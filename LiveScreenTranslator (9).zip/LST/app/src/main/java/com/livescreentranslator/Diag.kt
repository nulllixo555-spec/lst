package com.livescreentranslator

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Registro e relatório de diagnóstico. Nunca guarda textos lidos, imagens nem chaves de API. */
object Diag {
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    val counters = ConcurrentHashMap<String, Long>()

    fun init(c: Context) { file = File(c.filesDir, "diag.log") }

    @Synchronized fun log(tag: String, msg: String) {
        val line = "${fmt.format(Date())} [$tag] $msg"
        lines.addLast(line)
        while (lines.size > 300) lines.removeFirst()
        runCatching {
            file?.let { f ->
                if (f.length() > 150_000) f.delete()
                f.appendText(line + "\n")
            }
        }
    }

    fun error(tag: String, t: Throwable) {
        count("erros")
        val top = t.stackTrace.take(3).joinToString(" < ") { "${it.fileName}:${it.lineNumber}" }
        log(tag, "ERRO ${t.javaClass.simpleName}: ${t.message} @ $top")
    }

    fun count(name: String, n: Long = 1) { counters.merge(name, n) { a, b -> a + b } }

    fun time(name: String, ms: Long) { count("$name.n"); count("$name.ms", ms) }

    @Synchronized fun recent(): List<String> = lines.toList()

    fun recordCrash(c: Context, t: Throwable) {
        runCatching {
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            File(c.filesDir, "crash.txt").writeText("${Date()}\n$sw")
        }
    }

    fun clear(c: Context) {
        synchronized(this) { lines.clear() }
        counters.clear()
        runCatching { File(c.filesDir, "diag.log").delete(); File(c.filesDir, "crash.txt").delete() }
    }

    fun checks(c: Context): List<Pair<Boolean, String>> {
        val sp = c.getSharedPreferences("lst", Context.MODE_PRIVATE)
        val out = ArrayList<Pair<Boolean, String>>()
        out += Settings.canDrawOverlays(c) to "Permissão de exibir sobre outros apps"
        out += NotificationManagerCompat.from(c).areNotificationsEnabled() to "Notificações permitidas"
        out += Engines.isOnline(c) to "Internet disponível (só é necessária para baixar pacotes e para a IA)"
        out += (c.filesDir.usableSpace > 200L * 1048576) to "Mais de 200 MB de espaço livre"
        out += sp.getBoolean(K.CONSENT, false) to "Envio do texto para IA/online autorizado (opcional)"
        val hasConf = runCatching { Class.forName("com.google.mlkit.vision.text.Text\$Line").getMethod("getConfidence"); true }.getOrDefault(false)
        out += hasConf to "Indicador de confiança do OCR disponível nesta versão do ML Kit"
        return out
    }

    fun report(c: Context): String {
        val sp = c.getSharedPreferences("lst", Context.MODE_PRIVATE)
        val pi = runCatching { c.packageManager.getPackageInfo(c.packageName, 0) }.getOrNull()
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val rt = Runtime.getRuntime()
        val sb = StringBuilder()
        sb.append("RELATÓRIO · Live Screen Translator\n")
        sb.append("Versão: ${pi?.versionName ?: "?"}\n")
        sb.append("Aparelho: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("RAM livre: ${mi.availMem / 1048576} MB de ${mi.totalMem / 1048576} MB · heap do app: ${(rt.totalMemory() - rt.freeMemory()) / 1048576}/${rt.maxMemory() / 1048576} MB\n")
        sb.append("Espaço livre: ${c.filesDir.usableSpace / 1048576} MB\n\n")

        sb.append("VERIFICAÇÃO\n")
        for ((ok, msg) in checks(c)) sb.append(if (ok) "  OK   " else "  FALTA ").append(msg).append('\n')

        sb.append("\nCONFIGURAÇÕES\n")
        sb.append("  Mecanismo: ${sp.getString(K.ENGINE, "offline")} · modo da IA: ${sp.getString(K.QUALITY, "contextual")} · contexto: ${sp.getInt(K.CTX, 4)}\n")
        sb.append("  Chave Claude: ${if (Secrets.get(c, "claude").isEmpty()) "não" else "sim"} · chave Google: ${if (Secrets.get(c, "google").isEmpty()) "não" else "sim"}\n")
        sb.append("  Estilo: ${sp.getString(K.STYLE, "natural")} · balões: ${sp.getBoolean(K.BALLOON, true)}\n")
        sb.append("  Desempenho: ${sp.getString(K.POWER, "balanced")} · modo: ${sp.getString("mode", "auto")} · idioma da tela: ${sp.getString("source", "en")} · destino: ${sp.getString("target", "pt")}\n")
        sb.append("  Gestos: toque=${sp.getString(K.G_TAP, "menu")} duplo=${sp.getString(K.G_DOUBLE, "edit")} longo=${sp.getString(K.G_LONG, "retranslate")} dois dedos=${sp.getString(K.G_TWO, "toggle")} botão=${sp.getString(K.G_BUBBLE, "touch")}\n")
        sb.append("  Obra ativa: ${sp.getLong("activeWork", 0L)} · capítulo informado: ${if (sp.getString("activeChapter", "").isNullOrBlank()) "não" else "sim"}\n")
        sb.append("  Serviço: ${TranslatorService.state.value}\n")

        sb.append("\nCONTADORES E TEMPOS\n")
        val names = counters.keys.filter { !it.endsWith(".n") && !it.endsWith(".ms") }.sorted()
        for (k in names) sb.append("  $k: ${counters[k]}\n")
        for (k in counters.keys.filter { it.endsWith(".n") }.sorted()) {
            val base = k.removeSuffix(".n")
            val n = counters[k] ?: 0L
            val ms = counters["$base.ms"] ?: 0L
            sb.append("  tempo $base: ${if (n == 0L) 0 else ms / n} ms em média (${n}x)\n")
        }

        val crash = runCatching { File(c.filesDir, "crash.txt").readText() }.getOrDefault("")
        if (crash.isNotBlank()) sb.append("\nÚLTIMO TRAVAMENTO\n").append(crash.take(2500)).append('\n')

        sb.append("\nREGISTRO RECENTE\n")
        for (l in recent().takeLast(120)) sb.append("  ").append(l).append('\n')
        return sb.toString()
    }
}
