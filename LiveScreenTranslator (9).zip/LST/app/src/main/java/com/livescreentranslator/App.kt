package com.livescreentranslator

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Diag.init(this)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Diag.recordCrash(this, e)
            previous?.uncaughtException(t, e)
        }
        Diag.log("app", "aplicativo iniciado")
    }
}
