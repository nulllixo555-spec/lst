package com.livescreentranslator

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Term(
    val id: Long, val kind: String, val source: String, val target: String,
    val srcLang: String, val tgtLang: String, val whole: Boolean, val notes: String, val work: Long
)

/** Memória de correções (SQLite local): termos, nomes, lugares, habilidades, frases e histórico. */
class TermDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "lst_memory.db", null, 3) {

    private val appCtx = ctx.applicationContext

    companion object {
        val KINDS = listOf("Termo", "Personagem", "Habilidade", "Técnica", "Lugar", "Clã", "Família", "Organização", "Expressão", "Frase")
        @Volatile private var inst: TermDb? = null
        fun get(c: Context): TermDb = inst ?: synchronized(this) { inst ?: TermDb(c).also { inst = it } }
        fun norm(s: String) = s.trim().replace(Regex("\\s+"), " ")
        /** Obra ativa: termos dessa obra (e os globais) valem; os de outras obras não. */
        @Volatile var activeWork: Long = 0L
    }

    @Volatile private var cache: List<Term>? = null

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE terms(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, source TEXT, target TEXT, srcLang TEXT, tgtLang TEXT, whole INTEGER, created INTEGER, notes TEXT DEFAULT '', work INTEGER DEFAULT 0)")
        db.execSQL("CREATE UNIQUE INDEX idx_terms ON terms(source, tgtLang, work)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, original TEXT, old_t TEXT, new_t TEXT, at INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) db.execSQL("ALTER TABLE terms ADD COLUMN notes TEXT DEFAULT ''")
        if (o < 3) {
            db.execSQL("ALTER TABLE terms ADD COLUMN work INTEGER DEFAULT 0")
            db.execSQL("DROP INDEX IF EXISTS idx_terms")
            db.execSQL("CREATE UNIQUE INDEX idx_terms ON terms(source, tgtLang, work)")
        }
    }

    @Synchronized fun all(): List<Term> {
        cache?.let { return it }
        val out = ArrayList<Term>()
        readableDatabase.rawQuery("SELECT id,kind,source,target,srcLang,tgtLang,whole,notes,work FROM terms ORDER BY kind, source", null).use { c ->
            while (c.moveToNext()) out += Term(c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                c.getString(4) ?: "", c.getString(5) ?: "", c.getInt(6) == 1, c.getString(7) ?: "", c.getLong(8))
        }
        cache = out
        return out
    }

    @Synchronized fun upsert(kind: String, source: String, target: String, srcLang: String, tgtLang: String, notes: String = "", work: Long = 0L) {
        val v = ContentValues()
        v.put("kind", kind); v.put("source", norm(source)); v.put("target", norm(target))
        v.put("srcLang", srcLang); v.put("tgtLang", tgtLang); v.put("notes", notes); v.put("work", work)
        v.put("whole", if (kind == "Frase") 1 else 0); v.put("created", System.currentTimeMillis())
        writableDatabase.insertWithOnConflict("terms", null, v, SQLiteDatabase.CONFLICT_REPLACE)
        cache = null
    }

    @Synchronized fun update(id: Long, kind: String, source: String, target: String, notes: String, work: Long) {
        val v = ContentValues()
        v.put("kind", kind); v.put("source", norm(source)); v.put("target", norm(target))
        v.put("whole", if (kind == "Frase") 1 else 0)
        v.put("notes", notes); v.put("work", work)
        writableDatabase.update("terms", v, "id=?", arrayOf(id.toString()))
        cache = null
    }

    @Synchronized fun delete(id: Long) {
        writableDatabase.delete("terms", "id=?", arrayOf(id.toString()))
        cache = null
    }

    fun log(original: String, before: String, after: String) {
        val v = ContentValues()
        v.put("original", original); v.put("old_t", before); v.put("new_t", after); v.put("at", System.currentTimeMillis())
        synchronized(this) { writableDatabase.insert("history", null, v) }
    }

    /** Termos que a IA deve respeitar: os que aparecem no texto e os personagens cadastrados. */
    fun glossary(text: String, tgt: String): List<Term> {
        val terms = all().filter { it.tgtLang == tgt && !it.whole && inScope(it) }
        val hit = terms.filter { text.contains(it.source, ignoreCase = true) }
        val people = terms.filter { it.kind == "Personagem" && it !in hit }.take(12)
        return (hit + people).take(40)
    }

    /** Backup da memória de correções em JSON (cada termo leva o nome da sua obra). */
    fun exportJson(): String {
        val works = LibraryDb.get(appCtx).all().associateBy { it.id }
        val arr = JSONArray()
        for (t in all()) {
            val j = JSONObject()
            j.put("kind", t.kind); j.put("source", t.source); j.put("target", t.target)
            j.put("srcLang", t.srcLang); j.put("tgtLang", t.tgtLang); j.put("notes", t.notes)
            j.put("work", works[t.work]?.name ?: "")
            arr.put(j)
        }
        val o = JSONObject()
        o.put("app", "LiveScreenTranslator"); o.put("version", 2); o.put("terms", arr)
        return o.toString(2)
    }

    /** Quantos termos há no backup (para confirmar antes de importar). */
    fun countJson(text: String): Int = JSONObject(text).getJSONArray("terms").length()

    /** Importa um backup: termos com o mesmo original, idioma e obra são atualizados. Obras novas são criadas. */
    fun importJson(text: String): Int {
        val lib = LibraryDb.get(appCtx)
        val arr = JSONObject(text).getJSONArray("terms")
        var n = 0
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            val src = j.optString("source", "")
            val tgt = j.optString("target", "")
            if (src.isBlank() || tgt.isBlank()) continue
            val kind = j.optString("kind", "Termo").let { if (it in KINDS) it else "Termo" }
            val wn = j.optString("work", "")
            val work = if (wn.isBlank()) 0L else (lib.byName(wn)?.id ?: lib.add(wn, "Outro", ""))
            upsert(kind, src, tgt, j.optString("srcLang", ""), j.optString("tgtLang", "pt"), j.optString("notes", ""), work)
            n++
        }
        return n
    }

    private fun inScope(t: Term) = t.work == 0L || t.work == activeWork

    /** Tradução salva para o texto inteiro, se houver (a da obra ativa vale mais que a global). */
    fun exact(text: String, tgt: String): String? =
        all().filter { it.tgtLang == tgt && it.source == text && inScope(it) }.maxByOrNull { it.work }?.target

    fun deleteWork(work: Long) {
        synchronized(this) { writableDatabase.delete("terms", "work=?", arrayOf(work.toString())); cache = null }
    }

    fun moveWork(from: Long, to: Long) {
        synchronized(this) {
            val v = ContentValues()
            v.put("work", to)
            runCatching { writableDatabase.update("terms", v, "work=?", arrayOf(from.toString())) }
            cache = null
        }
    }

    /** Troca termos salvos (nomes etc.) pela forma preferida antes de traduzir. */
    fun preSubstitute(text: String, tgt: String): String {
        var s = text
        for (t in all().filter { !it.whole && it.tgtLang == tgt && it.source.length >= 2 && inScope(it) }.sortedByDescending { it.source.length }) {
            if (s.contains(t.source, ignoreCase = true)) s = s.replace(t.source, " ${t.target} ", ignoreCase = true)
        }
        return if (s == text) text else norm(s)
    }
}

/** Salva páginas e legendas em disco para recuperar depois (inclusive após reiniciar). */
object PageStore {
    private const val MAX_PAGES = 400
    private fun file(c: Context) = File(c.filesDir, "pages.json")

    fun toJson(pages: List<Page>): JSONArray {
        val arr = JSONArray()
        for (p in pages) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("fp", JSONArray(p.fingerprint.toList()))
            o.put("work", p.workId); o.put("chap", p.chapter); o.put("read", p.readAt)
            val subs = JSONArray()
            for (u in p.subs) {
                val j = JSONObject()
                j.put("id", u.id); j.put("region", u.regionId); j.put("o", u.original); j.put("t", u.translated)
                j.put("l", u.sourceLang); j.put("x", u.x); j.put("y", u.y); j.put("w", u.w); j.put("h", u.h)
                j.put("bg", u.bg); j.put("fg", u.fg); j.put("st", u.state.name)
                j.put("hist", JSONArray(u.history)); j.put("tgt", u.targetLang ?: "")
                j.put("ttl", u.ttlOv); j.put("uh", u.userHidden)
                j.put("style", u.styleKey ?: ""); j.put("eng", u.engine); j.put("conf", u.conf.toDouble()); j.put("sfx", u.sfx)
                u.styleOv?.let { j.put("sov", it.toJson()) }
                subs.put(j)
            }
            o.put("subs", subs)
            arr.put(o)
        }
        return arr
    }

    fun fromJson(arr: JSONArray): List<Page> {
        val out = ArrayList<Page>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val fpA = o.getJSONArray("fp")
            val page = Page(o.getLong("id"), IntArray(fpA.length()) { fpA.getInt(it) })
            Ids.ensure(page.id)
            page.workId = o.optLong("work", 0L); page.chapter = o.optString("chap", ""); page.readAt = o.optLong("read", 0L)
            val subs = o.getJSONArray("subs")
            for (k in 0 until subs.length()) {
                val j = subs.getJSONObject(k)
                val u = Subtitle(j.getLong("id"), j.getString("region"), j.getString("o"), j.getString("t"), j.getString("l"),
                    j.getInt("x"), j.getInt("y"), j.getInt("w"), j.getInt("h"), j.getInt("bg"), j.getInt("fg"))
                Ids.ensure(u.id)
                u.state = runCatching { SubState.valueOf(j.getString("st")) }.getOrDefault(SubState.TRANSLATED)
                val h = j.getJSONArray("hist")
                for (m in 0 until h.length()) u.history.add(h.getString(m))
                u.targetLang = j.getString("tgt").ifEmpty { null }
                u.ttlOv = j.getLong("ttl"); u.userHidden = j.getBoolean("uh")
                u.styleKey = j.optString("style", "").ifEmpty { null }
                u.engine = j.optString("eng", "offline")
                u.conf = j.optDouble("conf", -1.0).toFloat()
                u.sfx = j.optBoolean("sfx", false)
                j.optJSONObject("sov")?.let { u.styleOv = SubStyle.fromJson(it) }
                page.subs.add(u)
            }
            out.add(page)
        }
        return out
    }

    /** Escreve num arquivo temporário e troca no fim: um travamento no meio não estraga o histórico. */
    fun save(c: Context, pages: List<Page>) {
        runCatching {
            val f = file(c)
            val tmp = File(f.parentFile, "pages.tmp")
            tmp.writeText(toJson(pages.takeLast(MAX_PAGES)).toString())
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        }
    }

    fun load(c: Context): List<Page> = runCatching {
        val f = file(c)
        if (!f.exists()) emptyList() else fromJson(JSONArray(f.readText()))
    }.getOrDefault(emptyList())

    fun mutate(c: Context, change: (Page) -> Unit) {
        val all = load(c)
        all.forEach(change)
        save(c, all)
    }

    fun deleteWhere(c: Context, pred: (Page) -> Boolean) {
        save(c, load(c).filterNot(pred))
    }
}
