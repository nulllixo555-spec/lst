package com.livescreentranslator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast

/** Verificação rápida e relatório para enviar quando algo der errado. */
class DiagActivity : FormActivity() {

    private lateinit var reportView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("Diagnóstico")
        header("VERIFICAÇÃO")
        for ((ok, msg) in Diag.checks(this)) {
            content.addView(label((if (ok) "✔ " else "✖ ") + msg, 14f, if (ok) 0xFF69F0AE.toInt() else 0xFFFFB74D.toInt()).apply { setPadding(0, dp(3), 0, dp(3)) })
        }
        hint("Itens com ✖ nem sempre são problema: internet e envio para IA, por exemplo, são opcionais.")

        header("RELATÓRIO PARA ENVIAR")
        hint("O relatório não inclui textos lidos, imagens nem chaves de API. Tem o aparelho, as configurações, tempos médios e o registro dos últimos eventos e erros.")
        reportView = label(Diag.report(this), 11f, MUTED).apply { typeface = Typeface.MONOSPACE; setTextIsSelectable(true) }
        button("Copiar relatório") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("relatório", reportView.text))
            Toast.makeText(this, "Relatório copiado", Toast.LENGTH_SHORT).show()
        }
        button("Compartilhar", outlined = true) {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, reportView.text.toString())
            startActivity(Intent.createChooser(i, "Enviar relatório"))
        }
        button("Atualizar", outlined = true) { reportView.text = Diag.report(this) }
        button("Limpar registros", outlined = true) { Diag.clear(this); reportView.text = Diag.report(this) }
        content.addView(reportView)
    }
}
