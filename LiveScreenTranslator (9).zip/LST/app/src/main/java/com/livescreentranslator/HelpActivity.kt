package com.livescreentranslator

import android.os.Bundle

/** Como usar e problemas conhecidos. Abre sozinha na primeira vez. */
class HelpActivity : FormActivity() {

    private fun para(t: String) { content.addView(label(t, 14f).apply { setPadding(0, dp(4), 0, dp(4)) }) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("Como usar")

        header("PRIMEIROS PASSOS")
        para("1. Na tela inicial, escolha o idioma do texto na tela (por exemplo, Japonês) e para qual idioma traduzir.")
        para("2. Em Idiomas offline, baixe os pacotes que vai usar (cada um tem cerca de 30 MB). Faça isso com Wi-Fi.")
        para("3. Se quiser, cadastre a obra na Biblioteca e informe o capítulo na tela inicial. Assim o histórico e o dicionário ficam organizados.")
        para("4. Toque em Iniciar tradução e permita as telas que o Android pedir (sobreposição, notificações e captura de tela).")
        para("5. Abra o mangá ou o site. As traduções aparecem por cima do texto original.")

        header("MEXER NAS LEGENDAS")
        para("O Android não deixa a sobreposição receber toques sem bloquear o app de baixo. Por isso existe o botão flutuante 👆: toque nele para ligar o modo toque (desliga sozinho em 15 segundos), depois toque na legenda.")
        para("Um toque abre o menu. Dois toques editam. Toque prolongado traduz de novo. Dois dedos ocultam ou mostram todas. Tudo isso dá para mudar em Tradução e IA.")
        para("Segure o botão 👆 para reexibir legendas que você ocultou.")

        header("PARA CELULARES SIMPLES (COMO O A07)")
        para("Use o desempenho Econômico, feche outros apps e prefira o modo Sob demanda: o app só traduz quando você toca no botão 👆. Leia em página por página se o seu leitor permitir.")
        para("Se a tradução ficar ruim por letras pequenas, teste Equilibrado ou Alta precisão, que leem com mais detalhe e são mais lentos.")

        header("PROBLEMAS CONHECIDOS")
        para("• O tradutor offline é bem mais fraco que o Google Tradutor, principalmente do japonês para o português. A IA com contexto melhora, mas precisa de chave, crédito e internet.")
        para("• Rolagem muito rápida, zoom com os dedos e telas que se mexem sozinhas (jogos, vídeos) confundem o rastreamento. Nesses casos as legendas podem sumir e ser refeitas.")
        para("• Letras muito estilizadas, texto vertical e efeitos sonoros desenhados são lidos com erros. Só uma tabela de efeitos comuns é traduzida direto.")
        para("• O app não descobre sozinho quem está falando nem o número do capítulo. Você informa o capítulo, e a IA infere o falante pelo contexto e pelas observações do dicionário.")
        para("• Os estilos de tradução só valem para a IA. O tradutor offline não aceita instruções de estilo.")
        para("• O ML Kit não tem pacote separado de chinês tradicional.")
        para("• O Android pode encerrar o serviço para poupar bateria. Em Configurações do Android, deixe a bateria deste app como Sem restrições.")

        header("SE ALGO DER ERRADO")
        para("Abra Diagnóstico e use Copiar relatório. O relatório não inclui textos lidos, imagens nem chaves, e ajuda muito a achar o problema.")
        button("Entendi") { finish() }
    }
}
