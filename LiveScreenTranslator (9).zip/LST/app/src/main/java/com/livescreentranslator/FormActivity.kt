package com.livescreentranslator

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.button.MaterialButton

/** Base simples para telas de configuração montadas em código. */
abstract class FormActivity : AppCompatActivity() {
    protected lateinit var content: LinearLayout
    protected val sp by lazy { getSharedPreferences("lst", MODE_PRIVATE) }
    protected val WHITE = 0xFFFFFFFF.toInt()
    protected val MUTED = 0xFF9AA0C8.toInt()
    protected val ACCENT = 0xFF6C63FF.toInt()
    protected val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    protected fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    protected fun setup(title: String) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(label(title, 22f).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(dp(20), dp(16), dp(20), dp(8)) })
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), dp(40)) }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    protected fun label(t: String, size: Float = 14f, color: Int = WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }

    protected fun header(t: String) {
        content.addView(label(t, 13f, ACCENT).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(26), 0, dp(4)) })
    }

    protected fun hint(t: String) { content.addView(label(t, 12f, MUTED).apply { setPadding(0, dp(2), 0, dp(4)) }) }

    protected fun switchRow(title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        content.addView(SwitchCompat(this).apply {
            text = title; setTextColor(WHITE); isChecked = get(); setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, v -> set(v) }
        })
    }

    protected fun spinnerRow(title: String, options: List<String>, selected: Int, onSel: (Int) -> Unit) {
        content.addView(label(title).apply { setPadding(0, dp(10), 0, 0) })
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        s.setSelection(selected.coerceAtLeast(0))
        var first = true
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                onSel(pos)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        content.addView(s, LinearLayout.LayoutParams(MATCH, dp(52)))
    }

    protected fun sliderRow(title: String, lo: Int, hi: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String = { "$it" }) {
        val tv = label("$title: ${fmt(get())}").apply { setPadding(0, dp(10), 0, 0) }
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (get() - lo).coerceIn(0, hi - lo)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$title: ${fmt(p + lo)}"
                if (fromUser) set(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(tv); content.addView(sb)
    }

    protected fun button(title: String, outlined: Boolean = false, onClick: () -> Unit): MaterialButton {
        val b = if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle) else MaterialButton(this)
        b.text = title
        b.setOnClickListener { onClick() }
        content.addView(b, LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(10) })
        return b
    }

    protected fun card(parent: LinearLayout? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(10))
        background = GradientDrawable().apply { cornerRadius = 16 * resources.displayMetrics.density; setColor(0xFF1A1E3C.toInt()) }
    }.also { (parent ?: content).addView(it, LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }) }

    protected fun rowButtons(vararg b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END
        for (v in b) addView(v)
    }

    protected fun link(t: String, color: Int = ACCENT, onClick: () -> Unit) =
        label(t, 14f, color).apply { setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { onClick() } }

    /** Alterações no histórico só com a tradução parada (o serviço também grava esses arquivos). */
    protected fun idleOrWarn(): Boolean {
        if (TranslatorService.state.value == TranslatorService.State.IDLE) return true
        android.widget.Toast.makeText(this, "Encerre a tradução antes de fazer isso.", android.widget.Toast.LENGTH_LONG).show()
        return false
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState) }
}
