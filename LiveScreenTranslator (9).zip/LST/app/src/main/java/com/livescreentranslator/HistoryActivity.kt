package com.livescreentranslator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico por capítulo: textos reconhecidos, traduções, correções, pendências e data da leitura. */
class HistoryActivity : FormActivity() {

    private var workId = 0L
    private var filter = 0
    private lateinit var listBox: LinearLayout
    private var pages: List<Page> = emptyList()
    private val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

    private class Group(val chapter: String, val pages: List<Page>) {
        val translated = pages.sumOf { p -> p.subs.count { it.state == SubState.TRANSLATED || it.state == SubState.EDITED } }
        val edited = pages.sumOf { p -> p.subs.count { it.state == SubState.EDITED } }
        val pending = pages.sumOf { p -> p.subs.count { it.state == SubState.FAILED } }
        val last = pages.maxOfOrNull { it.readAt } ?: 0L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        workId = intent.getLongExtra("work", 0L)
        val name = if (workId == 0L) "Sem obra definida" else (LibraryDb.get(this).byId(workId)?.name ?: "Obra removida")
        setup("Histórico · $name")
        if (TranslatorService.state.value != TranslatorService.State.IDLE)
            hint("A tradução está ativa: as páginas mais recentes podem levar alguns segundos para aparecer aqui.")
        hint("O app não reconhece o número do capítulo sozinho: ele usa o que você informa na tela inicial. Aqui você pode renomear ou mover as páginas para outro capítulo. Quando uma página já traduzida aparece de novo na leitura, a tradução salva volta sozinha.")
        spinnerRow("Mostrar", listOf("Todos os capítulos", "Com traduções pendentes", "Com correções manuais"), 0) { filter = it; refresh() }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)
        load()
    }

    private fun load() {
        Thread {
            val all = PageStore.load(this).filter { it.workId == workId }
            runOnUiThread { if (!isFinishing) { pages = all; refresh() } }
        }.start()
    }

    private fun title(g: Group) = if (g.chapter.isBlank()) "Sem capítulo informado" else "Capítulo ${g.chapter} (informado por você)"

    private fun refresh() {
        listBox.removeAllViews()
        var groups = pages.groupBy { it.chapter }.map { Group(it.key, it.value) }.sortedByDescending { it.last }
        if (filter == 1) groups = groups.filter { it.pending > 0 }
        if (filter == 2) groups = groups.filter { it.edited > 0 }
        if (groups.isEmpty()) {
            listBox.addView(label("Nada aqui ainda. As páginas aparecem depois que você traduz algo com esta obra ativa.", 13f, MUTED).apply { setPadding(0, dp(16), 0, 0) })
            return
        }
        for (g in groups) {
            val c = card(listBox)
            c.addView(label(title(g), 17f))
            c.addView(label("${g.pages.size} páginas · ${g.translated} legendas traduzidas · ${g.edited} corrigidas por você · ${g.pending} pendentes", 12f, MUTED))
            if (g.last > 0) c.addView(label("Última leitura: ${df.format(Date(g.last))}", 12f, MUTED))
            if (g.pending > 0) c.addView(label("Pendentes são traduzidas sozinhas quando você reabre a página com os pacotes ou a internet disponíveis.", 11f, MUTED))
            c.addView(rowButtons(link("Ver textos") { showTexts(g) }, link("Copiar tudo") { copyAll(g) }))
            c.addView(rowButtons(link("Renomear / mover") { rename(g) }, link("Excluir", 0xFFFF6B6B.toInt()) { delete(g) }))
        }
    }

    private fun chapterText(g: Group): String {
        val sb = StringBuilder()
        g.pages.sortedBy { it.readAt }.forEachIndexed { i, p ->
            sb.append("— Página ${i + 1} —\n")
            for (s in p.subs.sortedWith(compareBy<Subtitle>({ it.y / 100 }, { -it.x }))) {
                sb.append(s.original).append("  →  ")
                sb.append(if (s.state == SubState.FAILED) "(pendente)" else s.translated)
                if (s.state == SubState.EDITED) sb.append("  ✎ corrigida por você")
                sb.append('\n')
            }
            sb.append('\n')
        }
        return sb.toString()
    }

    private fun showTexts(g: Group) {
        val tv = TextView(this).apply {
            text = chapterText(g).take(30000); setTextIsSelectable(true); textSize = 13f
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        AlertDialog.Builder(this).setTitle(title(g)).setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Fechar", null).show()
    }

    private fun copyAll(g: Group) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("capítulo", chapterText(g)))
        Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
    }

    private fun rename(g: Group) {
        if (!idleOrWarn()) return
        val et = EditText(this).apply { hint = "Número ou nome do capítulo (vazio = sem capítulo)"; setText(g.chapter) }
        AlertDialog.Builder(this).setTitle("Renomear ou mover").setView(et)
            .setPositiveButton("Salvar") { _, _ ->
                val nc = et.text.toString().trim()
                PageStore.mutate(this) { if (it.workId == workId && it.chapter == g.chapter) it.chapter = nc }
                load()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun delete(g: Group) {
        if (!idleOrWarn()) return
        AlertDialog.Builder(this).setTitle("Excluir este histórico?")
            .setMessage("${title(g)}: ${g.pages.size} páginas e suas traduções salvas, inclusive as correções manuais desse capítulo. O dicionário não é apagado.")
            .setPositiveButton("Excluir") { _, _ ->
                PageStore.deleteWhere(this) { it.workId == workId && it.chapter == g.chapter }
                load()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
