package com.livescreentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Camada transparente. Cada legenda está em coordenadas do "mundo" da página;
 * a posição na tela é (mundo - rolagem), então ela acompanha o texto original.
 */
class OverlayView(context: Context) : View(context) {

    private class Lay(val sig: Int, val fill: StaticLayout, val stroke: StaticLayout?, val bw: Float, val bh: Float, val pad: Float, val bg: Int)
    private class Pos(val sub: Subtitle, val s: SubStyle, val lay: Lay, var box: RectF)

    private val FOREVER = Long.MAX_VALUE / 4
    private val lays = HashMap<Long, Lay>()
    private val born = HashMap<Long, Long>()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var subs: List<Subtitle> = emptyList()
    private var scrollX = 0
    private var scrollY = 0
    private var hits: List<Pair<Subtitle, RectF>> = emptyList()

    /** Caixas (em coordenadas da tela) das legendas, usadas para ignorar essas áreas no rastreamento. */
    @Volatile var boxes: List<android.graphics.Rect> = emptyList()

    var previewMode = false
    var touchMode = false
    var onTap: ((Subtitle?, RectF?) -> Unit)? = null
    var onLongPress: ((Subtitle, RectF) -> Unit)? = null
    var onDouble: ((Subtitle?, RectF?) -> Unit)? = null
    var onTwoFinger: (() -> Unit)? = null
    private var twoAt = 0L

    var suppressed = false
        set(v) { field = v; invalidate() }

    var style: SubStyle = SubStyle()
        set(v) {
            field = v
            setLayerType(if (v.shadow) LAYER_TYPE_SOFTWARE else LAYER_TYPE_NONE, null)
            invalidate()
        }

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            val h = hit(e.x, e.y)
            onTap?.invoke(h?.first, h?.second)
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val h = hit(e.x, e.y)
            onDouble?.invoke(h?.first, h?.second)
            return true
        }
        override fun onLongPress(e: MotionEvent) {
            val h = hit(e.x, e.y) ?: return
            onLongPress?.invoke(h.first, h.second)
        }
    })

    private fun hit(x: Float, y: Float): Pair<Subtitle, RectF>? = hits.lastOrNull { it.second.contains(x, y) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!touchMode) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) twoAt = SystemClock.uptimeMillis()
            MotionEvent.ACTION_POINTER_UP -> if (twoAt > 0 && SystemClock.uptimeMillis() - twoAt < 400) {
                twoAt = 0
                onTwoFinger?.invoke()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> twoAt = 0
        }
        gestures.onTouchEvent(e)
        return true
    }

    fun update(list: List<Subtitle>, sx: Int, sy: Int) {
        subs = list; scrollX = sx; scrollY = sy
        val dm = resources.displayMetrics
        val w = if (width > 0) width else dm.widthPixels
        val h = if (height > 0) height else dm.heightPixels
        val out = ArrayList<android.graphics.Rect>()
        for (s in list) {
            val r = android.graphics.Rect(s.x - sx - 16, s.y - sy - 16, s.x + s.w - sx + 16, s.y + s.h - sy + 16)
            if (r.right > 0 && r.bottom > 0 && r.left < w && r.top < h) out += r
        }
        boxes = out
        invalidate()
    }

    fun resetAnim() { born.clear(); invalidate() }

    fun boxOf(sub: Subtitle): RectF? = hits.firstOrNull { it.first.id == sub.id }?.second

    // ------------------------------------------------------------ layout

    private fun layouts(text: String, innerW: Int, innerH: Int, shrink: Boolean, start: Float, tf: Typeface, fg: Int, s: SubStyle): Pair<StaticLayout, StaticLayout?> {
        val dm = resources.displayMetrics
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = tf; color = fg; isUnderlineText = s.underline; letterSpacing = s.letterSpacing
        }
        val t = if (s.wrap) text else text.replace('\n', ' ')
        val align = when (s.align) {
            0 -> Layout.Alignment.ALIGN_NORMAL
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_CENTER
        }
        fun mk(size: Float): StaticLayout {
            paint.textSize = size
            val w = if (s.wrap) innerW else ceil(paint.measureText(t)).toInt().coerceAtLeast(1)
            return StaticLayout.Builder.obtain(t, 0, t.length, paint, w)
                .setAlignment(align).setIncludePad(false).setLineSpacing(0f, s.lineSpacing).build()
        }
        fun fits(l: StaticLayout) = if (s.wrap) l.height <= innerH else l.width <= innerW

        val minSize = 7f * dm.scaledDensity
        var size = start
        var layout = mk(size)
        while (shrink && size > minSize && !fits(layout)) {
            size -= max(1f, size * 0.06f)
            layout = mk(size)
        }
        var stroke: StaticLayout? = null
        if (s.outline) {
            val p2 = TextPaint(paint).apply {
                style = Paint.Style.STROKE; strokeWidth = s.outlineDp * dm.density
                color = s.outlineColor; strokeJoin = Paint.Join.ROUND
            }
            stroke = StaticLayout.Builder.obtain(t, 0, t.length, p2, layout.width)
                .setAlignment(align).setIncludePad(false).setLineSpacing(0f, s.lineSpacing).build()
        }
        return layout to stroke
    }

    private fun layoutFor(sub: Subtitle, s: SubStyle, sig: Int): Lay {
        val dm = resources.displayMetrics
        val d = dm.density
        val sd = dm.scaledDensity
        val w = if (width > 0) width else dm.widthPixels
        val tf = FontResolver.resolve(context, s.font, s.bold, s.italic)
        val pad = s.paddingDp * d
        val stack = s.position != 0

        var bw = if (stack) (w * 0.92f * s.widthPct / 100f).coerceIn(80f * d, w.toFloat()) else sub.w * s.widthPct / 100f
        // Texto vertical (mangá/manhua): a tradução horizontal precisa de mais largura para ser legível.
        if (!stack && sub.h > sub.w * 2f) bw = max(bw, min(sub.h * 0.55f, w * 0.5f))
        val bh0 = if (stack) 0f else sub.h * s.heightPct / 100f
        val innerW = (bw - 2 * pad).toInt().coerceAtLeast(10)
        val innerH = if (stack) Int.MAX_VALUE / 4 else (bh0 - 2 * pad).toInt().coerceAtLeast(10)
        val shrink = s.autoSize && !stack
        val start = if (s.autoSize && !stack) min(innerH.toFloat(), 22f * sd) else (if (s.autoSize) 18f else s.textSizeSp) * sd

        val under = if (!s.bgEnabled || s.bgAuto) sub.bg else s.bgColor
        val fg = if (s.textColorAuto)
            (if (ColorUtils.calculateLuminance(under) > 0.45) 0xFF111111.toInt() else 0xFFF5F5F5.toInt())
        else s.textColor

        val (fill, stroke) = layouts(sub.translated, innerW, innerH, shrink, start, tf, fg, s)
        val bh = if (stack) fill.height + 2 * pad else bh0
        return Lay(sig, fill, stroke, bw, bh, pad, if (s.bgAuto) sub.bg else s.bgColor)
    }

    // ------------------------------------------------------------ desenho

    override fun onDraw(canvas: Canvas) {
        if (suppressed || subs.isEmpty()) { hits = emptyList(); return }
        val d = resources.displayMetrics.density
        val now = SystemClock.uptimeMillis()
        val W = width.toFloat()
        val H = height.toFloat()
        val list = ArrayList<Pos>()
        val allIds = HashSet<Long>()

        for (sub in subs) {
            allIds += sub.id
            val l = sub.x - scrollX
            val t = sub.y - scrollY
            val onScreen = l + sub.w > -60 && l < W + 60 && t + sub.h > -60 && t < H + 60
            if (!onScreen) { born.remove(sub.id); continue }
            if (sub.hidden || sub.userHidden || sub.state == SubState.FAILED) continue
            val s = sub.styleOv ?: style
            val sig = listOf(sub.translated, sub.w, sub.h, sub.bg, sub.fg, s, width).hashCode()
            val lay = lays[sub.id]?.takeIf { it.sig == sig } ?: layoutFor(sub, s, sig).also { lays[sub.id] = it }
            val box = if (s.position == 0) {
                val cx = sub.x + sub.w / 2f + s.offsetXDp * d - scrollX
                val cy = sub.y + sub.h / 2f + s.offsetYDp * d - scrollY
                RectF(cx - lay.bw / 2, cy - lay.bh / 2, cx + lay.bw / 2, cy + lay.bh / 2)
            } else RectF(0f, 0f, lay.bw, lay.bh)
            list += Pos(sub, s, lay, box)
        }
        lays.keys.retainAll(allIds)
        born.keys.retainAll(allIds)

        // Modos fixos (embaixo/topo/centro): empilha as legendas visíveis.
        val stacked = list.filter { it.s.position != 0 }.sortedBy { it.sub.y }
        if (stacked.isNotEmpty()) {
            val s0 = stacked[0].s
            val gap = 6 * d
            val total = stacked.sumOf { it.box.height().toDouble() }.toFloat() + gap * (stacked.size - 1)
            var y = when (s0.position) { 1 -> H - total - 72 * d; 2 -> 56 * d; else -> (H - total) / 2f } + s0.offsetYDp * d
            for (p in stacked) {
                val bw = p.box.width(); val bh = p.box.height()
                val x = (W - bw) / 2f + s0.offsetXDp * d
                p.box = RectF(x, y, x + bw, y + bh)
                y += bh + gap
            }
        }

        var fading = false
        var finite = false
        val shown = ArrayList<Pair<Subtitle, RectF>>()
        for (p in list) {
            val s = p.s
            val b = born.getOrPut(p.sub.id) { now }
            val ttl = when {
                previewMode -> FOREVER
                p.sub.ttlOv == 0L -> FOREVER
                p.sub.ttlOv > 0L -> p.sub.ttlOv
                s.keepWhileStatic -> FOREVER
                else -> {
                    val raw = if (s.durationAuto) p.sub.translated.length * s.msPerChar else s.fixedMs
                    raw.coerceIn(s.minMs, max(s.minMs, s.maxMs))
                }
            }
            val age = now - b
            if (age >= ttl) continue
            if (ttl < FOREVER) finite = true
            var a = 1f
            if (s.anim != 0) {
                if (s.fadeInMs > 0 && age < s.fadeInMs) { a = age.toFloat() / s.fadeInMs; fading = true }
                val left = ttl - age
                if (s.fadeOutMs > 0 && left < s.fadeOutMs) { a = min(a, left.toFloat() / s.fadeOutMs); fading = true }
            }
            drawOne(canvas, p, a.coerceIn(0f, 1f), d)
            shown += p.sub to RectF(p.box)
        }
        hits = shown
        if (fading) postInvalidateOnAnimation() else if (finite) postInvalidateDelayed(100)
    }

    private fun drawOne(c: Canvas, p: Pos, a: Float, d: Float) {
        val s = p.s
        val box = p.box
        val m = 14 * d
        val save = c.saveLayerAlpha(box.left - m, box.top - m, box.right + m, box.bottom + m, (a * 255).toInt())
        when (s.anim) {
            2 -> c.translate(0f, (1f - a) * 18 * d)
            3 -> { val sc = 0.85f + 0.15f * a; c.scale(sc, sc, box.centerX(), box.centerY()) }
        }
        val cr = s.cornerDp * d
        if (s.bgEnabled) {
            bgPaint.style = Paint.Style.FILL
            bgPaint.color = ColorUtils.setAlphaComponent(p.lay.bg, s.bgAlpha * 255 / 100)
            if (s.shadow) bgPaint.setShadowLayer(8 * d, 0f, 3 * d, 0x99000000.toInt()) else bgPaint.clearShadowLayer()
            c.drawRoundRect(box, cr, cr, bgPaint)
            bgPaint.clearShadowLayer()
            if (s.borderDp > 0) {
                val bw = s.borderDp * d
                borderPaint.style = Paint.Style.STROKE
                borderPaint.strokeWidth = bw
                borderPaint.color = s.borderColor
                val rr = RectF(box)
                rr.inset(bw / 2, bw / 2)
                c.drawRoundRect(rr, cr, cr, borderPaint)
            }
        }
        c.save()
        c.clipRect(box)
        val innerW = box.width() - 2 * p.lay.pad
        val ox = when (s.align) {
            0 -> 0f
            2 -> innerW - p.lay.fill.width
            else -> (innerW - p.lay.fill.width) / 2f
        }
        val top = box.top + p.lay.pad + max(0f, (box.height() - 2 * p.lay.pad - p.lay.fill.height) / 2f)
        c.translate(box.left + p.lay.pad + max(0f, ox), top)
        p.lay.stroke?.draw(c)
        p.lay.fill.draw(c)
        c.restore()
        if (s.showConf && p.sub.conf >= 0f) {
            dotPaint.color = when {
                p.sub.conf >= 0.85f -> 0xFF4CAF50.toInt()
                p.sub.conf >= 0.6f -> 0xFFFFC107.toInt()
                else -> 0xFFF44336.toInt()
            }
            c.drawCircle(box.right - 7 * d, box.top + 7 * d, 4.5f * d, dotPaint)
        }
        c.restoreToCount(save)
    }
}
