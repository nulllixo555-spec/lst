package com.livescreentranslator

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Biblioteca de obras: cadastro, favoritas, recentes, busca, edição, exclusão e backup. */
class LibraryActivity : FormActivity() {

    private lateinit var lib: LibraryDb
    private lateinit var listBox: LinearLayout
    private var filter = 0
    private var query = ""
    private var stats: Map<Long, IntArray> = emptyMap()     // obra -> [capítulos, páginas, legendas]
    private val df = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

    private val exporter = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        val ok = runCatching {
            contentResolver.openOutputStream(uri)?.use { it.write(BackupHelper.export(this).toByteArray(Charsets.UTF_8)) }
        }.isSuccess
        Toast.makeText(this, if (ok) "Backup salvo" else "Não foi possível salvar o backup", Toast.LENGTH_LONG).show()
    }

    private val importer = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        if (!idleOrWarn()) return@registerForActivityResult
        val text = runCatching { contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull()
        val sum = text?.let { runCatching { BackupHelper.summary(it) }.getOrNull() }
        if (text == null || sum == null) {
            Toast.makeText(this, "Esse arquivo não é um backup válido", Toast.LENGTH_LONG).show()
            return@registerForActivityResult
        }
        AlertDialog.Builder(this).setTitle("Importar backup completo?")
            .setMessage("${sum.first} obras, ${sum.second} termos e ${sum.third} páginas. Nada do que você já tem será apagado.")
            .setPositiveButton("Importar") { _, _ ->
                val r = runCatching { BackupHelper.import(this, text) }.getOrNull()
                Toast.makeText(this, if (r == null) "Falha ao importar" else "Novas: ${r.first} obras, ${r.second} termos, ${r.third} páginas", Toast.LENGTH_LONG).show()
                refresh(); loadStats()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("Biblioteca")
        lib = LibraryDb.get(this)
        hint("Cadastre as obras que você lê. O histórico de páginas, as correções e o dicionário ficam ligados a cada obra, e tudo fica só neste celular.")
        button("＋ Adicionar obra") { editWork(null) }
        spinnerRow("Mostrar", listOf("Recentes", "Favoritas", "Todas"), 0) { filter = it; refresh() }
        val search = EditText(this)
        search.hint = "Buscar obra…"; search.setTextColor(WHITE); search.setHintTextColor(MUTED)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { query = e.toString().trim(); refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        content.addView(search)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)

        header("BACKUP COMPLETO (obras, dicionário e histórico)")
        button("Exportar backup", outlined = true) { exporter.launch("biblioteca-lst.json") }
        button("Importar backup", outlined = true) { importer.launch(arrayOf("*/*")) }
        hint("Para guardar na nuvem ou levar para outro celular, salve o arquivo no seu Google Drive ou envie por um app de mensagens. O app não sincroniza nada sozinho nem envia seus dados a servidores.")
        refresh()
    }

    override fun onResume() { super.onResume(); refresh(); loadStats() }

    private fun loadStats() {
        Thread {
            val pages = PageStore.load(this)
            val m = HashMap<Long, IntArray>()
            val chapters = HashMap<Long, HashSet<String>>()
            for (p in pages) {
                val a = m.getOrPut(p.workId) { IntArray(3) }
                a[1]++; a[2] += p.subs.size
                chapters.getOrPut(p.workId) { HashSet() }.add(p.chapter)
            }
            for ((k, v) in chapters) m[k]?.set(0, v.size)
            runOnUiThread { if (!isFinishing) { stats = m; refresh() } }
        }.start()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val active = sp.getLong("activeWork", 0L)
        var ws = lib.all()
        if (filter == 1) ws = ws.filter { it.favorite }
        if (query.isNotEmpty()) ws = ws.filter { it.name.contains(query, ignoreCase = true) }
        ws = if (filter == 0) ws.sortedByDescending { it.lastRead } else ws.sortedBy { it.name.lowercase() }
        for (w in ws) addCard(w, active)
        val orphan = stats[0L]
        if (filter != 1 && query.isEmpty() && orphan != null && orphan[1] > 0) {
            val c = card(listBox)
            c.addView(label("Sem obra definida", 17f))
            c.addView(label("${orphan[0]} capítulos · ${orphan[1]} páginas · ${orphan[2]} legendas", 12f, MUTED))
            c.addView(rowButtons(link("Histórico") { openHistory(0L) }))
        }
        if (listBox.childCount == 0)
            listBox.addView(label("Nenhuma obra aqui ainda. Toque em “Adicionar obra”.", 13f, MUTED).apply { setPadding(0, dp(16), 0, 0) })
    }

    private fun addCard(w: Work, active: Long) {
        val c = card(listBox)
        c.addView(label((if (w.favorite) "★ " else "") + w.name + if (w.id == active) "  (obra ativa)" else "", 17f))
        val st = stats[w.id]
        c.addView(label(w.type + (if (st != null) " · ${st[0]} capítulos · ${st[1]} páginas · ${st[2]} legendas" else ""), 12f, MUTED))
        if (w.lastRead > 0) c.addView(label("Última leitura: ${df.format(Date(w.lastRead))}", 12f, MUTED))
        if (w.notes.isNotBlank()) c.addView(label(w.notes, 12f, MUTED))
        c.addView(rowButtons(
            link("Usar agora") {
                sp.edit().putLong("activeWork", w.id).apply(); TermDb.activeWork = w.id
                Toast.makeText(this, "Obra ativa: ${w.name}", Toast.LENGTH_SHORT).show(); refresh()
            },
            link("Histórico") { openHistory(w.id) }
        ))
        c.addView(rowButtons(
            link(if (w.favorite) "★ Favorita" else "☆ Favoritar") { lib.setFavorite(w.id, !w.favorite); refresh() },
            link("Editar") { editWork(w) },
            link("Excluir", 0xFFFF6B6B.toInt()) { deleteWork(w) }
        ))
    }

    private fun openHistory(workId: Long) {
        startActivity(Intent(this, HistoryActivity::class.java).putExtra("work", workId))
    }

    private fun editWork(w: Work?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Nome da obra"; setText(w?.name ?: "") }
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, LibraryDb.TYPES)
        type.setSelection(w?.let { LibraryDb.TYPES.indexOf(it.type) }?.coerceAtLeast(0) ?: 0)
        val notes = EditText(this).apply { hint = "Observações (opcional)"; setText(w?.notes ?: "") }
        box.addView(name); box.addView(type); box.addView(notes)
        AlertDialog.Builder(this).setTitle(if (w == null) "Nova obra" else "Editar obra").setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val n = name.text.toString().trim()
                val t = LibraryDb.TYPES[type.selectedItemPosition]
                val o = notes.text.toString().trim()
                if (n.isEmpty()) {
                    Toast.makeText(this, "Informe o nome", Toast.LENGTH_SHORT).show()
                } else if (w == null) {
                    if (lib.byName(n) != null) Toast.makeText(this, "Já existe uma obra com esse nome", Toast.LENGTH_SHORT).show()
                    else lib.add(n, t, o)
                } else lib.update(w.id, n, t, o)
                refresh()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun deleteWork(w: Work) {
        if (!idleOrWarn()) return
        AlertDialog.Builder(this).setTitle("Excluir “${w.name}”?")
            .setMessage("Você pode excluir só a obra (o histórico e os termos continuam, sem obra) ou tudo o que pertence a ela.")
            .setPositiveButton("Obra e dados") { _, _ ->
                PageStore.deleteWhere(this) { it.workId == w.id }
                TermDb.get(this).deleteWork(w.id)
                finishDelete(w)
            }
            .setNeutralButton("Só a obra") { _, _ ->
                PageStore.mutate(this) { if (it.workId == w.id) it.workId = 0L }
                TermDb.get(this).moveWork(w.id, 0L)
                finishDelete(w)
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun finishDelete(w: Work) {
        lib.delete(w.id)
        if (sp.getLong("activeWork", 0L) == w.id) { sp.edit().putLong("activeWork", 0L).apply(); TermDb.activeWork = 0L }
        refresh(); loadStats()
    }
}
