package com.livescreentranslator

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class Work(val id: Long, val name: String, val type: String, val favorite: Boolean, val lastRead: Long, val notes: String)

/** Biblioteca de obras (mangás, manhwas, manhuas). Tudo fica só neste celular. */
class LibraryDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "lst_library.db", null, 1) {

    companion object {
        val TYPES = listOf("Mangá", "Manhwa", "Manhua", "Outro")
        @Volatile private var inst: LibraryDb? = null
        fun get(c: Context): LibraryDb = inst ?: synchronized(this) { inst ?: LibraryDb(c).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE works(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, type TEXT, favorite INTEGER DEFAULT 0, lastRead INTEGER DEFAULT 0, notes TEXT DEFAULT '', created INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized fun all(): List<Work> {
        val out = ArrayList<Work>()
        readableDatabase.rawQuery("SELECT id,name,type,favorite,lastRead,notes FROM works ORDER BY lastRead DESC, name", null).use { c ->
            while (c.moveToNext()) out += Work(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "Outro", c.getInt(3) == 1, c.getLong(4), c.getString(5) ?: "")
        }
        return out
    }

    fun byId(id: Long): Work? = all().firstOrNull { it.id == id }
    fun byName(name: String): Work? = all().firstOrNull { it.name.equals(name.trim(), ignoreCase = true) }

    @Synchronized fun add(name: String, type: String, notes: String): Long {
        val v = ContentValues()
        v.put("name", name.trim()); v.put("type", type); v.put("notes", notes); v.put("created", System.currentTimeMillis())
        return writableDatabase.insert("works", null, v)
    }

    @Synchronized fun update(id: Long, name: String, type: String, notes: String) {
        val v = ContentValues()
        v.put("name", name.trim()); v.put("type", type); v.put("notes", notes)
        writableDatabase.update("works", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized fun setFavorite(id: Long, fav: Boolean) {
        val v = ContentValues()
        v.put("favorite", if (fav) 1 else 0)
        writableDatabase.update("works", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized fun touch(id: Long) {
        val v = ContentValues()
        v.put("lastRead", System.currentTimeMillis())
        writableDatabase.update("works", v, "id=?", arrayOf(id.toString()))
    }

    @Synchronized fun delete(id: Long) {
        writableDatabase.delete("works", "id=?", arrayOf(id.toString()))
    }
}

/** Backup completo local: obras, dicionário e histórico de páginas. Não envia nada para servidores. */
object BackupHelper {

    fun export(c: Context): String {
        val o = JSONObject()
        o.put("app", "LiveScreenTranslator"); o.put("version", 2)
        val ws = JSONArray()
        for (w in LibraryDb.get(c).all()) {
            val j = JSONObject()
            j.put("id", w.id); j.put("name", w.name); j.put("type", w.type)
            j.put("favorite", w.favorite); j.put("notes", w.notes); j.put("lastRead", w.lastRead)
            ws.put(j)
        }
        o.put("works", ws)
        o.put("terms", JSONObject(TermDb.get(c).exportJson()).getJSONArray("terms"))
        o.put("pages", PageStore.toJson(PageStore.load(c)))
        return o.toString()
    }

    /** (obras, termos, páginas) que o arquivo contém. */
    fun summary(text: String): Triple<Int, Int, Int> {
        val o = JSONObject(text)
        return Triple(o.optJSONArray("works")?.length() ?: 0, o.optJSONArray("terms")?.length() ?: 0, o.optJSONArray("pages")?.length() ?: 0)
    }

    /** Junta o backup ao que já existe, sem apagar nada. Use só com a tradução parada. */
    fun import(c: Context, text: String): Triple<Int, Int, Int> {
        val o = JSONObject(text)
        val lib = LibraryDb.get(c)
        val idMap = HashMap<Long, Long>()
        var nw = 0
        val ws = o.optJSONArray("works") ?: JSONArray()
        for (i in 0 until ws.length()) {
            val j = ws.getJSONObject(i)
            val name = j.getString("name")
            val ex = lib.byName(name)
            val id = if (ex != null) ex.id else { nw++; lib.add(name, j.optString("type", "Outro"), j.optString("notes", "")) }
            idMap[j.getLong("id")] = id
        }
        var nt = 0
        val terms = o.optJSONArray("terms")
        if (terms != null) nt = TermDb.get(c).importJson(JSONObject().put("terms", terms).toString())
        val have = PageStore.load(c).toMutableList()
        var np = 0
        val pg = o.optJSONArray("pages")
        if (pg != null) for (p in PageStore.fromJson(pg)) {
            if (have.any { Tracker.fpDiff(it.fingerprint, p.fingerprint) < 6f && it.chapter == p.chapter }) continue
            p.workId = idMap[p.workId] ?: 0L
            have.add(p); np++
        }
        PageStore.save(c, have)
        return Triple(nw, nt, np)
    }
}
