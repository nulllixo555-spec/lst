package com.livescreentranslator

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.google.android.material.button.MaterialButton

/** Dicionário pessoal: termos, nomes, habilidades, lugares etc., globais ou separados por obra. */
class TermsActivity : FormActivity() {

    private lateinit var db: TermDb
    private lateinit var lib: LibraryDb
    private lateinit var listBox: LinearLayout
    private var kindFilter = 0
    private var scopeFilter = -1L       // -1 todos, 0 global, outro = id da obra
    private var query = ""
    private var works: List<Work> = emptyList()
    private val target: String get() = sp.getString("target", "pt") ?: "pt"

    private val exporter = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        val ok = runCatching {
            contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) }
        }.isSuccess
        Toast.makeText(this, if (ok) "Dicionário salvo" else "Não foi possível salvar", Toast.LENGTH_LONG).show()
    }

    private val importer = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val text = runCatching { contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull()
        val n = text?.let { runCatching { db.countJson(it) }.getOrNull() }
        if (text == null || n == null) {
            Toast.makeText(this, "Esse arquivo não é um dicionário válido", Toast.LENGTH_LONG).show()
            return@registerForActivityResult
        }
        AlertDialog.Builder(this).setTitle("Importar dicionário?")
            .setMessage("$n termos serão importados. Termos com o mesmo original e a mesma obra são atualizados; os demais ficam como estão. Obras que ainda não existem são criadas.")
            .setPositiveButton("Importar") { _, _ ->
                val done = runCatching { db.importJson(text) }.getOrDefault(0)
                Toast.makeText(this, "$done termos importados", Toast.LENGTH_SHORT).show()
                works = lib.all().sortedBy { it.name.lowercase() }
                refresh()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("Dicionário e memória")
        db = TermDb.get(this)
        lib = LibraryDb.get(this)
        works = lib.all().sortedBy { it.name.lowercase() }

        hint("Nomes e termos salvos aqui são usados em todas as próximas traduções, e a IA recebe estes dados como glossário. Dicionários de uma obra só valem enquanto ela estiver ativa; os globais valem sempre.")
        button("＋ Adicionar termo") { edit(null) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Exportar"; setOnClickListener { exporter.launch("dicionario-lst.json") }
        }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(4) })
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Importar"; setOnClickListener { importer.launch(arrayOf("*/*")) }
        }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(4) })
        content.addView(row)
        hint("Para compartilhar um dicionário, exporte e envie o arquivo. Quem receber importa e ganha os mesmos termos, já separados por obra.")

        spinnerRow("Dicionário", listOf("Todos", "Global (todas as obras)") + works.map { it.name }, 0) { pos ->
            scopeFilter = when (pos) { 0 -> -1L; 1 -> 0L; else -> works[pos - 2].id }
            refresh()
        }
        spinnerRow("Categoria", listOf("Todas") + TermDb.KINDS, 0) { kindFilter = it; refresh() }
        val search = EditText(this)
        search.hint = "Buscar…"; search.setTextColor(WHITE); search.setHintTextColor(MUTED)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { query = e.toString().trim(); refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        content.addView(search)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)
        refresh()
    }

    private fun workName(id: Long) = if (id == 0L) "Global" else (works.firstOrNull { it.id == id }?.name ?: "Obra removida")

    private fun refresh() {
        listBox.removeAllViews()
        val kind = if (kindFilter == 0) null else TermDb.KINDS[kindFilter - 1]
        val items = db.all().filter {
            (kind == null || it.kind == kind) && (scopeFilter == -1L || it.work == scopeFilter) &&
                (query.isEmpty() || it.source.contains(query, true) || it.target.contains(query, true) || it.notes.contains(query, true))
        }
        if (items.isEmpty()) {
            listBox.addView(label("Nada salvo aqui. Ao editar uma legenda, marque “Lembrar como termo”, ou toque em Adicionar.", 13f, MUTED).apply { setPadding(0, dp(16), 0, 0) })
            return
        }
        for (t in items) {
            val c = card(listBox)
            c.addView(label(t.kind.uppercase() + "  ·  " + workName(t.work) + if (t.tgtLang.isNotEmpty()) "  ·  → ${t.tgtLang}" else "", 11f, ACCENT))
            c.addView(label("${t.source}  →  ${t.target}", 16f).apply { setPadding(0, dp(4), 0, dp(4)) })
            if (t.notes.isNotBlank()) c.addView(label(t.notes, 12f, MUTED))
            c.addView(rowButtons(link("Editar") { edit(t) }, link("Excluir", 0xFFFF6B6B.toInt()) { confirmDelete(t) }))
        }
    }

    private fun confirmDelete(t: Term) {
        AlertDialog.Builder(this).setTitle("Excluir termo?").setMessage("${t.source} → ${t.target}")
            .setPositiveButton("Excluir") { _, _ -> db.delete(t.id); refresh() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun edit(t: Term?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val kindSp = Spinner(this)
        kindSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, TermDb.KINDS)
        kindSp.setSelection(t?.let { TermDb.KINDS.indexOf(it.kind) }?.coerceAtLeast(0) ?: 0)
        val workSp = Spinner(this)
        workSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Global (todas as obras)") + works.map { it.name })
        val defWork = t?.work ?: (if (scopeFilter > 0) scopeFilter else TermDb.activeWork)
        workSp.setSelection(works.indexOfFirst { it.id == defWork }.let { if (it < 0) 0 else it + 1 })
        val src = EditText(this).apply { hint = "Original (ex.: nome do personagem)"; setText(t?.source ?: "") }
        val tgt = EditText(this).apply { hint = "Como deve ser traduzido"; setText(t?.target ?: "") }
        val notes = EditText(this).apply { hint = "Observações (opcional: personalidade, relação…)"; setText(t?.notes ?: "") }
        box.addView(kindSp); box.addView(workSp); box.addView(src); box.addView(tgt); box.addView(notes)
        AlertDialog.Builder(this).setTitle(if (t == null) "Novo termo" else "Editar termo").setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val s = src.text.toString().trim()
                val g = tgt.text.toString().trim()
                if (s.isEmpty() || g.isEmpty()) {
                    Toast.makeText(this, "Preencha o original e a tradução", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val kind = TermDb.KINDS[kindSp.selectedItemPosition]
                val n = notes.text.toString().trim()
                val w = if (workSp.selectedItemPosition == 0) 0L else works[workSp.selectedItemPosition - 1].id
                if (t == null) db.upsert(kind, s, g, "", target, n, w) else db.update(t.id, kind, s, g, n, w)
                refresh()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
