package com.livescreentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** Um texto traduzido, na posição exata do original. */
data class TItem(val rect: Rect, val text: String, val bg: Int, val fg: Int)

/** Camada transparente que cobre só o texto original e desenha a tradução por cima. */
class OverlayView(context: Context) : View(context) {

    private class Drawn(val item: TItem, val layout: StaticLayout, val top: Float)

    private var drawn: List<Drawn> = emptyList()
    val currentRects: List<Rect> get() = drawn.map { it.item.rect }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.scaledDensity

    fun setItems(items: List<TItem>) {
        drawn = items.map { layoutFor(it) }
        invalidate()
    }

    fun clear() { drawn = emptyList(); invalidate() }

    private fun layoutFor(item: TItem): Drawn {
        val pad = 3
        val w = (item.rect.width() - pad * 2).coerceAtLeast(10)
        val h = (item.rect.height() - pad * 2).coerceAtLeast(10)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = item.fg; isFakeBoldText = false }
        var size = minOf(h.toFloat(), 22f * density)
        val min = 8f * density
        var layout: StaticLayout
        while (true) {
            paint.textSize = size
            layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, paint, w)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
            if (layout.height <= h || size <= min) break
            size -= 1.5f * density / 2
        }
        val top = item.rect.top + pad + ((h - layout.height) / 2f).coerceAtLeast(0f)
        return Drawn(item, layout, top)
    }

    override fun onDraw(canvas: Canvas) {
        for (d in drawn) {
            val r = d.item.rect
            bgPaint.color = d.item.bg
            canvas.drawRoundRect(RectF(r), 6f, 6f, bgPaint)
            canvas.save()
            canvas.clipRect(r)
            canvas.translate(r.left + 3f, d.top)
            d.layout.draw(canvas)
            canvas.restore()
        }
    }
}
