package com.livescreentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.graphics.ColorUtils
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await

class TranslatorService : Service() {

    enum class State { IDLE, RUNNING, PAUSED }

    companion object {
        const val ACTION_START = "start"; const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"; const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"; const val EXTRA_DATA = "data"; const val EXTRA_TARGET = "target"; const val EXTRA_SOURCE = "source"
        val state = MutableStateFlow(State.IDLE)
        private const val CHANNEL = "lst"
        private const val GRID_W = 24
        private const val GRID_H = 48
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var screenW = 0
    private var screenH = 0
    private var lastFrame: Bitmap? = null

    private var target = TranslateLanguage.PORTUGUESE
    private var sourceMode = "en"
    private val cache = HashMap<String, String>()          // "src>texto" -> tradução (evita retraduzir)
    private val translators = HashMap<String, Translator>()
    private val modelLock = Mutex()
    private var prevSig: IntArray? = null

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val jp by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent)
            ACTION_PAUSE -> { state.value = State.PAUSED; overlay?.clear(); prevSig = null; notify(true) }
            ACTION_RESUME -> { state.value = State.RUNNING; prevSig = null; notify(false) }
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- início

    private fun begin(intent: Intent) {
        createChannel()
        val n = buildNotification(false)
        if (Build.VERSION.SDK_INT >= 29)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        target = intent.getStringExtra(EXTRA_TARGET) ?: TranslateLanguage.PORTUGUESE
        sourceMode = intent.getStringExtra(EXTRA_SOURCE) ?: "en"
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION") val data: Intent = intent.getParcelableExtra(EXTRA_DATA) ?: return shutdown()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { shutdown() } }
            }, main)
        }

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels; screenH = dm.heightPixels

        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "lst", screenW, screenH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )

        overlay = OverlayView(this).also {
            val lp = WindowManager.LayoutParams(
                screenW, screenH,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28)
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            wm.addView(it, lp)
        }

        state.value = State.RUNNING
        // Baixa os modelos de tradução já no início, para a primeira tradução não esperar.
        scope.launch {
            val first = when (sourceMode) { "ja" -> "ja"; "zh" -> "zh"; "ko" -> "ko"; "id" -> "id"; else -> "en" }
            translatorFor(first); if (first != "en") translatorFor("en")
        }
        job = scope.launch {
            while (isActive) {
                if (state.value == State.RUNNING) runCatching { cycle() }
                delay(350)
            }
        }
    }

    // ------------------------------------------------------------- ciclo

    private suspend fun cycle() {
        val frame = grab() ?: return
        val ov = overlay ?: return
        val rects = withContext(Dispatchers.Main) { ov.currentRects }
        val sig = signature(frame, rects)
        val prev = prevSig
        prevSig = sig
        if (prev != null && !changed(prev, sig)) return           // nada mudou
        if (prev == null && rects.isNotEmpty()) return            // só define a referência

        // A tela mudou: remove a camada por um instante para o OCR ler o texto original.
        withContext(Dispatchers.Main) { ov.clear() }
        delay(120)
        val clean = grab() ?: frame

        val scale = if (clean.width > 800) 800f / clean.width else 1f
        val small = if (scale < 1f) Bitmap.createScaledBitmap(clean, 800, (clean.height * scale).toInt(), true) else clean
        val blocks = recognize(small).map { (r, t) ->
            Rect((r.left / scale).toInt(), (r.top / scale).toInt(), (r.right / scale).toInt(), (r.bottom / scale).toInt()) to t
        }
        val items = ArrayList<TItem>()
        val lock = Mutex()
        coroutineScope {
            blocks.map { (rect, text) ->
                async {
                    val it = translateBlock(clean, rect, text) ?: return@async
                    lock.withLock {
                        items += it
                        val snap = items.toList()
                        withContext(Dispatchers.Main) { if (state.value == State.RUNNING) ov.setItems(snap) }
                    }
                }
            }.awaitAll()
        }
        prevSig = if (items.isEmpty()) signature(clean, emptyList()) else null
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return lastFrame
        img.use {
            val p = it.planes[0]
            val pad = p.rowStride - p.pixelStride * screenW
            val full = Bitmap.createBitmap(screenW + pad / p.pixelStride, screenH, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            val bmp = Bitmap.createBitmap(full, 0, 0, screenW, screenH)
            if (full !== bmp) full.recycle()
            lastFrame = bmp
            return bmp
        }
    }

    // Assinatura de baixa resolução; células cobertas pelo overlay são ignoradas (-1).
    private fun signature(b: Bitmap, covered: List<Rect>): IntArray {
        val s = Bitmap.createScaledBitmap(b, GRID_W, GRID_H, true)
        val out = IntArray(GRID_W * GRID_H)
        for (y in 0 until GRID_H) for (x in 0 until GRID_W) {
            val c = s.getPixel(x, y)
            out[y * GRID_W + x] = ((c shr 16 and 255) * 3 + (c shr 8 and 255) * 6 + (c and 255)) / 10
        }
        s.recycle()
        for (r in covered) {
            val x0 = r.left * GRID_W / screenW; val x1 = (r.right * GRID_W / screenW).coerceAtMost(GRID_W - 1)
            val y0 = r.top * GRID_H / screenH; val y1 = (r.bottom * GRID_H / screenH).coerceAtMost(GRID_H - 1)
            for (y in y0..y1) for (x in x0..x1) out[y * GRID_W + x] = -1
        }
        return out
    }

    private fun changed(a: IntArray, b: IntArray): Boolean {
        var valid = 0; var diff = 0
        for (i in a.indices) {
            if (a[i] < 0 || b[i] < 0) continue
            valid++
            if (kotlin.math.abs(a[i] - b[i]) > 24) diff++
        }
        return valid == 0 || diff.toFloat() / valid > 0.03f
    }

    // --------------------------------------------------------------- OCR

    private fun isCjk(c: Char) = c in '\u3040'..'\u30ff' || c in '\u4e00'..'\u9fff' || c in '\uac00'..'\ud7af'
    private fun letters(s: String) = s.count { it.isLetter() }

    private suspend fun recognize(bmp: Bitmap): List<Pair<Rect, String>> = coroutineScope {
        val img = InputImage.fromBitmap(bmp, 0)
        val auto = sourceMode == "auto"
        val recs = when (sourceMode) {
            "auto" -> listOf(ko to true, jp to true, zh to true, latin to false)
            "ja" -> listOf(jp to true)
            "zh" -> listOf(zh to true)
            "ko" -> listOf(ko to true)
            else -> listOf(latin to false)
        }
        val rs = recs.map { (r, _) -> async { runCatching { r.process(img).await() }.getOrNull() } }.awaitAll()
        val cand = ArrayList<Pair<Rect, String>>()
        rs.forEachIndexed { idx, t ->
            t?.textBlocks?.forEach { b ->
                val box = b.boundingBox ?: return@forEach
                val txt = b.text.replace("\n", " ").trim()
                if (letters(txt) < 2) return@forEach
                if (auto) {
                    val share = txt.count { isCjk(it) }.toFloat() / txt.length
                    if (if (recs[idx].second) share >= 0.3f else share < 0.3f) cand += box to txt
                } else cand += box to txt
            }
        }
        val kept = ArrayList<Pair<Rect, String>>()
        for (c in cand) {
            val area = c.first.width().toLong() * c.first.height()
            val dup = kept.any { k ->
                val i = Rect(k.first)
                i.intersect(c.first) && i.width().toLong() * i.height() > area * 0.4
            }
            if (!dup) kept += c
        }
        kept
    }

    // ----------------------------------------------------------- tradução

    private suspend fun sourceLang(text: String): String? {
        if (text.any { it in '\uac00'..'\ud7af' }) return TranslateLanguage.KOREAN
        if (text.any { it in '\u3040'..'\u30ff' }) return TranslateLanguage.JAPANESE
        if (text.any { it in '\u4e00'..'\u9fff' }) return TranslateLanguage.CHINESE
        when (sourceMode) {
            "id" -> return TranslateLanguage.INDONESIAN
            "en", "ja", "zh", "ko" -> return TranslateLanguage.ENGLISH   // sem CJK = inglês
        }
        val code = runCatching { langId.identifyLanguage(text).await() }.getOrNull() ?: return null
        return if (code == "und") TranslateLanguage.ENGLISH else TranslateLanguage.fromLanguageTag(code)
    }

    private suspend fun translateBlock(bmp: Bitmap, rect: Rect, text: String): TItem? {
        val src = sourceLang(text) ?: return null
        if (src == target) return null
        val key = "$src>$text"
        val out = cache[key] ?: run {
            val tr = translatorFor(src) ?: return null
            runCatching { tr.translate(text).await() }.getOrNull()?.also { cache[key] = it } ?: return null
        }
        if (out.equals(text, true)) return null
        val bg = sampleBackground(bmp, rect)
        val fg = if (ColorUtils.calculateLuminance(bg) > 0.45) 0xFF111111.toInt() else 0xFFF5F5F5.toInt()
        val r = Rect(rect).apply { inset(-2, -2) }
        r.intersect(0, 0, screenW, screenH)
        return TItem(r, out, bg, fg)
    }

    private suspend fun translatorFor(src: String): Translator? = modelLock.withLock {
        val k = "$src>$target"
        translators[k]?.let { return it }
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(target).build())
        val ok = runCatching { t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await() }.isSuccess
        if (ok) { translators[k] = t; t } else { t.close(); null }
    }

    // Cor de fundo: média de pixels logo fora da caixa do texto.
    private fun sampleBackground(b: Bitmap, r: Rect): Int {
        var rs = 0; var gs = 0; var bs = 0; var n = 0
        fun px(x: Int, y: Int) {
            val c = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))
            rs += c shr 16 and 255; gs += c shr 8 and 255; bs += c and 255; n++
        }
        val steps = 8
        for (i in 0..steps) {
            val x = r.left + r.width() * i / steps; val y = r.top + r.height() * i / steps
            px(x, r.top - 3); px(x, r.bottom + 3); px(r.left - 3, y); px(r.right + 3, y)
        }
        return 0xFF shl 24 or (rs / n shl 16) or (gs / n shl 8) or (bs / n)
    }

    // ------------------------------------------------------- notificação

    private fun createChannel() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Tradução", NotificationManager.IMPORTANCE_LOW))
    }

    private fun act(a: String, label: String) = NotificationCompat.Action(
        0, label, PendingIntent.getService(this, a.hashCode(),
            Intent(this, TranslatorService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE))

    private fun buildNotification(paused: Boolean): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Live Screen Translator")
            .setContentText(if (paused) "Pausado" else "Traduzindo a tela…")
            .setOngoing(true)
            .addAction(if (paused) act(ACTION_RESUME, "Retomar") else act(ACTION_PAUSE, "Pausar"))
            .addAction(act(ACTION_STOP, "Encerrar"))
            .build()

    private fun notify(paused: Boolean) =
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification(paused))

    // ---------------------------------------------------------- encerrar

    private fun shutdown() {
        job?.cancel()
        overlay?.let { v -> runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } }
        overlay = null
        display?.release(); reader?.close(); projection?.stop()
        translators.values.forEach { it.close() }; translators.clear()
        state.value = State.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
