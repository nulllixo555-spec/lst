# Live Screen Translator

1. Abra esta pasta no Android Studio (Koala ou mais novo) e aguarde o Gradle sincronizar.
2. Rode em um aparelho real (Android 8+; MediaProjection não funciona bem em emulador).
3. Toque em "Iniciar tradução", permita sobreposição, notificações e captura de tela.

Pausar/retomar/encerrar também estão na notificação.
Os modelos de tradução (~30 MB por idioma) são baixados na primeira vez que cada idioma aparece.
