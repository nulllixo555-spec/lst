package com.livescreentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Um texto traduzido, na posição do original. */
data class TItem(val rect: Rect, val text: String, val bg: Int, val fg: Int)

/** Camada transparente que cobre o texto original e desenha a tradução com o estilo escolhido. */
class OverlayView(context: Context) : View(context) {

    private class Drawn(
        var box: RectF, val fill: StaticLayout, val stroke: StaticLayout?,
        var textTop: Float, val pad: Float, val bg: Int, val born: Long, val ttl: Long
    )

    private val FOREVER = Long.MAX_VALUE / 4
    private var lastItems: List<TItem> = emptyList()
    private var drawn: List<Drawn> = emptyList()
    private val births = HashMap<String, Long>()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    var previewMode = false
    var onAllExpired: (() -> Unit)? = null

    var style: SubStyle = SubStyle()
        set(v) {
            field = v
            setLayerType(if (v.shadow) LAYER_TYPE_SOFTWARE else LAYER_TYPE_NONE, null)
            if (lastItems.isNotEmpty()) { drawn = build(lastItems); invalidate() }
        }

    val currentRects: List<Rect>
        get() = drawn.map { Rect(it.box.left.toInt(), it.box.top.toInt(), it.box.right.toInt(), it.box.bottom.toInt()) }

    fun setItems(items: List<TItem>) { lastItems = items; drawn = build(items); invalidate() }

    fun clear() { lastItems = emptyList(); drawn = emptyList(); births.clear(); invalidate() }

    // ------------------------------------------------------------ montagem

    private fun layouts(text: String, innerW: Int, innerH: Int, shrink: Boolean, start: Float, tf: Typeface, fg: Int): Pair<StaticLayout, StaticLayout?> {
        val s = style
        val dm = resources.displayMetrics
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = tf; color = fg; isUnderlineText = s.underline; letterSpacing = s.letterSpacing
        }
        val t = if (s.wrap) text else text.replace('\n', ' ')
        val align = when (s.align) {
            0 -> Layout.Alignment.ALIGN_NORMAL
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_CENTER
        }
        fun mk(size: Float): StaticLayout {
            paint.textSize = size
            val w = if (s.wrap) innerW else ceil(paint.measureText(t)).toInt().coerceAtLeast(1)
            return StaticLayout.Builder.obtain(t, 0, t.length, paint, w)
                .setAlignment(align).setIncludePad(false).setLineSpacing(0f, s.lineSpacing).build()
        }
        fun fits(l: StaticLayout) = if (s.wrap) l.height <= innerH else l.width <= innerW

        val minSize = 7f * dm.scaledDensity
        var size = start
        var layout = mk(size)
        while (shrink && size > minSize && !fits(layout)) {
            size -= max(1f, size * 0.06f)
            layout = mk(size)
        }
        var stroke: StaticLayout? = null
        if (s.outline) {
            val p2 = TextPaint(paint).apply {
                style = Paint.Style.STROKE; strokeWidth = s.outlineDp * dm.density
                color = s.outlineColor; strokeJoin = Paint.Join.ROUND
            }
            stroke = StaticLayout.Builder.obtain(t, 0, t.length, p2, layout.width)
                .setAlignment(align).setIncludePad(false).setLineSpacing(0f, s.lineSpacing).build()
        }
        return layout to stroke
    }

    private fun build(items: List<TItem>): List<Drawn> {
        val s = style
        val dm = resources.displayMetrics
        val d = dm.density
        val sd = dm.scaledDensity
        val w = if (width > 0) width else dm.widthPixels
        val h = if (height > 0) height else dm.heightPixels
        val tf = FontResolver.resolve(context, s.font, s.bold, s.italic)
        val pad = s.paddingDp * d
        val stack = s.position != 0
        val now = SystemClock.uptimeMillis()
        val live = HashSet<String>()
        val list = ArrayList<Drawn>()

        for (item in items.sortedBy { it.rect.top }) {
            val key = "${item.rect.left},${item.rect.top},${item.text}"
            live += key
            val born = births.getOrPut(key) { now }
            val r = item.rect

            val bw = if (stack) (w * 0.92f * s.widthPct / 100f).coerceIn(80f * d, w.toFloat())
                     else r.width() * s.widthPct / 100f
            val bh0 = if (stack) 0f else r.height() * s.heightPct / 100f
            val innerW = (bw - 2 * pad).toInt().coerceAtLeast(10)
            val innerH = if (stack) Int.MAX_VALUE / 4 else (bh0 - 2 * pad).toInt().coerceAtLeast(10)
            val shrink = s.autoSize && !stack
            val start = if (s.autoSize && !stack) min(innerH.toFloat(), 22f * sd)
                        else (if (s.autoSize) 18f else s.textSizeSp) * sd

            val under = if (!s.bgEnabled || s.bgAuto) item.bg else s.bgColor
            val fg = if (s.textColorAuto)
                (if (ColorUtils.calculateLuminance(under) > 0.45) 0xFF111111.toInt() else 0xFFF5F5F5.toInt())
            else s.textColor

            val (fill, stroke) = layouts(item.text, innerW, innerH, shrink, start, tf, fg)
            val bh = if (stack) fill.height + 2 * pad else bh0
            val box = if (stack) RectF(0f, 0f, bw, bh) else {
                val cx = r.centerX() + s.offsetXDp * d
                val cy = r.centerY() + s.offsetYDp * d
                RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)
            }

            val ttl = if (previewMode || s.keepWhileStatic) FOREVER else {
                val raw = if (s.durationAuto) item.text.length * s.msPerChar else s.fixedMs
                raw.coerceIn(s.minMs, max(s.minMs, s.maxMs))
            }
            list += Drawn(box, fill, stroke, 0f, pad, if (s.bgAuto) item.bg else s.bgColor, born, ttl)
        }

        if (stack && list.isNotEmpty()) {
            val gap = 6 * d
            val total = list.sumOf { it.box.height().toDouble() }.toFloat() + gap * (list.size - 1)
            var y = when (s.position) {
                1 -> h - total - 72 * d
                2 -> 56 * d
                else -> (h - total) / 2f
            } + s.offsetYDp * d
            for (dr in list) {
                val bw = dr.box.width()
                val bh = dr.box.height()
                val x = (w - bw) / 2f + s.offsetXDp * d
                dr.box = RectF(x, y, x + bw, y + bh)
                y += bh + gap
            }
        }
        for (dr in list) {
            dr.textTop = dr.box.top + dr.pad + max(0f, (dr.box.height() - 2 * dr.pad - dr.fill.height) / 2f)
        }
        births.keys.retainAll(live)
        return list
    }

    // ------------------------------------------------------------ desenho

    override fun onDraw(canvas: Canvas) {
        if (drawn.isEmpty()) return
        val s = style
        val d = resources.displayMetrics.density
        val now = SystemClock.uptimeMillis()
        var alive = false
        var fading = false
        var finite = false

        for (dr in drawn) {
            val age = now - dr.born
            if (age >= dr.ttl) continue
            alive = true
            if (dr.ttl < FOREVER) finite = true
            var a = 1f
            if (s.anim != 0) {
                if (s.fadeInMs > 0 && age < s.fadeInMs) { a = age.toFloat() / s.fadeInMs; fading = true }
                val left = dr.ttl - age
                if (s.fadeOutMs > 0 && left < s.fadeOutMs) { a = min(a, left.toFloat() / s.fadeOutMs); fading = true }
            }
            drawOne(canvas, dr, a.coerceIn(0f, 1f), s, d)
        }

        if (!alive) {
            drawn = emptyList(); lastItems = emptyList(); births.clear()
            post { onAllExpired?.invoke() }
        } else if (fading) postInvalidateOnAnimation()
        else if (finite) postInvalidateDelayed(100)
    }

    private fun drawOne(c: Canvas, dr: Drawn, a: Float, s: SubStyle, d: Float) {
        val m = 14 * d
        val save = c.saveLayerAlpha(dr.box.left - m, dr.box.top - m, dr.box.right + m, dr.box.bottom + m, (a * 255).toInt())
        when (s.anim) {
            2 -> c.translate(0f, (1f - a) * 18 * d)
            3 -> { val sc = 0.85f + 0.15f * a; c.scale(sc, sc, dr.box.centerX(), dr.box.centerY()) }
        }
        val cr = s.cornerDp * d
        if (s.bgEnabled) {
            bgPaint.style = Paint.Style.FILL
            bgPaint.color = ColorUtils.setAlphaComponent(dr.bg, s.bgAlpha * 255 / 100)
            if (s.shadow) bgPaint.setShadowLayer(8 * d, 0f, 3 * d, 0x99000000.toInt()) else bgPaint.clearShadowLayer()
            c.drawRoundRect(dr.box, cr, cr, bgPaint)
            bgPaint.clearShadowLayer()
            if (s.borderDp > 0) {
                val bw = s.borderDp * d
                borderPaint.style = Paint.Style.STROKE
                borderPaint.strokeWidth = bw
                borderPaint.color = s.borderColor
                val rr = RectF(dr.box)
                rr.inset(bw / 2, bw / 2)
                c.drawRoundRect(rr, cr, cr, borderPaint)
            }
        }
        c.save()
        c.clipRect(dr.box)
        val innerW = dr.box.width() - 2 * dr.pad
        val ox = when (s.align) {
            0 -> 0f
            2 -> innerW - dr.fill.width
            else -> (innerW - dr.fill.width) / 2f
        }
        c.translate(dr.box.left + dr.pad + max(0f, ox), dr.textTop)
        dr.stroke?.draw(c)
        dr.fill.draw(c)
        c.restore()
        c.restoreToCount(save)
    }
}
