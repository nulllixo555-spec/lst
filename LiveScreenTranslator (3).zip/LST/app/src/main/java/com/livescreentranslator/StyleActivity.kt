package com.livescreentranslator

import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.button.MaterialButton
import java.io.File
import java.util.Locale

class StyleActivity : AppCompatActivity() {

    private lateinit var st: SubStyle
    private lateinit var content: LinearLayout
    private lateinit var preview: OverlayView
    private val WHITE = 0xFFFFFFFF.toInt()
    private val MUTED = 0xFF9AA0C8.toInt()
    private val ACCENT = 0xFF6C63FF.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val SAMPLE = "Olá! Esta é uma legenda de exemplo.\nこんにちは 안녕하세요 你好"

    private val fontPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val raw = contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else null
        } ?: "fonte_${System.currentTimeMillis()}.ttf"
        val name = raw.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (name.substringAfterLast('.').lowercase() !in listOf("ttf", "otf", "ttc")) {
            Toast.makeText(this, "Escolha um arquivo .ttf ou .otf", Toast.LENGTH_LONG).show(); return@registerForActivityResult
        }
        val out = File(File(filesDir, "fonts").apply { mkdirs() }, name)
        contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        val ok = runCatching { Typeface.createFromFile(out) }.isSuccess
        if (!ok) { out.delete(); Toast.makeText(this, "Não foi possível ler essa fonte", Toast.LENGTH_LONG).show(); return@registerForActivityResult }
        st.font = "file:${out.absolutePath}"
        changed(); build()
        Toast.makeText(this, "Fonte importada e selecionada", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        st = SubStyle.load(this)

        val rootL = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rootL.addView(label("Personalizar Legendas", 20f).apply {
            typeface = Typeface.DEFAULT_BOLD; setPadding(dp(20), dp(16), dp(20), dp(10))
        })
        val frame = FrameLayout(this).apply { setBackgroundColor(0xFFE8E8E8.toInt()) }
        frame.addView(TextView(this).apply {
            text = "Texto original (será coberto)"; setTextColor(0xFF222222.toInt()); gravity = Gravity.CENTER; textSize = 16f
        }, FrameLayout.LayoutParams(MATCH, MATCH))
        preview = OverlayView(this).apply { previewMode = true }
        frame.addView(preview, FrameLayout.LayoutParams(MATCH, MATCH))
        rootL.addView(frame, LinearLayout.LayoutParams(MATCH, dp(190)))

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), dp(40)) }
        val sv = ScrollView(this).apply { addView(content) }
        rootL.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(rootL)

        build()
        frame.post { refreshPreview() }
    }

    // ---------------------------------------------------------------- util

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, color: Int = WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }

    private fun refreshPreview() {
        if (preview.width == 0) { preview.post { refreshPreview() }; return }
        val w = preview.width
        val d = resources.displayMetrics.density
        preview.style = st
        preview.setItems(listOf(TItem(Rect((24 * d).toInt(), (60 * d).toInt(), w - (24 * d).toInt(), (120 * d).toInt()),
            SAMPLE, 0xFFE8E8E8.toInt(), 0xFF111111.toInt())))
    }

    private fun changed() {
        st.save(this)
        refreshPreview()
        TranslatorService.reloadHook?.invoke()
    }

    private fun header(t: String) {
        content.addView(label(t, 13f, ACCENT).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(26), 0, dp(4)) })
    }

    private fun hint(t: String) { content.addView(label(t, 12f, MUTED)) }

    private fun switchRow(title: String, get: () -> Boolean, set: (Boolean) -> Unit, rebuild: Boolean = false) {
        content.addView(SwitchCompat(this).apply {
            text = title; setTextColor(WHITE); isChecked = get(); setPadding(0, dp(10), 0, dp(10))
            setOnCheckedChangeListener { _, v -> set(v); changed(); if (rebuild) build() }
        })
    }

    private fun sliderRow(title: String, lo: Int, hi: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String = { "$it" }) {
        val tv = label("$title: ${fmt(get())}").apply { setPadding(0, dp(10), 0, 0) }
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (get() - lo).coerceIn(0, hi - lo)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                tv.text = "$title: ${fmt(v)}"
                if (fromUser) { set(v); changed() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        content.addView(tv); content.addView(sb)
    }

    private fun spinnerRow(title: String, options: List<String>, selected: Int, onSel: (Int) -> Unit) {
        content.addView(label(title).apply { setPadding(0, dp(10), 0, 0) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        sp.setSelection(selected.coerceAtLeast(0))
        var first = true
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) { first = false; return }
                onSel(pos); changed()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        content.addView(sp, LinearLayout.LayoutParams(MATCH, dp(52)))
    }

    private fun fmtT(ms: Long): String =
        if (st.unitSeconds) String.format(Locale.US, "%.3f", ms / 1000.0).trimEnd('0').trimEnd('.') else ms.toString()

    private fun timeRow(title: String, get: () -> Long, set: (Long) -> Unit) {
        val unit = if (st.unitSeconds) "segundos" else "milissegundos"
        content.addView(label("$title ($unit)").apply { setPadding(0, dp(10), 0, 0) })
        val et = EditText(this)
        et.setTextColor(WHITE)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        et.setText(fmtT(get()))
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) {
                val v = e.toString().replace(',', '.').toDoubleOrNull() ?: return
                set(if (st.unitSeconds) (v * 1000).toLong() else v.toLong())
                changed()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        content.addView(et)
    }

    private fun colorRow(title: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        val tv = label(title).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
        val sw = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(56), dp(30)); setBackgroundColor(get()) }
        row.addView(tv); row.addView(sw)
        row.setOnClickListener { pickColor(get()) { c -> set(c); sw.setBackgroundColor(c); changed() } }
        content.addView(row)
    }

    private fun pickColor(initial: Int, cb: (Int) -> Unit) {
        val colors = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFF5F5F5.toInt(), 0xFF212121.toInt(), 0xFFFF5252.toInt(), 0xFFFF9800.toInt(),
            0xFFFFEB3B.toInt(), 0xFF4CAF50.toInt(), 0xFF00BCD4.toInt(), 0xFF2196F3.toInt(), 0xFF6C63FF.toInt(), 0xFFE91E63.toInt(),
            0xFF795548.toInt(), 0xFF9E9E9E.toInt(), 0xFFFFF3C4.toInt(), 0xFF1A1E3C.toInt(), 0xFF00E676.toInt(), 0xFFB388FF.toInt()
        )
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val hex = EditText(this).apply { setText(String.format("#%06X", initial and 0xFFFFFF)) }
        var dialog: AlertDialog? = null
        for (r in colors.toList().chunked(6)) {
            val line = LinearLayout(this)
            for (c in r) {
                val v = View(this)
                v.setBackgroundColor(c)
                v.setOnClickListener { cb(c); dialog?.dismiss() }
                line.addView(v, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            box.addView(line)
        }
        box.addView(label("Ou digite um código (#RRGGBB):", 12f, MUTED).apply { setPadding(0, dp(10), 0, 0) })
        box.addView(hex)
        dialog = AlertDialog.Builder(this).setTitle("Escolher cor").setView(box)
            .setPositiveButton("OK") { _, _ -> runCatching { cb(Color.parseColor(hex.text.toString().trim())) } }
            .setNegativeButton("Cancelar", null).create()
        dialog.show()
    }

    private fun button(title: String, outlined: Boolean = false, onClick: () -> Unit) {
        val b = if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle) else MaterialButton(this)
        b.text = title
        b.setOnClickListener { onClick() }
        content.addView(b, LinearLayout.LayoutParams(MATCH, dp(54)).apply { topMargin = dp(12) })
    }

    // -------------------------------------------------------------- telas

    private fun build() {
        content.removeAllViews()

        header("TEXTO")
        switchRow("Cor das letras automática (contraste com o fundo)", { st.textColorAuto }, { st.textColorAuto = it })
        colorRow("Cor das letras", { st.textColor }, { st.textColor = it })
        switchRow("Tamanho da fonte automático (ajusta à caixa)", { st.autoSize }, { st.autoSize = it })
        sliderRow("Tamanho da fonte", 8, 48, { st.textSizeSp.toInt() }, { st.textSizeSp = it.toFloat() }, { "$it sp" })

        val fonts = (FontResolver.presets + FontResolver.importedFonts(this) + FontResolver.installedFonts()).distinctBy { it.second }
        spinnerRow("Fonte", fonts.map { it.first }, fonts.indexOfFirst { it.second == st.font }) { st.font = fonts[it].second }
        hint("Japonês, coreano e chinês sempre usam a fonte de reserva do Android quando a escolhida não tem o caractere.")
        button("Importar fonte (TTF ou OTF)", outlined = true) { fontPicker.launch(arrayOf("*/*")) }

        switchRow("Negrito", { st.bold }, { st.bold = it })
        switchRow("Itálico", { st.italic }, { st.italic = it })
        switchRow("Sublinhado", { st.underline }, { st.underline = it })
        sliderRow("Espaçamento entre letras", -5, 40, { (st.letterSpacing * 100).toInt() }, { st.letterSpacing = it / 100f },
            { String.format(Locale.US, "%.2f em", it / 100f) })
        sliderRow("Espaçamento entre linhas", 80, 250, { (st.lineSpacing * 100).toInt() }, { st.lineSpacing = it / 100f },
            { String.format(Locale.US, "%.2fx", it / 100f) })
        spinnerRow("Alinhamento", listOf("Esquerda", "Centro", "Direita"), st.align) { st.align = it }
        sliderRow("Largura da legenda", 30, 250, { st.widthPct }, { st.widthPct = it }, { "$it%" })
        sliderRow("Altura da legenda", 30, 250, { st.heightPct }, { st.heightPct = it }, { "$it%" })
        switchRow("Quebra automática de linhas", { st.wrap }, { st.wrap = it })

        header("FUNDO")
        switchRow("Mostrar fundo", { st.bgEnabled }, { st.bgEnabled = it })
        hint("Sem fundo, o texto original continua visível por baixo da tradução.")
        switchRow("Cor igual ao fundo original", { st.bgAuto }, { st.bgAuto = it })
        colorRow("Cor do fundo", { st.bgColor }, { st.bgColor = it })
        sliderRow("Transparência do fundo", 0, 100, { 100 - st.bgAlpha }, { st.bgAlpha = 100 - it }, { "$it%" })
        sliderRow("Bordas arredondadas", 0, 40, { st.cornerDp }, { st.cornerDp = it }, { "$it dp" })
        sliderRow("Espessura da borda", 0, 8, { st.borderDp }, { st.borderDp = it }, { "$it dp" })
        colorRow("Cor da borda", { st.borderColor }, { st.borderColor = it })
        switchRow("Sombra no fundo", { st.shadow }, { st.shadow = it })
        switchRow("Contorno no texto", { st.outline }, { st.outline = it })
        colorRow("Cor do contorno", { st.outlineColor }, { st.outlineColor = it })
        sliderRow("Espessura do contorno", 1, 6, { st.outlineDp }, { st.outlineDp = it }, { "$it dp" })
        sliderRow("Distância entre texto e bordas", 0, 24, { st.paddingDp }, { st.paddingDp = it }, { "$it dp" })

        header("DURAÇÃO")
        switchRow("Manter a legenda enquanto a tela não mudar", { st.keepWhileStatic }, { st.keepWhileStatic = it })
        hint("Ligado: a legenda fica até a tela mudar. Desligue para ela sumir sozinha pelos tempos abaixo.")
        switchRow("Duração automática pelo tamanho da frase", { st.durationAuto }, { st.durationAuto = it })
        switchRow("Mostrar tempos em segundos (desligado = milissegundos)", { st.unitSeconds }, { st.unitSeconds = it }, rebuild = true)
        timeRow("Duração fixa", { st.fixedMs }, { st.fixedMs = it })
        timeRow("Tempo mínimo de exibição", { st.minMs }, { st.minMs = it })
        timeRow("Tempo máximo de exibição", { st.maxMs }, { st.maxMs = it })
        timeRow("Tempo de leitura por caractere", { st.msPerChar }, { st.msPerChar = it })
        timeRow("Velocidade de aparecimento", { st.fadeInMs }, { st.fadeInMs = it })
        timeRow("Velocidade de desaparecimento", { st.fadeOutMs }, { st.fadeOutMs = it })
        spinnerRow("Animação de entrada e saída", listOf("Nenhuma", "Aparecer (fade)", "Deslizar", "Zoom"), st.anim) { st.anim = it }

        header("POSIÇÃO")
        spinnerRow("Onde mostrar", listOf("Sobre o texto original", "Fixa na parte de baixo", "Fixa no topo", "Fixa no centro"), st.position) { st.position = it }
        sliderRow("Deslocamento horizontal", -200, 200, { st.offsetXDp }, { st.offsetXDp = it }, { "$it dp" })
        sliderRow("Deslocamento vertical", -200, 200, { st.offsetYDp }, { st.offsetYDp = it }, { "$it dp" })

        button("Testar animação") { preview.clear(); refreshPreview() }
        button("Restaurar padrões", outlined = true) {
            st = SubStyle(); st.save(this); build(); refreshPreview(); TranslatorService.reloadHook?.invoke()
        }
    }
}
