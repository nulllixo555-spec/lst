# Live Screen Translator

Abra no Android Studio (ou compile pelo GitHub Actions) e rode em um aparelho real (Android 8+).
Veja o app: Iniciar tradução > botão flutuante 👆 para tocar nas legendas > Personalizar legendas > Memória de correções.
