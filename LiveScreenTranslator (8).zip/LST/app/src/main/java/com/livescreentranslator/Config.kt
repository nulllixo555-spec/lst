package com.livescreentranslator

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Chaves das configurações (SharedPreferences "lst"). */
object K {
    const val ENGINE = "engineMode"; const val QUALITY = "quality"; const val CTX = "ctxSize"
    const val MODEL = "claudeModel"; const val CONSENT = "consent"; const val STYLE = "style"
    const val LANGENG = "langEngines"; const val POWER = "power"; const val BALLOON = "balloon"
    const val G_TAP = "g_tap"; const val G_DOUBLE = "g_double"; const val G_LONG = "g_long"
    const val G_TWO = "g_two"; const val G_BUBBLE = "g_bubble"; const val WIFI = "wifiOnly"
}

/** Chaves de API guardadas criptografadas (Android Keystore). Nunca ficam no código nem em backups. */
object Secrets {
    private val mem = HashMap<String, String>()

    private fun prefs(c: Context) = EncryptedSharedPreferences.create(
        c.applicationContext, "lst_secrets",
        MasterKey.Builder(c.applicationContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Synchronized fun get(c: Context, name: String): String {
        mem[name]?.let { return it }
        val v = runCatching { prefs(c).getString(name, "") ?: "" }.getOrDefault("")
        mem[name] = v
        return v
    }

    @Synchronized fun set(c: Context, name: String, value: String) {
        mem[name] = value
        runCatching { prefs(c).edit().putString(name, value).apply() }
    }
}

object LangNames {
    fun name(code: String) = when (code) {
        "pt" -> "português do Brasil"; "en" -> "inglês"; "es" -> "espanhol"; "fr" -> "francês"
        "de" -> "alemão"; "it" -> "italiano"; "ja" -> "japonês"; "ko" -> "coreano"
        "zh" -> "chinês"; "id" -> "indonésio"; else -> code
    }
}

/** Estilos de tradução (valem para a IA; o tradutor offline não aceita instruções de estilo). */
object TStyles {
    val list = listOf(
        "literal" to "Literal", "natural" to "Natural", "contextual" to "Contextual",
        "comic" to "Adaptada para quadrinhos", "formal" to "Formal", "informal" to "Informal"
    )

    fun label(key: String?) = list.firstOrNull { it.first == key }?.second ?: "Natural"

    fun instruction(key: String): String = when (key) {
        "literal" -> "Tradução literal: fiel às palavras e à estrutura do original, sem adaptar expressões."
        "contextual" -> "Tradução contextual: use todo o contexto para escolher o sentido certo, com pronomes e tratamento coerentes entre as falas."
        "comic" -> "Tradução adaptada para quadrinhos: frases curtas e diretas, vocabulário natural de balão de fala, interjeições e gírias adequadas, texto que caiba em balões pequenos."
        "formal" -> "Registro formal e polido."
        "informal" -> "Registro informal e coloquial, com gírias leves quando combinar com o personagem."
        else -> "Tradução natural e fluida, preservando o sentido e o tom do original."
    }
}

fun ocrLabel(conf: Float) = when {
    conf < 0f -> "indisponível"
    conf >= 0.85f -> "Alta"
    conf >= 0.6f -> "Média"
    else -> "Baixa"
}

fun engineLabel(e: String) = when (e) {
    "claude" -> "IA (Claude)"; "google" -> "Google Tradutor"; "offline" -> "offline (no celular)"
    "memória" -> "sua memória de correções"; "efeito sonoro" -> "dicionário de efeitos sonoros"; else -> e
}

/** Efeitos sonoros comuns (japonês, coreano, chinês) -> onomatopeia em português. */
object SfxDict {
    private val map: Map<String, String> = mapOf(
        // japonês
        "ドン" to "BAM!", "ドーン" to "BOOM!", "ガチャ" to "CLAC!", "ガチャン" to "CLANG!", "ガチャリ" to "CLAC!",
        "バン" to "BANG!", "バーン" to "BAM!", "ドキドキ" to "TUM-TUM", "ドキッ" to "TUM!", "ドクン" to "TUM!",
        "ゴゴゴ" to "GRRRR…", "ゴゴゴゴ" to "GRRRR…", "ゴゴ" to "GRRR…", "ゴゴゴゴゴ" to "GRRRR…",
        "ザワザワ" to "(murmúrios)", "ざわざわ" to "(murmúrios)", "シーン" to "(silêncio)", "しーん" to "(silêncio)",
        "ピカッ" to "FLASH!", "ピカー" to "FLASH!", "ズズズ" to "RUMMM…", "ズン" to "THUD!",
        "ドカ" to "POW!", "ドカッ" to "POW!", "ドカーン" to "KABUM!", "バキ" to "CRACK!", "バキッ" to "CRACK!",
        "ガシャン" to "CRASH!", "ゴクリ" to "GULP!", "ゴクッ" to "GULP!", "ハァハァ" to "(ofegante)", "はあはあ" to "(ofegante)",
        "クスクス" to "(risadinhas)", "ワハハ" to "HAHAHA!", "キラキラ" to "BRILHO", "ヒュー" to "FIUU!",
        "シュッ" to "SHH!", "ゴロゴロ" to "RUMBLE…", "ニヤリ" to "(sorriso malicioso)",
        // coreano
        "쿵" to "THUD!", "쾅" to "BAM!", "두근두근" to "TUM-TUM", "두근" to "TUM!", "철컥" to "CLAC!", "덜컥" to "CLAC!",
        "우르르" to "RUMMM…", "와장창" to "CRASH!", "짝" to "PLAC!", "휙" to "FIUU!", "번쩍" to "FLASH!", "꿀꺽" to "GULP!",
        // chinês
        "咚" to "TUM!", "砰" to "BAM!", "嘭" to "BAM!", "咔嚓" to "CLAC!", "轰" to "BUM!", "轰隆" to "BUUUM!",
        "哐当" to "CLANG!", "啪" to "PAF!", "嗖" to "FIUU!", "咕嘟" to "GULP!", "扑通" to "TUM-TUM!", "咚咚" to "TUM-TUM!"
    )

    private val strip = Regex("[\\s!！?？…・、。.~〜♪]")

    fun lookup(text: String): String? {
        val k = strip.replace(text, "")
        if (k.isEmpty() || k.length > 8) return null
        return map[k] ?: map[k.replace("ー", "")]
    }
}
