package com.livescreentranslator

import android.content.Context
import android.graphics.Typeface
import java.io.File

/** Resolve fontes do sistema, instaladas e importadas (TTF/OTF). Glifos que faltam (CJK etc.) usam a fonte de reserva do Android. */
object FontResolver {
    private val cache = HashMap<String, Typeface>()

    val presets = listOf(
        "Roboto / Arial (padrão do Android)" to "sys:sans-serif",
        "Roboto Condensed" to "sys:sans-serif-condensed",
        "Noto Serif (com serifa)" to "sys:serif",
        "Noto Sans CJK (japonês, coreano, chinês)" to "cjk",
        "Estilo quadrinhos (casual)" to "sys:casual",
        "Cursiva" to "sys:cursive",
        "Monoespaçada" to "sys:monospace"
    )

    fun installedFonts(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        for (dir in listOf("/system/fonts", "/product/fonts", "/system_ext/fonts")) {
            File(dir).listFiles()
                ?.filter { it.extension.lowercase() in listOf("ttf", "otf", "ttc") }
                ?.filter {
                    val n = it.name
                    !(n.startsWith("NotoSans") || n.startsWith("NotoSerif")) || n.contains("CJK") ||
                        n.startsWith("NotoSans-") || n.startsWith("NotoSerif-") ||
                        n.contains("JP") || n.contains("KR") || n.contains("SC")
                }
                ?.sortedBy { it.name }
                ?.forEach { out += "Instalada: ${it.nameWithoutExtension}" to "file:${it.absolutePath}" }
        }
        return out
    }

    fun importedFonts(c: Context): List<Pair<String, String>> =
        File(c.filesDir, "fonts").listFiles()?.sortedBy { it.name }
            ?.map { "Importada: ${it.nameWithoutExtension}" to "file:${it.absolutePath}" } ?: emptyList()

    fun resolve(c: Context, spec: String, bold: Boolean, italic: Boolean): Typeface {
        val key = "$spec|$bold|$italic"
        return cache.getOrPut(key) {
            val style = when {
                bold && italic -> Typeface.BOLD_ITALIC
                bold -> Typeface.BOLD
                italic -> Typeface.ITALIC
                else -> Typeface.NORMAL
            }
            val base: Typeface = when {
                spec.startsWith("file:") ->
                    runCatching { Typeface.createFromFile(spec.removePrefix("file:")) }.getOrNull() ?: Typeface.DEFAULT
                spec == "cjk" -> cjk()
                else -> Typeface.create(spec.removePrefix("sys:"), Typeface.NORMAL)
            }
            Typeface.create(base, style)
        }
    }

    private fun cjk(): Typeface {
        val f = installedFonts().firstOrNull { it.second.contains("CJK", true) } ?: return Typeface.SANS_SERIF
        return runCatching { Typeface.createFromFile(f.second.removePrefix("file:")) }.getOrDefault(Typeface.SANS_SERIF)
    }
}
