package com.livescreentranslator

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Encontra o interior do balão ao redor de um texto: espalha a cor do fundo a partir do texto
 * até bater no contorno. Se vazar (fundo desenhado, balão aberto), devolve null e o app usa a legenda comum.
 */
object BalloonFinder {

    fun find(bmp: Bitmap, text: Rect): Rect? {
        val pad = max(max(text.width(), text.height()), 40)
        val win = Rect(text.left - pad, text.top - pad, text.right + pad, text.bottom + pad)
        if (!win.intersect(0, 0, bmp.width, bmp.height)) return null
        if (win.width() < 24 || win.height() < 24) return null

        val scale = min(1f, 280f / max(win.width(), win.height()))
        val w = max(8, (win.width() * scale).toInt())
        val h = max(8, (win.height() * scale).toInt())
        val small = Bitmap.createScaledBitmap(Bitmap.createBitmap(bmp, win.left, win.top, win.width(), win.height()), w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)

        val tl = ((text.left - win.left) * scale).toInt().coerceIn(1, w - 2)
        val tt = ((text.top - win.top) * scale).toInt().coerceIn(1, h - 2)
        val tr = ((text.right - win.left) * scale).toInt().coerceIn(tl + 1, w - 2)
        val tb = ((text.bottom - win.top) * scale).toInt().coerceIn(tt + 1, h - 2)

        // anel logo fora do texto: define a cor do fundo
        val ring = ArrayList<Int>()
        val l0 = (tl - 2).coerceAtLeast(0); val r0 = (tr + 2).coerceAtMost(w - 1)
        val t0 = (tt - 2).coerceAtLeast(0); val b0 = (tb + 2).coerceAtMost(h - 1)
        for (x in l0..r0) { ring += t0 * w + x; ring += b0 * w + x }
        for (y in t0..b0) { ring += y * w + l0; ring += y * w + r0 }
        var rs = 0; var gs = 0; var bs = 0
        for (i in ring) { val c = px[i]; rs += c shr 16 and 255; gs += c shr 8 and 255; bs += c and 255 }
        val br = rs / ring.size; val bg = gs / ring.size; val bb = bs / ring.size

        fun near(c: Int) = abs((c shr 16 and 255) - br) + abs((c shr 8 and 255) - bg) + abs((c and 255) - bb) <= 60

        val seen = BooleanArray(w * h)
        val queue = IntArray(w * h)
        var head = 0; var tail = 0
        for (i in ring) if (!seen[i] && near(px[i])) { seen[i] = true; queue[tail++] = i }
        if (tail == 0) return null

        var minX = w; var maxX = 0; var minY = h; var maxY = 0
        var count = 0
        while (head < tail) {
            val i = queue[head++]
            val x = i % w; val y = i / w
            if (x == 0 || y == 0 || x == w - 1 || y == h - 1) return null   // vazou para fora da janela
            count++
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
            val n1 = i - 1; val n2 = i + 1; val n3 = i - w; val n4 = i + w
            if (!seen[n1] && near(px[n1])) { seen[n1] = true; queue[tail++] = n1 }
            if (!seen[n2] && near(px[n2])) { seen[n2] = true; queue[tail++] = n2 }
            if (!seen[n3] && near(px[n3])) { seen[n3] = true; queue[tail++] = n3 }
            if (!seen[n4] && near(px[n4])) { seen[n4] = true; queue[tail++] = n4 }
        }

        val boxW = maxX - minX + 1
        val boxH = maxY - minY + 1
        val textA = max(1, (tr - tl) * (tb - tt))
        val boxA = boxW * boxH
        if (count < 20 || boxA > textA * 6 || boxA < textA * 1.1f) return null

        val fill = count.toFloat() / boxA
        val f = if (fill > 0.92f) 0.94f else 0.78f      // retângulo x balão arredondado
        val cx = (minX + maxX + 1) / 2f
        val cy = (minY + maxY + 1) / 2f
        val l = ((cx - boxW * f / 2f) / scale).toInt() + win.left
        val t = ((cy - boxH * f / 2f) / scale).toInt() + win.top
        val r = ((cx + boxW * f / 2f) / scale).toInt() + win.left
        val b = ((cy + boxH * f / 2f) / scale).toInt() + win.top
        val out = Rect(l, t, r, b)
        out.union(text)
        return out
    }
}
