package com.livescreentranslator

import android.graphics.Rect
import java.util.Collections
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

enum class SubState { TRANSLATING, TRANSLATED, EDITED, FAILED }

/** Legenda ancorada: coordenadas no "mundo" da página (não na tela). */
class Subtitle(
    val id: Long,
    var regionId: String,
    var original: String,
    var translated: String,
    var sourceLang: String,
    var x: Int, var y: Int, var w: Int, var h: Int,
    var bg: Int, var fg: Int
) {
    @Volatile var state: SubState = SubState.TRANSLATED
    @Volatile var hidden: Boolean = false          // oculta só durante a captura
    @Volatile var userHidden: Boolean = false      // oculta pelo usuário
    @Volatile var styleOv: SubStyle? = null        // aparência só desta legenda
    @Volatile var ttlOv: Long = -1L                // -1 padrão, 0 até a tela mudar, >0 ms
    @Volatile var targetLang: String? = null       // idioma de destino só desta legenda
    val history = CopyOnWriteArrayList<String>()   // histórico de correções
    @Volatile var styleKey: String? = null         // estilo de tradução só desta legenda
    @Volatile var engine: String = "offline"       // quem traduziu: offline, claude, google, memória...
    @Volatile var conf: Float = -1f                // confiança do OCR (0..1), -1 = desconhecida
    @Volatile var sfx: Boolean = false             // efeito sonoro
    fun rect() = Rect(x, y, x + w, y + h)
}

/** Uma página/tela já vista, com suas legendas salvas. */
class Page(val id: Long, val fingerprint: IntArray) {
    val subs = CopyOnWriteArrayList<Subtitle>()
    val done: MutableSet<Long> = Collections.synchronizedSet(HashSet<Long>())   // células já processadas pelo OCR
}

object Ids {
    private val n = AtomicLong(1)
    fun next() = n.getAndIncrement()
    fun ensure(min: Long) { while (n.get() <= min) n.incrementAndGet() }
}
