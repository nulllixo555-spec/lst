package com.livescreentranslator

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val languages = listOf(
        "Português (Brasil)" to "pt", "English" to "en", "Español" to "es",
        "Français" to "fr", "Deutsch" to "de", "Italiano" to "it", "日本語" to "ja", "Bahasa Indonesia" to "id"
    )
    private lateinit var btnPause: MaterialButton
    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton
    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private lateinit var sourceSpinner: Spinner
    private lateinit var modeSpinner: Spinner
    private lateinit var powerSpinner: Spinner
    private val powers = listOf("Econômico (celulares simples)" to "eco", "Equilibrado" to "balanced", "Alta precisão (mais lento)" to "high")
    private val modes = listOf("Automático" to "auto", "Sob demanda (toque no botão 👆)" to "demand")
    private val sources = listOf(
        "Inglês (americano e britânico)" to "en", "Indonésio" to "id",
        "Espanhol, francês, etc. (rápido)" to "latin", "Japonês" to "ja",
        "Chinês" to "zh", "Coreano" to "ko", "Automático (mais lento)" to "auto"
    )
    private val prefs by lazy { getSharedPreferences("lst", Context.MODE_PRIVATE) }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslatorService::class.java)
                .setAction(TranslatorService.ACTION_START)
                .putExtra(TranslatorService.EXTRA_CODE, r.resultCode)
                .putExtra(TranslatorService.EXTRA_DATA, data)
                .putExtra(TranslatorService.EXTRA_TARGET, languages[spinner.selectedItemPosition].second)
                .putExtra(TranslatorService.EXTRA_SOURCE, sources[sourceSpinner.selectedItemPosition].second)
                .putExtra(TranslatorService.EXTRA_MODE, modes[modeSpinner.selectedItemPosition].second)
                .putExtra(TranslatorService.EXTRA_POWER, powers[powerSpinner.selectedItemPosition].second)
            ContextCompat.startForegroundService(this, i)
        }
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnStart = findViewById(R.id.btnStart); btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop); status = findViewById(R.id.status)
        spinner = findViewById(R.id.language)
        sourceSpinner = findViewById(R.id.source)
        modeSpinner = findViewById(R.id.mode)
        powerSpinner = findViewById(R.id.power)
        modeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes.map { it.first })
        modeSpinner.setSelection(modes.indexOfFirst { it.second == prefs.getString("mode", "auto") }.coerceAtLeast(0))
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("mode", modes[pos].second).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        powerSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, powers.map { it.first })
        powerSpinner.setSelection(powers.indexOfFirst { it.second == prefs.getString("power", "balanced") }.coerceAtLeast(0))
        powerSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("power", powers[pos].second).apply()
                TranslatorService.reloadHook?.invoke()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        sourceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sources.map { it.first })
        sourceSpinner.setSelection(sources.indexOfFirst { it.second == prefs.getString("source", "en") }.coerceAtLeast(0))
        sourceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("source", sources[pos].second).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages.map { it.first })
        spinner.setSelection(languages.indexOfFirst { it.second == prefs.getString("target", "pt") }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("target", languages[pos].second).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        btnStart.setOnClickListener { start() }
        btnPause.setOnClickListener {
            val paused = TranslatorService.state.value == TranslatorService.State.PAUSED
            send(if (paused) TranslatorService.ACTION_RESUME else TranslatorService.ACTION_PAUSE)
        }
        btnStop.setOnClickListener { send(TranslatorService.ACTION_STOP) }
        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnOffline).setOnClickListener {
            startActivity(Intent(this, OfflineActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnTerms).setOnClickListener {
            startActivity(Intent(this, TermsActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnStyle).setOnClickListener {
            startActivity(Intent(this, StyleActivity::class.java))
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                TranslatorService.state.collect { render(it) }
            }
        }
    }

    private fun render(s: TranslatorService.State) {
        status.text = when (s) {
            TranslatorService.State.IDLE -> "Parado"
            TranslatorService.State.RUNNING -> "Traduzindo…"
            TranslatorService.State.PAUSED -> "Pausado"
        }
        btnStart.isEnabled = s == TranslatorService.State.IDLE
        btnPause.isEnabled = s != TranslatorService.State.IDLE
        btnStop.isEnabled = s != TranslatorService.State.IDLE
        btnPause.text = if (s == TranslatorService.State.PAUSED) "Retomar tradução" else "Pausar tradução"
    }

    private fun send(action: String) = startService(Intent(this, TranslatorService::class.java).setAction(action))

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita a exibição sobre outros apps e volte.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS); return
        }
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
