package com.livescreentranslator

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class OnlineResult(val text: String?, val error: String?)

/** Mecanismos de tradução online. Só enviam TEXTO (nunca imagens) e só com autorização do usuário. */
object Engines {

    fun isOnline(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Decide qual mecanismo usar para este idioma de origem: "offline", "claude" ou "google". */
    fun plan(c: Context, src: String): String {
        val sp = c.getSharedPreferences("lst", Context.MODE_PRIVATE)
        if (!sp.getBoolean(K.CONSENT, false)) return "offline"
        val perLang = runCatching { JSONObject(sp.getString(K.LANGENG, "{}") ?: "{}").optString(src, "") }.getOrDefault("")
        var mode = if (perLang.isNotEmpty() && perLang != "default") perLang else (sp.getString(K.ENGINE, "offline") ?: "offline")
        if (mode == "auto") mode = when {
            Secrets.get(c, "claude").isNotEmpty() -> "claude"
            Secrets.get(c, "google").isNotEmpty() -> "google"
            else -> "offline"
        }
        if (mode != "claude" && mode != "google") return "offline"
        if (Secrets.get(c, mode).isEmpty()) return "offline"
        if (!isOnline(c)) return "offline"
        return mode
    }

    private fun post(url: String, headers: Map<String, String>, body: String): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 30000
            conn.doOutput = true
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return code to text
        } finally {
            conn.disconnect()
        }
    }

    private fun httpError(code: Int, body: String): String = when (code) {
        401, 403 -> "chave de API inválida ou sem permissão"
        429 -> "limite de uso ou de crédito atingido"
        400 -> runCatching { JSONObject(body).getJSONObject("error").getString("message") }.getOrDefault("pedido recusado")
        else -> "erro $code do servidor"
    }

    private fun systemPrompt(tgt: String, style: String) =
        "Você é um tradutor profissional de quadrinhos (mangá, manhwa e manhua) e de jogos. " +
            "Traduza o TEXTO ATUAL para ${LangNames.name(tgt)}. " +
            "Responda SOMENTE com a tradução: sem aspas, sem explicações, sem notas. " +
            TStyles.instruction(style) + " " +
            "Use as falas anteriores para manter coerência de pronomes, tratamento e tom de cada personagem. " +
            "Siga o glossário exatamente quando um termo dele aparecer. " +
            "Interprete gírias, expressões idiomáticas e ironia pelo sentido, nunca palavra por palavra sem sentido. " +
            "O texto veio de OCR e pode ter pequenos erros de leitura: corrija-os quando o erro for óbvio. " +
            "Efeitos sonoros (onomatopeias) viram onomatopeias em português (por exemplo, ドン vira BAM!). " +
            "Se o texto for ilegível ou não for texto, responda exatamente: ???"

    private fun userPrompt(text: String, glossary: List<Term>, ctx: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        if (glossary.isNotEmpty()) {
            sb.append("GLOSSÁRIO (use exatamente):\n")
            for (t in glossary) {
                sb.append("- ").append(t.source).append(" → ").append(t.target).append(" [").append(t.kind).append("]")
                if (t.notes.isNotBlank()) sb.append(" (").append(t.notes.take(120)).append(")")
                sb.append('\n')
            }
            sb.append('\n')
        }
        if (ctx.isNotEmpty()) {
            sb.append("FALAS ANTERIORES (mais antigas primeiro):\n")
            ctx.forEachIndexed { i, (o, t) -> sb.append(i + 1).append(". ").append(o.take(200)).append(" → ").append(t.take(200)).append('\n') }
            sb.append('\n')
        }
        sb.append("TEXTO ATUAL:\n").append(text)
        return sb.toString()
    }

    suspend fun claude(
        c: Context, text: String, src: String, tgt: String, style: String,
        glossary: List<Term>, ctx: List<Pair<String, String>>, model: String
    ): OnlineResult = withContext(Dispatchers.IO) {
        try {
            val key = Secrets.get(c, "claude")
            if (key.isEmpty()) return@withContext OnlineResult(null, "chave não configurada")
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", (text.length * 4 + 150).coerceIn(150, 800))
                .put("system", systemPrompt(tgt, style))
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", userPrompt(text, glossary, ctx))))
            val (code, resp) = post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01", "content-type" to "application/json"),
                body.toString()
            )
            if (code !in 200..299) return@withContext OnlineResult(null, httpError(code, resp))
            val arr = JSONObject(resp).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") == "text") sb.append(o.optString("text"))
            }
            val out = sb.toString().trim()
            if (out.isEmpty() || out == "???") OnlineResult(null, "a IA não conseguiu ler o texto") else OnlineResult(out, null)
        } catch (e: Exception) {
            OnlineResult(null, "sem conexão com o servidor")
        }
    }

    suspend fun google(c: Context, text: String, src: String, tgt: String): OnlineResult = withContext(Dispatchers.IO) {
        try {
            val key = Secrets.get(c, "google")
            if (key.isEmpty()) return@withContext OnlineResult(null, "chave não configurada")
            val body = JSONObject().put("q", text).put("source", src).put("target", tgt).put("format", "text")
            val (code, resp) = post(
                "https://translation.googleapis.com/language/translate/v2",
                mapOf("X-goog-api-key" to key, "content-type" to "application/json"),
                body.toString()
            )
            if (code !in 200..299) return@withContext OnlineResult(null, httpError(code, resp))
            val out = JSONObject(resp).getJSONObject("data").getJSONArray("translations").getJSONObject(0).getString("translatedText").trim()
            if (out.isEmpty()) OnlineResult(null, "resposta vazia") else OnlineResult(out, null)
        } catch (e: Exception) {
            OnlineResult(null, "sem conexão com o servidor")
        }
    }
}
