package com.livescreentranslator

import android.content.Context
import org.json.JSONObject
import java.lang.reflect.Modifier

/** Todas as configurações de aparência, duração e posição das legendas. */
data class SubStyle(
    // ---- texto
    var textColorAuto: Boolean = true,
    var textColor: Int = 0xFFFFFFFF.toInt(),
    var autoSize: Boolean = true,
    var textSizeSp: Float = 16f,
    var font: String = "sys:sans-serif",
    var bold: Boolean = false,
    var italic: Boolean = false,
    var underline: Boolean = false,
    var letterSpacing: Float = 0f,       // em
    var lineSpacing: Float = 1.0f,       // multiplicador
    var align: Int = 1,                  // 0 esquerda, 1 centro, 2 direita
    var widthPct: Int = 100,
    var heightPct: Int = 100,
    var wrap: Boolean = true,
    // ---- fundo
    var bgEnabled: Boolean = true,
    var bgAuto: Boolean = true,
    var bgColor: Int = 0xFF000000.toInt(),
    var bgAlpha: Int = 100,              // opacidade em %
    var cornerDp: Int = 6,
    var borderDp: Int = 0,
    var borderColor: Int = 0xFFFFFFFF.toInt(),
    var shadow: Boolean = false,
    var outline: Boolean = false,
    var outlineColor: Int = 0xFF000000.toInt(),
    var outlineDp: Int = 2,
    var paddingDp: Int = 2,
    // ---- duração
    var keepWhileStatic: Boolean = true,
    var durationAuto: Boolean = true,
    var fixedMs: Long = 4000,
    var minMs: Long = 1500,
    var maxMs: Long = 15000,
    var msPerChar: Long = 60,
    var fadeInMs: Long = 150,
    var fadeOutMs: Long = 250,
    var anim: Int = 1,                   // 0 nenhuma, 1 aparecer, 2 deslizar, 3 zoom
    var unitSeconds: Boolean = true,
    // ---- posição
    var position: Int = 0,               // 0 sobre o original, 1 baixo, 2 topo, 3 centro
    var offsetXDp: Int = 0,
    var offsetYDp: Int = 0,
    var showConf: Boolean = false
) {
    fun save(c: Context) {
        val o = JSONObject()
        for (f in SubStyle::class.java.declaredFields) {
            if (Modifier.isStatic(f.modifiers)) continue
            f.isAccessible = true
            o.put(f.name, f.get(this))
        }
        c.getSharedPreferences("lst", Context.MODE_PRIVATE).edit().putString("style", o.toString()).apply()
    }

    companion object {
        fun load(c: Context): SubStyle {
            val s = SubStyle()
            val raw = c.getSharedPreferences("lst", Context.MODE_PRIVATE).getString("style", null) ?: return s
            val o = runCatching { JSONObject(raw) }.getOrNull() ?: return s
            for (f in SubStyle::class.java.declaredFields) {
                if (Modifier.isStatic(f.modifiers) || !o.has(f.name)) continue
                f.isAccessible = true
                runCatching {
                    when (f.type) {
                        Boolean::class.javaPrimitiveType -> f.setBoolean(s, o.getBoolean(f.name))
                        Int::class.javaPrimitiveType -> f.setInt(s, o.getInt(f.name))
                        Long::class.javaPrimitiveType -> f.setLong(s, o.getLong(f.name))
                        Float::class.javaPrimitiveType -> f.setFloat(s, o.getDouble(f.name).toFloat())
                        String::class.java -> f.set(s, o.getString(f.name))
                    }
                }
            }
            return s
        }
    }
}
