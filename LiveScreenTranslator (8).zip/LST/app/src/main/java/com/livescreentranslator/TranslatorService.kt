package com.livescreentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.graphics.ColorUtils
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.tasks.await
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class TranslatorService : Service() {

    enum class State { IDLE, RUNNING, PAUSED }

    companion object {
        const val ACTION_START = "start"; const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"; const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"; const val EXTRA_DATA = "data"
        const val EXTRA_TARGET = "target"; const val EXTRA_SOURCE = "source"
        const val EXTRA_MODE = "mode"; const val EXTRA_POWER = "power"
        val state = MutableStateFlow(State.IDLE)
        @Volatile var reloadHook: (() -> Unit)? = null
        private const val CHANNEL = "lst"
        private const val CELL = 96
    }

    private class Tr(val out: String, val src: String, val bg: Int, val fg: Int, val engine: String)
    private class Pending(
        val sub: Subtitle, val cands: List<Cand>, val original: String, val lang: String, val conf: Float,
        val prev: SubState, val oldTarget: String?, val oldEngine: String, val oldConf: Float,
        val oldOriginal: String, val oldLang: String, val newTarget: String?
    ) {
        var applied = 0
        var historyAdded = false
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var bubble: Bubble? = null
    private var menu: FloatingMenu? = null
    private var screenW = 0
    private var screenH = 0
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private val sp by lazy { getSharedPreferences("lst", Context.MODE_PRIVATE) }

    // desempenho (modo econômico / equilibrado / alta precisão)
    private var tickMs = 110L
    private var settleMs = 450L
    private var gapMs = 700L
    private var ocrW = 800
    private var enhance = false

    // captura e rastreamento
    private val imgLock = Any()
    private var held: Image? = null
    @Volatile private var heldAt = 0L
    private var prevProf: Tracker.Prof? = null
    @Volatile private var phase = 1
    private var changeAt = 0L
    private var needClean = false
    private var lastMotionAt = 0L
    private var lastOcrAt = 0L
    @Volatile private var ignoreUntil = 0L
    @Volatile private var rebaseUntil = 0L      // após mexer nas legendas, a próxima tela vira a nova referência
    private var lastDx = 0
    private var lastDy = 0
    @Volatile private var dirty = false
    @Volatile private var busy = false
    @Volatile private var retrBusy = false
    @Volatile private var menuOpen = false
    @Volatile private var touchMode = false
    @Volatile private var requested = false
    @Volatile private var sx = 0
    @Volatile private var sy = 0
    private val pages = ArrayList<Page>()
    @Volatile private var page: Page? = null
    private var pagesDirty = false
    private var lastSaveAt = 0L
    private var pending: Pending? = null
    private var lastErrAt = 0L

    // tradução
    private var target = TranslateLanguage.PORTUGUESE
    private var sourceMode = "en"
    private var onDemand = false
    private val cache = ConcurrentHashMap<String, String>()
    private val confByText = ConcurrentHashMap<String, Float>()
    private val translators = HashMap<String, Translator>()
    private val modelLock = Mutex()
    private val netSem = Semaphore(3)
    private val db by lazy { TermDb.get(this) }
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val jp by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent)
            ACTION_PAUSE -> doPause()
            ACTION_RESUME -> doResume()
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun doPause() {
        state.value = State.PAUSED
        overlay?.suppressed = true
        menu?.dismiss()
        notify(true)
    }

    private fun doResume() {
        state.value = State.RUNNING
        overlay?.suppressed = false
        resetToStable(SystemClock.uptimeMillis(), false)
        notify(false)
    }

    private fun applyPower(p: String) {
        when (p) {
            "eco" -> { tickMs = 200L; Tracker.step = 8; ocrW = 640; settleMs = 700L; gapMs = 1500L; enhance = false }
            "high" -> { tickMs = 80L; Tracker.step = 5; ocrW = 1080; settleMs = 350L; gapMs = 500L; enhance = true }
            else -> { tickMs = 110L; Tracker.step = 6; ocrW = 800; settleMs = 450L; gapMs = 700L; enhance = false }
        }
    }

    // ---------------------------------------------------------------- início

    private fun begin(intent: Intent) {
        createChannel()
        val n = buildNotification(false, null)
        if (Build.VERSION.SDK_INT >= 29)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        target = intent.getStringExtra(EXTRA_TARGET) ?: TranslateLanguage.PORTUGUESE
        sourceMode = intent.getStringExtra(EXTRA_SOURCE) ?: "en"
        onDemand = intent.getStringExtra(EXTRA_MODE) == "demand"
        applyPower(intent.getStringExtra(EXTRA_POWER) ?: sp.getString(K.POWER, "balanced") ?: "balanced")
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION") val data: Intent = intent.getParcelableExtra(EXTRA_DATA) ?: return shutdown()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { shutdown() } }
            }, main)
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels; screenH = dm.heightPixels

        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 4)
        display = projection!!.createVirtualDisplay(
            "lst", screenW, screenH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )

        val lp = WindowManager.LayoutParams(
            screenW, screenH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        overlayLp = lp
        overlay = OverlayView(this).also {
            it.style = SubStyle.load(this)
            it.onTap = { sub, box -> gesture("tap", sub, box) }
            it.onDouble = { sub, box -> gesture("double", sub, box) }
            it.onLongPress = { sub, box -> gesture("long", sub, box) }
            it.onTwoFinger = { gesture("two", null, null) }
            wm.addView(it, lp)
        }
        menu = FloatingMenu(this, wm, screenW, screenH, { SubStyle.load(this) }, actions)
        bubble = Bubble(this, wm, screenW, screenH, { onBubble() }, { unhideAll() }).also { it.show() }

        pages.addAll(PageStore.load(this))
        state.value = State.RUNNING
        phase = 1; changeAt = SystemClock.uptimeMillis(); needClean = false
        reloadHook = {
            main.post {
                overlay?.style = SubStyle.load(this@TranslatorService)
                applyPower(sp.getString(K.POWER, "balanced") ?: "balanced")
            }
        }

        scope.launch {
            val first = when (sourceMode) { "ja" -> "ja"; "zh" -> "zh"; "ko" -> "ko"; "id" -> "id"; else -> "en" }
            translatorFor(first, target); if (first != "en") translatorFor("en", target)
        }
        job = scope.launch {
            while (isActive) {
                if (state.value == State.RUNNING) runCatching { tick() }
                delay(tickMs)
            }
        }
    }

    // ------------------------------------------------------------ modo toque

    private val touchOff = Runnable { if (!menuOpen) setTouch(false) else rearmTouch() }

    private fun rearmTouch() { main.removeCallbacks(touchOff); if (touchMode) main.postDelayed(touchOff, 15000) }

    private fun setTouch(on: Boolean) {
        touchMode = on
        overlayLp?.let { lp ->
            lp.flags = if (on) baseFlags else baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            overlay?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
        }
        overlay?.touchMode = on
        bubble?.setActive(on)
        main.removeCallbacks(touchOff)
        if (on) main.postDelayed(touchOff, 15000) else menu?.dismiss()
        notifyText(if (on) "Modo toque ligado: toque numa legenda (desliga sozinho)" else null)
    }

    private fun onBubble() {
        if (sp.getString(K.G_BUBBLE, "touch") == "pause") {
            if (state.value == State.PAUSED) doResume() else doPause()
            return
        }
        if (onDemand) {
            requested = true; dirty = true; lastMotionAt = 0L; lastOcrAt = 0L
            notifyText("Traduzindo esta tela…")
            setTouch(true)
        } else setTouch(!touchMode)
    }

    private fun toggleHideAll() { overlay?.let { it.suppressed = !it.suppressed } }

    private fun gesture(name: String, sub: Subtitle?, box: RectF?) {
        rearmTouch()
        if (sub == null && menuOpen && name != "two") { menu?.dismiss(); return }
        val def = when (name) { "tap" -> "menu"; "double" -> "edit"; "long" -> "retranslate"; else -> "toggle" }
        when (sp.getString("g_$name", def) ?: def) {
            "menu" -> if (sub != null && box != null) { menuOpen = true; menu?.showMenu(sub, box) }
            "edit" -> if (sub != null && box != null) { menuOpen = true; menu?.edit(sub, box) }
            "retranslate" -> if (sub != null) retranslate(sub, null)
            "copy" -> if (sub != null) actions.copy(sub)
            "hide" -> if (sub != null) actions.hide(sub)
            "toggle" -> toggleHideAll()
        }
    }

    private fun unhideAll() {
        page?.subs?.forEach { it.userHidden = false }
        pagesDirty = true
        postUpdate()
        notifyText("Legendas ocultas reexibidas")
    }

    // ------------------------------------------------------ ações do menu

    private val actions = object : MenuActions {
        override fun retranslate(sub: Subtitle) = this@TranslatorService.retranslate(sub, null)

        override fun saveEdit(sub: Subtitle, text: String, term: Triple<String, String, String>?) {
            val t = text.trim()
            if (t.isEmpty()) return
            val before = sub.translated
            sub.history.add(before); sub.translated = t; sub.state = SubState.EDITED; sub.engine = "memória"
            val tgt = sub.targetLang ?: target
            scope.launch {
                db.log(sub.original, before, t)
                db.upsert("Frase", sub.original, t, sub.sourceLang, tgt)
                term?.let { db.upsert(it.first, it.second, it.third, sub.sourceLang, tgt) }
                pagesDirty = true
            }
            postUpdate()
        }

        override fun setTarget(sub: Subtitle, lang: String) = this@TranslatorService.retranslate(sub, lang)

        override fun setStyle(sub: Subtitle, key: String?) {
            sub.styleKey = key
            pagesDirty = true
            this@TranslatorService.retranslate(sub, null)
        }

        override fun copy(sub: Subtitle) {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("tradução", sub.translated))
            notifyText("Tradução copiada")
        }

        override fun setDuration(sub: Subtitle, ms: Long) {
            sub.ttlOv = ms; pagesDirty = true
            overlay?.resetAnim(); postUpdate()
        }

        override fun applyStyle(sub: Subtitle, s: SubStyle?) { sub.styleOv = s; postUpdate() }

        override fun hide(sub: Subtitle) {
            sub.userHidden = true; pagesDirty = true; postUpdate()
            notifyText("Legenda oculta. Segure o botão 👆 para reexibir")
        }

        override fun choose(sub: Subtitle, index: Int) {
            val p = pending ?: return
            pending = null
            if (p.sub !== sub) return
            if (index != p.applied && index in p.cands.indices) applyIndex(p, index)
            pagesDirty = true
            postUpdate()
        }

        override fun closed() { menuOpen = false }
    }

    private fun applyIndex(p: Pending, i: Int) {
        val s = p.sub
        if (i == 0) {
            s.translated = p.cands[0].text; s.state = p.prev; s.targetLang = p.oldTarget
            s.engine = p.oldEngine; s.conf = p.oldConf; s.original = p.oldOriginal; s.sourceLang = p.oldLang
            if (p.historyAdded && s.history.isNotEmpty()) { s.history.removeAt(s.history.size - 1); p.historyAdded = false }
        } else {
            val c = p.cands[i]
            if (!p.historyAdded) { s.history.add(p.cands[0].text); p.historyAdded = true }
            s.original = p.original; s.translated = c.text; s.engine = c.engine; s.sourceLang = p.lang
            s.state = SubState.TRANSLATED
            if (p.newTarget != null) s.targetLang = p.newTarget
            if (p.conf >= 0f) s.conf = p.conf
        }
        p.applied = i
    }

    // ------------------------------------------------------------------ ciclo

    private suspend fun tick() {
        val now = SystemClock.uptimeMillis()
        val img: Image? = synchronized(imgLock) {
            val i = reader?.acquireLatestImage()
            if (i != null) { held?.close(); held = i; heldAt = now }
            i
        }
        if (phase == 0) {
            if (img != null && now >= ignoreUntil && !menuOpen) onFrame(img, now)
            maybeSettle(now)
        } else {
            val h = held
            if (h != null && (!needClean || heldAt > changeAt + 60) &&
                ((now - heldAt > 220 && now - changeAt > 300) || now - changeAt > 2500)) finalizePage(h, now)
        }
        if (pagesDirty && now - lastSaveAt > 8000) {
            pagesDirty = false; lastSaveAt = now
            PageStore.save(this, pages.toList())
        }
    }

    private fun onFrame(img: Image, now: Long) {
        val ix = min(abs(lastDx), 120) + 8
        val iy = min(abs(lastDy), 120) + 8
        val masks = (overlay?.boxes ?: emptyList()).map { Rect(it).apply { inset(-ix, -iy) } } + listOfNotNull(bubble?.rect())
        val prof = Tracker.profile(img, masks)
        val prev = prevProf
        prevProf = prof
        if (prev == null || now < rebaseUntil) return     // legendas acabaram de mudar: só atualiza a referência
        val m = Tracker.estimate(prev, prof)
        when (m.kind) {
            0 -> { lastDx = 0; lastDy = 0 }
            1 -> { lastDx = m.dx; lastDy = m.dy; sx -= m.dx; sy -= m.dy; lastMotionAt = now; dirty = true; postUpdate() }
            2 -> resetToStable(now, overlay?.boxes?.isNotEmpty() == true)
        }
    }

    private fun resetToStable(now: Long, hadVisible: Boolean) {
        phase = 1; changeAt = now; needClean = hadVisible; prevProf = null
        sx = 0; sy = 0; page = null; dirty = false
        postUpdate()
    }

    private fun finalizePage(img: Image, now: Long) {
        val fp = Tracker.fingerprint(img)
        val match = pages.firstOrNull { Tracker.fpDiff(it.fingerprint, fp) < 10f }
        val p = match ?: Page(Ids.next(), fp).also {
            pages.add(it)
            if (pages.size > 25) pages.removeAt(0)
        }
        page = p
        sx = 0; sy = 0
        prevProf = null
        rebaseUntil = now + 400
        phase = 0
        dirty = !onDemand && (match == null || p.done.isEmpty())
        lastMotionAt = now
        postUpdate()
    }

    private fun postUpdate() {
        val subs = page?.subs?.toList() ?: emptyList()
        val x = sx
        val y = sy
        main.post { overlay?.update(subs, x, y) }
    }

    private fun maybeSettle(now: Long) {
        if (!dirty || busy || retrBusy || menuOpen) return
        if (onDemand && !requested) return
        val settle = if (onDemand) 0L else settleMs
        if (now - lastMotionAt < settle || now - lastOcrAt < gapMs) return
        val p = page ?: return
        busy = true; dirty = false; requested = false; lastOcrAt = now
        scope.launch {
            try { ocrPage(p) } catch (e: CancellationException) { throw e } catch (e: Throwable) { /* ignora */ }
            finally { busy = false; lastOcrAt = SystemClock.uptimeMillis() }
        }
    }

    // ------------------------------------------------- OCR só do que é novo

    private fun key(cx: Int, cy: Int) = (cx.toLong() shl 32) xor (cy.toLong() and 0xffffffffL)

    private suspend fun waitNewFrame(t0: Long) {
        var waited = 0
        while (heldAt <= t0 + 30 && waited < 600) { delay(25); waited += 25 }
    }

    private suspend fun ocrPage(p: Page) {
        val x0 = sx
        val y0 = sy
        val top = (screenH * 0.07f).toInt()
        val bot = (screenH * 0.95f).toInt()
        val cx0 = Math.floorDiv(x0, CELL)
        val cx1 = Math.floorDiv(x0 + screenW - 1, CELL)
        val cy0 = Math.floorDiv(y0 + top, CELL)
        val cy1 = Math.floorDiv(y0 + bot - 1, CELL)
        var ux0 = Int.MAX_VALUE; var uy0 = Int.MAX_VALUE; var ux1 = Int.MIN_VALUE; var uy1 = Int.MIN_VALUE
        var count = 0
        for (cy in cy0..cy1) for (cx in cx0..cx1) if (!p.done.contains(key(cx, cy))) {
            count++; ux0 = min(ux0, cx); uy0 = min(uy0, cy); ux1 = max(ux1, cx); uy1 = max(uy1, cy)
        }
        fun markAll() { for (cy in cy0..cy1) for (cx in cx0..cx1) p.done.add(key(cx, cy)) }
        if (count == 0) return
        if (count < 2) { markAll(); return }

        val margin = 48
        val crop = Rect(
            (ux0 * CELL - x0 - margin).coerceAtLeast(0), (uy0 * CELL - y0 - margin).coerceAtLeast(top),
            ((ux1 + 1) * CELL - x0 + margin).coerceAtMost(screenW), ((uy1 + 1) * CELL - y0 + margin).coerceAtMost(bot)
        )
        if (crop.width() < 40 || crop.height() < 40) { markAll(); return }

        val cap = synchronized(imgLock) { held?.let { Triple(toBitmap(it), sx, sy) } }
        if (cap == null) return
        val (full, cx, cy) = cap
        if (cx != x0 || cy != y0) { full.recycle(); dirty = true; if (onDemand) requested = true; return }

        val region0 = Bitmap.createBitmap(full, crop.left, crop.top, crop.width(), crop.height())
        full.recycle()
        val region = if (region0.isMutable) region0 else region0.copy(Bitmap.Config.ARGB_8888, true).also { region0.recycle() }
        // Áreas já cobertas por legendas mostram a tradução, não o original: apaga para o OCR ignorar.
        // Assim as legendas não precisam sumir (nem piscar) durante a leitura.
        run {
            val cv = Canvas(region)
            val wipe = Paint().apply { color = 0xFFFFFFFF.toInt() }
            for (b in overlay?.boxes ?: emptyList()) if (Rect.intersects(b, crop))
                cv.drawRect((b.left - crop.left).toFloat(), (b.top - crop.top).toFloat(), (b.right - crop.left).toFloat(), (b.bottom - crop.top).toFloat(), wipe)
        }
        val blocks = mergeBalloons(ocrBlocks(region, sourceMode), region.width.toLong() * region.height)

        val balloonOn = sp.getBoolean(K.BALLOON, true)
        val baseStyle = SubStyle.load(this)
        val cutRects = java.util.Collections.synchronizedList(ArrayList<Rect>())
        coroutineScope {
            blocks.map { (rect, text0) ->
                async {
                    val wr = Rect(rect.left + crop.left + cx, rect.top + crop.top + cy, rect.right + crop.left + cx, rect.bottom + crop.top + cy)
                    val sl = rect.left + crop.left
                    val sr = rect.right + crop.left
                    val st = rect.top + crop.top
                    val sb = rect.bottom + crop.top
                    if (sl <= 3 || sr >= screenW - 3 || st <= top + 6 || sb >= bot - 6) { cutRects.add(wr); return@async }
                    if (!shouldProcess(p, wr)) return@async

                    var text = text0
                    val c0 = confByText[text0]
                    var conf: Float? = c0
                    if (enhance && c0 != null && c0 < 0.6f) {
                        val b = enhanceRead(region, rect, sourceMode)
                        val bc = b?.second
                        if (b != null && b.first.isNotBlank() && bc != null && bc > c0) { text = b.first; conf = bc }
                    }
                    val tr = translateBlock(region, rect, text, sourceMode, p, wr) ?: return@async

                    val sfx = SfxDict.lookup(TermDb.norm(text)) != null
                    val balloon = if (balloonOn && !sfx) BalloonFinder.find(region, rect) else null
                    val box = balloon ?: rect
                    val bwr = Rect(box.left + crop.left + cx, box.top + crop.top + cy, box.right + crop.left + cx, box.bottom + crop.top + cy)
                    val pad = if (balloon == null) 2 else 0
                    val sub = Subtitle(
                        Ids.next(), "${text.hashCode()}@${wr.left / CELL},${wr.top / CELL}", text, tr.out, tr.src,
                        bwr.left - pad, bwr.top - pad, bwr.width() + 2 * pad, bwr.height() + 2 * pad, tr.bg, tr.fg
                    )
                    sub.engine = tr.engine
                    sub.conf = conf ?: -1f
                    sub.sfx = sfx
                    if (sfx) sub.styleOv = baseStyle.copy(bold = true, outline = true, outlineDp = 2, autoSize = true)
                    if (place(p, sub)) { pagesDirty = true; rebaseUntil = SystemClock.uptimeMillis() + 400; postUpdate() }
                }
            }.awaitAll()
        }
        region.recycle()
        markAll()
        for (r in cutRects) {
            for (yy in Math.floorDiv(r.top, CELL)..Math.floorDiv(r.bottom, CELL))
                for (xx in Math.floorDiv(r.left, CELL)..Math.floorDiv(r.right, CELL)) p.done.remove(key(xx, yy))
        }
    }

    private fun overlap(a: Rect, b: Rect): Float {
        val i = Rect(a)
        if (!i.intersect(b)) return 0f
        val ia = i.width().toLong() * i.height()
        val m = min(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return ia.toFloat() / max(1L, m)
    }

    private fun shouldProcess(p: Page, wr: Rect): Boolean {
        for (o in p.subs) {
            if (overlap(o.rect(), wr) > 0.4f) {
                val a = wr.width().toLong() * wr.height()
                val oa = o.w.toLong() * o.h
                return a > oa * 1.35 && o.state == SubState.TRANSLATED
            }
        }
        return true
    }

    private fun place(p: Page, sub: Subtitle): Boolean = synchronized(p) {
        for (o in p.subs) {
            if (overlap(o.rect(), sub.rect()) > 0.4f) {
                val a = sub.w.toLong() * sub.h
                val oa = o.w.toLong() * o.h
                if (a > oa * 1.35 && o.state == SubState.TRANSLATED) { p.subs.remove(o); p.subs.add(sub); return true }
                return false
            }
        }
        p.subs.add(sub)
        true
    }

    // ------------------------------------------- juntar blocos do mesmo balão

    private class Grp(val r: Rect, val parts: ArrayList<Pair<Rect, String>>)

    private fun canJoin(a: Rect, b: Rect, maxArea: Long): Boolean {
        val aV = a.height() > a.width() * 1.5f
        val bV = b.height() > b.width() * 1.5f
        if (aV != bV) return false
        val u = Rect(a)
        u.union(b)
        if (u.width().toLong() * u.height() > maxArea) return false
        if (aV) {
            val vo = min(a.bottom, b.bottom) - max(a.top, b.top)
            val gap = max(a.left, b.left) - min(a.right, b.right)
            return vo >= 0.6f * min(a.height(), b.height()) && gap >= -4 && gap <= 0.8f * min(a.width(), b.width())
        }
        val ho = min(a.right, b.right) - max(a.left, b.left)
        val gap = max(a.top, b.top) - min(a.bottom, b.bottom)
        val cxd = abs(a.centerX() - b.centerX())
        val maxGap = max(10f, 0.5f * min(a.height(), b.height()))
        return ho >= 0.4f * min(a.width(), b.width()) && gap >= -4 && gap <= maxGap &&
            cxd <= 0.35f * max(a.width(), b.width())
    }

    private fun mergeBalloons(blocks: List<Pair<Rect, String>>, maxRegionArea: Long): List<Pair<Rect, String>> {
        if (blocks.size < 2) return blocks
        val maxArea = (maxRegionArea * 0.3).toLong()
        val groups = blocks.map { Grp(Rect(it.first), arrayListOf(it)) }.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in groups.indices) for (j in i + 1 until groups.size) {
                if (canJoin(groups[i].r, groups[j].r, maxArea)) {
                    groups[i].r.union(groups[j].r)
                    groups[i].parts.addAll(groups[j].parts)
                    groups.removeAt(j)
                    changed = true
                    break@loop
                }
            }
        }
        return groups.map { g ->
            if (g.parts.size == 1) g.parts[0]
            else {
                val vertical = g.parts.all { it.first.height() > it.first.width() * 1.5f }
                val ordered = if (vertical) g.parts.sortedWith(compareByDescending<Pair<Rect, String>> { it.first.centerX() }.thenBy { it.first.top })
                else g.parts.sortedWith(compareBy<Pair<Rect, String>>({ it.first.top }, { it.first.left }))
                val cjk = ordered.any { p -> p.second.any { isCjk(it) } }
                val merged = joinText(ordered.map { it.second }, cjk)
                val cs = ordered.mapNotNull { confByText[it.second] }
                if (cs.isNotEmpty()) confByText[merged] = cs.min()
                g.r to merged
            }
        }
    }

    // ---------------------------------------------------------- retradução

    private fun fail(sub: Subtitle, prev: SubState, msg: String) { sub.state = prev; notifyText(msg) }

    private fun retranslate(sub: Subtitle, newTarget: String?) {
        if (retrBusy) return
        retrBusy = true
        notifyText("Traduzindo novamente…")
        scope.launch {
            val prev = sub.state
            try {
                sub.state = SubState.TRANSLATING
                val t0 = SystemClock.uptimeMillis()
                sub.hidden = true
                postUpdate()
                waitNewFrame(t0)
                val cap = synchronized(imgLock) { held?.let { Triple(toBitmap(it), sx, sy) } }
                sub.hidden = false
                postUpdate()
                if (cap == null) { fail(sub, prev, "Não consegui capturar a tela"); return@launch }
                val (bmp, cx, cy) = cap
                val m = 14
                val l = (sub.x - cx - m).coerceIn(0, bmp.width - 2)
                val t = (sub.y - cy - m).coerceIn(0, bmp.height - 2)
                val r = (sub.x + sub.w - cx + m).coerceIn(l + 1, bmp.width)
                val b = (sub.y + sub.h - cy + m).coerceIn(t + 1, bmp.height)
                if (r - l < 10 || b - t < 10) { bmp.recycle(); fail(sub, prev, "A legenda não está visível na tela"); return@launch }
                val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
                bmp.recycle()
                val blocks = ocrBlocks(crop, "auto")
                if (blocks.isEmpty()) { crop.recycle(); fail(sub, prev, "Não encontrei texto nessa região"); return@launch }

                val vertical = blocks.count { it.first.height() > it.first.width() * 1.5f } * 2 > blocks.size
                val ordered = if (vertical)
                    blocks.sortedWith(compareByDescending<Pair<Rect, String>> { it.first.centerX() }.thenBy { it.first.top })
                else blocks.sortedWith(compareBy<Pair<Rect, String>>({ it.first.top }, { it.first.left }))
                val texts = ordered.map { it.second }
                val cjk = texts.any { s -> s.any { isCjk(it) } }
                var text = joinText(texts, cjk)
                var conf: Float? = ordered.mapNotNull { confByText[it.second] }.minOrNull()

                // leitura melhorada (mais nitidez e contraste); fica com a de maior confiança
                val better = enhanceRead(crop, Rect(0, 0, crop.width, crop.height), "auto")
                crop.recycle()
                val bc = better?.second
                if (better != null && better.first.isNotBlank() && bc != null && (conf == null || bc > conf)) { text = better.first; conf = bc }

                val src = sourceLang(text, "auto")
                val tgt = newTarget ?: sub.targetLang ?: target
                if (src == null) { fail(sub, prev, "Não consegui identificar o idioma"); return@launch }
                if (src == tgt) { fail(sub, prev, "O texto já está no idioma de destino"); return@launch }

                val old = Cand(if (prev == SubState.EDITED) "Anterior (sua correção)" else "Anterior", sub.translated, sub.engine)
                val cands = ArrayList<Cand>()
                cands += old
                SfxDict.lookup(text)?.let { cands += Cand("Efeito sonoro", it, "efeito sonoro") }
                offlineTranslate(TermDb.norm(text), src, tgt, true)?.let { cands += Cand("Automática (offline)", it, "offline") }
                val engine = Engines.plan(this@TranslatorService, src)
                if (engine != "offline") {
                    val res = onlineTranslate(engine, TermDb.norm(text), src, tgt, sub.styleKey, page, sub.rect(), sub.id)
                    if (res.text != null) cands += Cand(if (engine == "claude") "Contextual (IA Claude)" else "Online (Google)", res.text, engine)
                    else reportOnlineError(res.error)
                }
                if (cands.size == 1) { fail(sub, prev, "Nenhuma tradução disponível agora (veja os pacotes offline)"); return@launch }
                if (cands.drop(1).all { it.text == old.text }) { fail(sub, prev, "A tradução continua igual"); return@launch }

                val sfxIdx = cands.indexOfFirst { it.engine == "efeito sonoro" }
                val best = if (sfxIdx > 0) sfxIdx else cands.size - 1
                val pend = Pending(sub, cands, text, src, conf ?: -1f, prev, sub.targetLang, sub.engine, sub.conf,
                    sub.original, sub.sourceLang, newTarget)
                if (prev != SubState.EDITED) applyIndex(pend, best) else sub.state = prev   // correção manual só muda com autorização
                pending = pend
                pagesDirty = true
                postUpdate()
                notifyText("Nova tradução pronta")
                withContext(Dispatchers.Main) {
                    menuOpen = true
                    menu?.showCompare(sub, overlay?.boxOf(sub) ?: RectF((sub.x - sx).toFloat(), (sub.y - sy).toFloat(),
                        (sub.x + sub.w - sx).toFloat(), (sub.y + sub.h - sy).toFloat()),
                        Compare(text, src, conf ?: -1f, cands, pend.applied, prev == SubState.EDITED))
                }
            } finally {
                sub.hidden = false
                if (sub.state == SubState.TRANSLATING) sub.state = prev
                retrBusy = false
            }
        }
    }

    // ---------------------------------------------------------------- OCR

    private fun isCjk(c: Char) = c in '\u3040'..'\u30ff' || c in '\u4e00'..'\u9fff' || c in '\uac00'..'\ud7af'
    private fun letters(s: String) = s.count { it.isLetter() }

    /** Confiança do OCR do bloco (média das linhas). Lê por reflexão para não depender da versão do ML Kit. */
    private fun blockConf(b: Text.TextBlock): Float? {
        val vals = b.lines.mapNotNull { l ->
            runCatching { l.javaClass.getMethod("getConfidence").invoke(l) as Float }.getOrNull()
        }.filter { it > 0.001f }
        return if (vals.isEmpty()) null else vals.average().toFloat()
    }

    private suspend fun ocrBlocks(bmp: Bitmap, mode: String): List<Pair<Rect, String>> {
        val scale = (ocrW.toFloat() / bmp.width).coerceIn(0.4f, 1.6f)
        val small = if (abs(scale - 1f) > 0.05f)
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val res = recognize(small, mode).map { (r, t) ->
            Rect((r.left / scale).toInt(), (r.top / scale).toInt(), (r.right / scale).toInt(), (r.bottom / scale).toInt()) to t
        }
        if (small !== bmp) small.recycle()
        return res
    }

    private suspend fun recognize(bmp: Bitmap, mode: String): List<Pair<Rect, String>> = coroutineScope {
        val img = InputImage.fromBitmap(bmp, 0)
        val auto = mode == "auto"
        val recs = when (mode) {
            "auto" -> listOf(ko to true, jp to true, zh to true, latin to false)
            "ja" -> listOf(jp to true)
            "zh" -> listOf(zh to true)
            "ko" -> listOf(ko to true)
            else -> listOf(latin to false)
        }
        val rs = recs.map { (r, _) -> async { runCatching { r.process(img).await() }.getOrNull() } }.awaitAll()
        if (confByText.size > 600) confByText.clear()
        val cand = ArrayList<Pair<Rect, String>>()
        rs.forEachIndexed { idx, t ->
            t?.textBlocks?.forEach { b ->
                val box = b.boundingBox ?: return@forEach
                val raw = b.text.replace(Regex("(\\p{L})[-\u2010\u2011\u2012\u2013]\\s*\\n\\s*(\\p{L})"), "\$1\$2")
                val cjkText = raw.any { isCjk(it) }
                val txt = TermDb.norm(raw.replace("\n", if (cjkText) "" else " "))
                if (letters(txt) < 2 || box.width() < 10 || box.height() < 10) return@forEach
                var keep = true
                if (auto) {
                    val share = txt.count { isCjk(it) }.toFloat() / txt.length
                    keep = if (recs[idx].second) share >= 0.3f else share < 0.3f
                }
                if (keep) {
                    cand += box to txt
                    blockConf(b)?.let { confByText[txt] = it }
                }
            }
        }
        val kept = ArrayList<Pair<Rect, String>>()
        for (c in cand) {
            if (kept.none { overlap(it.first, c.first) > 0.4f }) kept += c
        }
        kept
    }

    /** Segunda leitura de um trecho com baixa confiança: amplia, tira a cor e aumenta o contraste. */
    private suspend fun enhanceRead(src: Bitmap, rect: Rect, mode: String): Pair<String, Float?>? {
        val pad = 8
        val r = Rect(rect.left - pad, rect.top - pad, rect.right + pad, rect.bottom + pad)
        if (!r.intersect(0, 0, src.width, src.height) || r.width() < 8 || r.height() < 8) return null
        val crop = Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height())
        val up = Bitmap.createScaledBitmap(crop, (crop.width * 2).coerceAtMost(2000), (crop.height * 2).coerceAtMost(2000), true)
        val out = Bitmap.createBitmap(up.width, up.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        val k = 1.6f
        val tt = (-0.5f * k + 0.5f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(k, 0f, 0f, 0f, tt, 0f, k, 0f, 0f, tt, 0f, 0f, k, 0f, tt, 0f, 0f, 0f, 1f, 0f)))
        Canvas(out).drawBitmap(up, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        val blocks = recognize(out, mode)
        if (crop !== src) crop.recycle()
        if (up !== crop) up.recycle()
        out.recycle()
        if (blocks.isEmpty()) return null
        val ordered = blocks.sortedBy { it.first.top }
        val texts = ordered.map { it.second }
        val text = joinText(texts, texts.any { s -> s.any { isCjk(it) } })
        return text to ordered.mapNotNull { confByText[it.second] }.minOrNull()
    }

    // ----------------------------------------------------------- tradução

    private suspend fun sourceLang(text: String, mode: String): String? {
        if (text.any { it in '\uac00'..'\ud7af' }) return TranslateLanguage.KOREAN
        if (text.any { it in '\u3040'..'\u30ff' }) return TranslateLanguage.JAPANESE
        if (text.any { it in '\u4e00'..'\u9fff' }) return TranslateLanguage.CHINESE
        if (text.length >= 12 && mode != "auto") {
            val c = runCatching { langId.identifyLanguage(text).await() }.getOrNull()
            if (c != null && c != "und" && c == target) return c
        }
        when (mode) {
            "id" -> return TranslateLanguage.INDONESIAN
            "en", "ja", "zh", "ko" -> return TranslateLanguage.ENGLISH
        }
        val code = runCatching { langId.identifyLanguage(text).await() }.getOrNull() ?: return null
        return if (code == "und") TranslateLanguage.ENGLISH else TranslateLanguage.fromLanguageTag(code)
    }

    private fun reportOnlineError(e: String?) {
        val now = SystemClock.uptimeMillis()
        if (now - lastErrAt > 20000) { lastErrAt = now; notifyText("Tradução online: ${e ?: "falhou"}. Usando a tradução offline.") }
    }

    private fun contextFor(p: Page, ref: Rect, selfId: Long, n: Int): List<Pair<String, String>> =
        p.subs.filter { it.id != selfId && it.state != SubState.FAILED && it.y < ref.bottom }
            .sortedWith(compareBy<Subtitle>({ it.y / 100 }, { -it.x }))
            .takeLast(n).map { it.original to it.translated }

    private suspend fun onlineTranslate(
        engine: String, norm: String, src: String, tgt: String, styleKey: String?, p: Page?, ref: Rect?, selfId: Long
    ): OnlineResult {
        val style = styleKey ?: sp.getString(K.STYLE, "natural") ?: "natural"
        return netSem.withPermit {
            if (engine == "claude") {
                val fast = sp.getString(K.QUALITY, "contextual") == "fast"
                val n = if (fast) 0 else sp.getInt(K.CTX, 4)
                val ctx = if (n > 0 && p != null && ref != null) contextFor(p, ref, selfId, n) else emptyList()
                Engines.claude(this@TranslatorService, norm, src, tgt, style, db.glossary(norm, tgt), ctx,
                    sp.getString(K.MODEL, "claude-haiku-5-5") ?: "claude-haiku-5-5")
            } else Engines.google(this@TranslatorService, norm, src, tgt)
        }
    }

    private suspend fun offlineTranslate(norm: String, src: String, tgt: String, force: Boolean): String? {
        val cleaned = cleanText(norm, src)
        val input = if (force) cleaned else db.preSubstitute(cleaned, tgt)
        val tr = translatorFor(src, tgt) ?: return null
        return runCatching { tr.translate(input).await() }.getOrNull()
    }

    /** Ordem: sua memória > dicionário de efeitos > cache > IA/online (se autorizado) > offline. */
    private suspend fun translateSmart(
        text: String, src: String, tgt: String, styleKey: String?, p: Page?, ref: Rect?, selfId: Long
    ): Pair<String, String>? {
        val norm = TermDb.norm(text)
        db.exact(norm, tgt)?.let { return it to "memória" }
        SfxDict.lookup(norm)?.let { return it to "efeito sonoro" }
        val style = styleKey ?: sp.getString(K.STYLE, "natural") ?: "natural"
        val engine = Engines.plan(this, src)
        val key = "$engine|$style|$src>$tgt>$norm"
        cache[key]?.let { return it to engine }
        if (engine != "offline") {
            val r = onlineTranslate(engine, norm, src, tgt, styleKey, p, ref, selfId)
            val out = r.text
            if (out != null) { cache[key] = out; return out to engine }
            reportOnlineError(r.error)
        }
        val off = offlineTranslate(norm, src, tgt, false) ?: return null
        return off to "offline"
    }

    private suspend fun translateBlock(bmp: Bitmap, rect: Rect, text: String, mode: String, p: Page?, wr: Rect?): Tr? {
        val src = sourceLang(text, mode) ?: return null
        if (src == target) return null
        val r = translateSmart(text, src, target, null, p, wr, -1L) ?: return null
        if (r.first.equals(text, true)) return null
        val bg = sampleBackground(bmp, rect)
        val fg = if (ColorUtils.calculateLuminance(bg) > 0.45) 0xFF111111.toInt() else 0xFFF5F5F5.toInt()
        return Tr(r.first, src, bg, fg, r.second)
    }

    private fun cleanText(t0: String, src: String): String {
        var t = t0
        if (src == "ja" || src == "zh") {
            val cjkChars = "\u3040-\u30ff\u4e00-\u9fff\uff00-\uffef"
            t = Regex("(?<=[$cjkChars])\\s+(?=[$cjkChars])").replace(t, "")
        } else if (src != "ko") {
            t = Regex("\\s+([,.;:!?])").replace(t, "\$1")
            t = Regex("(?<=\\p{L})\\|(?=\\p{L})").replace(t, "I")
            val letters = t.count { it.isLetter() }
            val upper = t.count { it.isUpperCase() }
            if (letters >= 4 && upper >= letters * 0.7) t = sentenceCase(t.lowercase(), src)
        }
        return TermDb.norm(t)
    }

    private fun sentenceCase(s: String, src: String): String {
        val sb = StringBuilder(s.length)
        var cap = true
        for (ch in s) {
            if (cap && ch.isLetter()) { sb.append(ch.uppercaseChar()); cap = false }
            else {
                sb.append(ch)
                if (ch == '.' || ch == '!' || ch == '?' || ch == '\u2026') cap = true
                else if (ch.isLetter()) cap = false
            }
        }
        val out = sb.toString()
        return if (src == "en") Regex("\\bi\\b").replace(out, "I") else out
    }

    private fun joinText(parts: List<String>, cjk: Boolean): String {
        val sb = StringBuilder()
        for (p in parts) {
            if (sb.isEmpty()) { sb.append(p); continue }
            when {
                cjk -> sb.append(p)
                sb.last() == '-' && sb.length >= 2 && sb[sb.length - 2].isLetter() && p.firstOrNull()?.isLetter() == true -> {
                    sb.setLength(sb.length - 1); sb.append(p)
                }
                else -> sb.append(' ').append(p)
            }
        }
        return TermDb.norm(sb.toString())
    }

    private suspend fun translatorFor(src: String, tgt: String): Translator? = modelLock.withLock {
        val k = "$src>$tgt"
        translators[k]?.let { return it }
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        val ok = runCatching { t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await() }.isSuccess
        if (ok) { translators[k] = t; t } else { t.close(); null }
    }

    private fun sampleBackground(b: Bitmap, r: Rect): Int {
        var rs = 0; var gs = 0; var bs = 0; var n = 0
        fun px(x: Int, y: Int) {
            val c = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))
            rs += c shr 16 and 255; gs += c shr 8 and 255; bs += c and 255; n++
        }
        val steps = 8
        for (i in 0..steps) {
            val x = r.left + r.width() * i / steps
            val y = r.top + r.height() * i / steps
            px(x, r.top - 3); px(x, r.bottom + 3); px(r.left - 3, y); px(r.right + 3, y)
        }
        return 0xFF shl 24 or (rs / n shl 16) or (gs / n shl 8) or (bs / n)
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val pad = p.rowStride - p.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + pad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        if (pad == 0) return full
        val out = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        full.recycle()
        return out
    }

    // ------------------------------------------------------- notificação

    private fun createChannel() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Tradução", NotificationManager.IMPORTANCE_LOW))
    }

    private fun act(a: String, label: String) = NotificationCompat.Action(
        0, label, PendingIntent.getService(this, a.hashCode(),
            Intent(this, TranslatorService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE))

    private fun buildNotification(paused: Boolean, text: String?): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Live Screen Translator")
            .setContentText(text ?: if (paused) "Pausado" else "Traduzindo a tela…")
            .setOngoing(true)
            .addAction(if (paused) act(ACTION_RESUME, "Retomar") else act(ACTION_PAUSE, "Pausar"))
            .addAction(act(ACTION_STOP, "Encerrar"))
            .build()

    private fun notify(paused: Boolean) =
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification(paused, null))

    /** Avisos vão na notificação (um Toast apareceria na tela e seria lido pelo OCR). */
    private fun notifyText(text: String?) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(1, buildNotification(state.value == State.PAUSED, text))
    }

    // ---------------------------------------------------------- encerrar

    private fun shutdown() {
        job?.cancel()
        reloadHook = null
        runCatching { PageStore.save(this, pages.toList()) }
        main.removeCallbacks(touchOff)
        menu?.dismiss()
        bubble?.hide()
        overlay?.let { v -> runCatching { wm.removeView(v) } }
        overlay = null
        synchronized(imgLock) { held?.close(); held = null }
        display?.release(); reader?.close(); projection?.stop()
        translators.values.forEach { it.close() }; translators.clear()
        state.value = State.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
