package com.livescreentranslator

import android.os.Bundle
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel
import java.io.File
import java.util.Locale

/** Pacotes de idioma para tradução sem internet. */
class OfflineActivity : FormActivity() {

    private val mgr = RemoteModelManager.getInstance()
    private val langs = listOf(
        "ja" to "Japonês", "ko" to "Coreano", "zh" to "Chinês", "en" to "Inglês", "pt" to "Português (Brasil)",
        "es" to "Espanhol", "fr" to "Francês", "de" to "Alemão", "it" to "Italiano", "id" to "Indonésio"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("Idiomas offline")
        refresh()
    }

    private fun dirSize(f: File): Long = if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

    private fun refresh() {
        mgr.getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { set -> render(set.map { it.language }.toSet()) }
            .addOnFailureListener { render(emptySet()) }
    }

    private fun conditions(): DownloadConditions {
        val b = DownloadConditions.Builder()
        if (sp.getBoolean(K.WIFI, true)) b.requireWifi()
        return b.build()
    }

    private fun download(code: String, done: () -> Unit = {}) {
        Toast.makeText(this, "Baixando… (cerca de 30 MB)", Toast.LENGTH_SHORT).show()
        mgr.download(TranslateRemoteModel.Builder(code).build(), conditions())
            .addOnSuccessListener { Toast.makeText(this, "Pacote baixado", Toast.LENGTH_SHORT).show(); done(); refresh() }
            .addOnFailureListener { Toast.makeText(this, "Falha no download. Confira a internet e a opção de só Wi-Fi.", Toast.LENGTH_LONG).show() }
    }

    private fun render(have: Set<String>) {
        content.removeAllViews()
        val used = dirSize(filesDir) + dirSize(noBackupFilesDir) + dirSize(cacheDir)
        header("ESPAÇO")
        hint("Dados do app (inclui os pacotes baixados): ${String.format(Locale.US, "%.1f", used / 1048576.0)} MB. O ML Kit guarda os pacotes sozinho, não dá para escolher a pasta.")
        switchRow("Baixar somente no Wi-Fi", { sp.getBoolean(K.WIFI, true) }, { sp.edit().putBoolean(K.WIFI, it).apply() })

        header("DISPONIBILIDADE OFFLINE")
        for ((src, name) in listOf("ja" to "Japonês", "ko" to "Coreano", "zh" to "Chinês", "en" to "Inglês")) {
            val ok = (src in have) && ("pt" in have)
            content.addView(label("$name → Português (BR): " + if (ok) "pronto offline ✔" else "faltam pacotes", 14f, if (ok) 0xFF69F0AE.toInt() else MUTED))
        }
        hint("Cada par precisa do idioma de origem e do português. O inglês é usado como ponte e baixa junto quando for necessário. O ML Kit não tem pacote separado para chinês tradicional.")

        header("PACOTES (cerca de 30 MB cada)")
        for ((code, name) in langs) {
            val c = card()
            c.addView(label(name, 16f))
            c.addView(label(if (code in have) "✔ Baixado" else "Não baixado", 13f, if (code in have) 0xFF69F0AE.toInt() else MUTED))
            val model = TranslateRemoteModel.Builder(code).build()
            if (code in have) {
                c.addView(rowButtons(
                    link("Atualizar") { mgr.deleteDownloadedModel(model).addOnCompleteListener { download(code) } },
                    link("Excluir", 0xFFFF6B6B.toInt()) { mgr.deleteDownloadedModel(model).addOnCompleteListener { refresh() } }
                ))
            } else c.addView(rowButtons(link("Baixar (≈30 MB)") { download(code) }))
        }
        hint("Para os pares prioritários: baixe Japonês, Coreano, Chinês e Inglês, mais o Português.")
    }
}
