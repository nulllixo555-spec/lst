package com.livescreentranslator

import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Mecanismos de tradução, IA, estilos, balões e gestos. */
class SettingsActivity : FormActivity() {

    private val engines = listOf(
        "Offline (no celular)" to "offline",
        "Automático (online quando houver chave e internet)" to "auto",
        "Claude (IA, com contexto)" to "claude",
        "Google Cloud Translation" to "google"
    )
    private val gestureActions = listOf(
        "Abrir menu da legenda" to "menu", "Editar tradução" to "edit", "Traduzir novamente" to "retranslate",
        "Copiar tradução" to "copy", "Ocultar esta legenda" to "hide", "Ocultar/mostrar todas" to "toggle", "Nenhuma ação" to "none"
    )
    private val bubbleActions = listOf("Ligar/desligar o modo toque" to "touch", "Pausar/continuar a tradução" to "pause")

    private fun put(k: String, v: String) { sp.edit().putString(k, v).apply(); TranslatorService.reloadHook?.invoke() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("Tradução e IA")
        build()
    }

    private fun alert(title: String, msg: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun keyRow(name: String, title: String) {
        val saved = Secrets.get(this, name)
        content.addView(label(if (saved.isEmpty()) "$title: não configurada" else "$title: salva (final …${saved.takeLast(4)})").apply { setPadding(0, dp(12), 0, 0) })
        val et = EditText(this)
        et.hint = "Cole a chave aqui"; et.setTextColor(WHITE); et.setHintTextColor(MUTED)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        content.addView(et)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(link("Salvar chave") {
            val v = et.text.toString().trim()
            if (v.length < 10) alert("Chave inválida", "Cole a chave completa.") else { Secrets.set(this, name, v); build() }
        })
        if (saved.isNotEmpty()) row.addView(link("Remover", 0xFFFF6B6B.toInt()) { Secrets.set(this, name, ""); build() })
        content.addView(row)
    }

    private fun build() {
        content.removeAllViews()

        header("MECANISMO DE TRADUÇÃO")
        spinnerRow("Mecanismo padrão", engines.map { it.first }, engines.indexOfFirst { it.second == sp.getString(K.ENGINE, "offline") }) {
            put(K.ENGINE, engines[it].second)
        }
        val q = listOf("Rápida (sem contexto)" to "fast", "Contextual (usa as falas anteriores)" to "contextual")
        spinnerRow("Modo da IA", q.map { it.first }, q.indexOfFirst { it.second == sp.getString(K.QUALITY, "contextual") }) { put(K.QUALITY, q[it].second) }
        sliderRow("Falas anteriores enviadas como contexto", 0, 10, { sp.getInt(K.CTX, 4) }, { sp.edit().putInt(K.CTX, it).apply() }, { if (it == 0) "nenhuma" else "$it" })
        hint("Menos contexto gasta menos crédito e processamento.")

        content.addView(label("Modelo do Claude").apply { setPadding(0, dp(10), 0, 0) })
        val model = EditText(this)
        model.setText(sp.getString(K.MODEL, "claude-haiku-5-5")); model.setTextColor(WHITE)
        model.setOnFocusChangeListener { _, focus -> if (!focus) put(K.MODEL, model.text.toString().trim().ifEmpty { "claude-haiku-5-5" }) }
        content.addView(model)
        hint("claude-haiku-5-5 é o mais barato e rápido. claude-sonnet-5-5 traduz melhor, custa mais.")

        header("CHAVES DE API")
        hint("As chaves ficam só neste celular, criptografadas, e não entram em backups. O app nunca as mostra por inteiro.")
        keyRow("claude", "Chave do Claude (console.anthropic.com)")
        keyRow("google", "Chave do Google Cloud Translation")

        header("PRIVACIDADE")
        switchRow("Autorizo enviar o TEXTO reconhecido ao serviço escolhido", { sp.getBoolean(K.CONSENT, false) }) {
            sp.edit().putBoolean(K.CONSENT, it).apply(); TranslatorService.reloadHook?.invoke()
        }
        hint("Só o texto lido na tela e, na IA, o contexto e o glossário. Imagens e histórico de leitura nunca são enviados. Desligado, tudo é traduzido no celular.")
        button("Testar tradução online", outlined = true) { testOnline() }

        header("MECANISMO POR IDIOMA")
        val per = listOf("Padrão" to "default", "Offline" to "offline", "Claude" to "claude", "Google" to "google")
        val saved = runCatching { JSONObject(sp.getString(K.LANGENG, "{}") ?: "{}") }.getOrDefault(JSONObject())
        for ((code, name) in listOf("ja" to "Japonês", "ko" to "Coreano", "zh" to "Chinês", "en" to "Inglês", "id" to "Indonésio")) {
            spinnerRow("Para texto em $name", per.map { it.first }, per.indexOfFirst { it.second == saved.optString(code, "default") }) { pos ->
                saved.put(code, per[pos].second); put(K.LANGENG, saved.toString())
            }
        }

        header("ESTILO DE TRADUÇÃO")
        spinnerRow("Estilo padrão", TStyles.list.map { it.second }, TStyles.list.indexOfFirst { it.first == sp.getString(K.STYLE, "natural") }) {
            put(K.STYLE, TStyles.list[it].first)
        }
        hint("O estilo muda a tradução da IA. O tradutor offline não aceita instruções de estilo. Para um estilo só numa legenda: toque na legenda > Estilo de tradução.")

        header("BALÕES")
        switchRow("Reconstruir balões de mangá (quando for possível)", { sp.getBoolean(K.BALLOON, true) }) { sp.edit().putBoolean(K.BALLOON, it).apply() }
        hint("O app procura o contorno do balão e coloca a tradução dentro dele. Se não achar, usa a legenda comum.")

        header("GESTOS")
        hint("Os gestos só funcionam com o modo toque ligado (botão 👆), porque o Android não deixa a sobreposição receber toques sem bloquear o app de baixo.")
        val gs = listOf(
            Triple("Um toque", K.G_TAP, "menu"), Triple("Dois toques", K.G_DOUBLE, "edit"),
            Triple("Toque prolongado", K.G_LONG, "retranslate"), Triple("Dois dedos", K.G_TWO, "toggle")
        )
        for ((title, key, def) in gs) {
            spinnerRow(title, gestureActions.map { it.first }, gestureActions.indexOfFirst { it.second == sp.getString(key, def) }) { put(key, gestureActions[it].second) }
        }
        spinnerRow("Toque no botão flutuante", bubbleActions.map { it.first }, bubbleActions.indexOfFirst { it.second == sp.getString(K.G_BUBBLE, "touch") }) {
            put(K.G_BUBBLE, bubbleActions[it].second)
        }
        hint("Se você escolher pausar/continuar no botão, ligue o modo toque pelo toque prolongado do app ou mantenha o padrão.")
    }

    private fun testOnline() {
        val plan = Engines.plan(this, "ja")
        if (plan == "offline") {
            alert("Online indisponível", "Verifique: autorização de envio ligada, chave salva, mecanismo diferente de Offline e internet ativa.")
            return
        }
        lifecycleScope.launch {
            val r = if (plan == "claude")
                Engines.claude(this@SettingsActivity, "こんにちは、元気ですか？", "ja", "pt", "natural", emptyList(), emptyList(),
                    sp.getString(K.MODEL, "claude-haiku-5-5") ?: "claude-haiku-5-5")
            else Engines.google(this@SettingsActivity, "こんにちは、元気ですか？", "ja", "pt")
            alert(if (r.text != null) "Funcionou" else "Falhou", r.text ?: "Erro: ${r.error}")
        }
    }
}
