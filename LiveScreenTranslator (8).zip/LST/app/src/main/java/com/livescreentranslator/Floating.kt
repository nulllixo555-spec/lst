package com.livescreentranslator

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object Langs {
    val list = listOf(
        "Português (Brasil)" to "pt", "English" to "en", "Español" to "es", "Français" to "fr",
        "Deutsch" to "de", "Italiano" to "it", "日本語" to "ja", "Bahasa Indonesia" to "id"
    )
}

/** Botão flutuante que liga/desliga o "modo toque" (toque curto) e reexibe legendas ocultas (toque longo). */
class Bubble(
    private val ctx: Context, private val wm: WindowManager, private val sw: Int, private val sh: Int,
    private val onToggle: () -> Unit, private val onLong: () -> Unit
) {
    private val d = ctx.resources.displayMetrics.density
    private val size = (52 * d).toInt()
    private val tv = TextView(ctx)
    private val handler = Handler(Looper.getMainLooper())
    private val lp = WindowManager.LayoutParams(
        size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = sw - size - (6 * d).toInt(); y = (sh * 0.45f).toInt() }
    private var shown = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false
    private var longFired = false

    init {
        tv.text = "👆"; tv.textSize = 22f; tv.gravity = Gravity.CENTER
        setActive(false)
        tv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; longFired = false
                    handler.postDelayed({ if (!moved) { longFired = true; onLong() } }, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > 12 * d || abs(dy) > 12 * d) { moved = true; handler.removeCallbacksAndMessages(null) }
                    if (moved) {
                        lp.x = (startX + dx).toInt().coerceIn(0, sw - size)
                        lp.y = (startY + dy).toInt().coerceIn(0, sh - size)
                        if (shown) wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacksAndMessages(null)
                    if (!moved && !longFired) onToggle()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacksAndMessages(null)
            }
            true
        }
    }

    fun setActive(on: Boolean) {
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) 0xFF6C63FF.toInt() else 0xAA2A2F55.toInt())
            setStroke((2 * d).toInt(), 0xCCFFFFFF.toInt())
        }
    }

    fun rect() = Rect(lp.x, lp.y, lp.x + size, lp.y + size)
    fun show() { if (!shown) { wm.addView(tv, lp); shown = true } }
    fun hide() { if (shown) { runCatching { wm.removeView(tv) }; shown = false } }
}

class Cand(val label: String, val text: String, val engine: String)

class Compare(val recognized: String, val lang: String, val conf: Float, val cands: List<Cand>, val applied: Int, val manual: Boolean)

interface MenuActions {
    fun retranslate(sub: Subtitle)
    fun saveEdit(sub: Subtitle, text: String, term: Triple<String, String, String>?)
    fun setTarget(sub: Subtitle, lang: String)
    fun copy(sub: Subtitle)
    fun setDuration(sub: Subtitle, ms: Long)
    fun applyStyle(sub: Subtitle, s: SubStyle?)
    fun hide(sub: Subtitle)
    fun choose(sub: Subtitle, index: Int)
    fun setStyle(sub: Subtitle, key: String?)
    fun closed()
}

/** Menu flutuante da legenda e seus painéis (editar, original, idioma, duração, estilo, comparação). */
class FloatingMenu(
    ctx: Context, private val wm: WindowManager, private val sw: Int, private val sh: Int,
    private val styleProvider: () -> SubStyle, private val actions: MenuActions
) {
    private val c: Context = ContextThemeWrapper(ctx, R.style.Theme_LST)
    private val d = ctx.resources.displayMetrics.density
    private var view: View? = null
    private var lastAnchor = RectF(0f, sh * 0.3f, sw.toFloat(), sh * 0.35f)
    private val WHITE = Color.WHITE
    private val MUTED = 0xFF9AA0C8.toInt()
    private val ACCENT = 0xFF6C63FF.toInt()

    private fun dp(v: Int) = (v * d).toInt()

    private fun box() = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(6), dp(6), dp(6), dp(6))
        background = GradientDrawable().apply { cornerRadius = 18 * d; setColor(0xF21A1E3C.toInt()); setStroke(dp(2), ACCENT) }
    }

    private fun text(t: String, size: Float = 15f, color: Int = WHITE) =
        TextView(c).apply { text = t; textSize = size; setTextColor(color) }

    private fun title(t: String) = text(t, 13f, ACCENT).apply { setPadding(dp(12), dp(8), dp(12), dp(4)) }

    private fun row(t: String, onClick: () -> Unit) = text(t, 16f).apply {
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setOnClickListener { onClick() }
    }

    private fun button(t: String, color: Int = ACCENT, onClick: () -> Unit) = text(t, 15f).apply {
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(12), dp(8), dp(12))
        background = GradientDrawable().apply { cornerRadius = 12 * d; setColor(color) }
        setOnClickListener { onClick() }
    }

    private fun buttons(vararg b: View): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(8), 0, 0)
        for (v in b) addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
    }

    private fun editBox(hint: String, value: String) = EditText(c).apply {
        setText(value); this.hint = hint; setTextColor(WHITE); setHintTextColor(MUTED); textSize = 15f
    }

    private fun scroll(inner: View, maxFrac: Float): ScrollView = ScrollView(c).apply { addView(inner) }.also {
        it.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (sh * maxFrac).toInt())
    }

    private fun yFor(h: Int): Int {
        var y = lastAnchor.bottom.toInt() + dp(10)
        if (y + h > sh - dp(20)) y = max(dp(20), lastAnchor.top.toInt() - h - dp(10))
        return y
    }

    private fun removeView() { view?.let { runCatching { wm.removeView(it) } }; view = null }

    private fun present(v: View, y: Int, focusable: Boolean) {
        removeView()
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(
            min(sw * 0.92f, 360 * d).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            this.y = y
            if (focusable) softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }
        wm.addView(v, lp)
        view = v
    }

    private fun hideKeyboard(v: View) {
        (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    fun dismiss() { removeView(); actions.closed() }

    // ---------------------------------------------------------------- menu

    fun showMenu(sub: Subtitle, anchor: RectF) {
        lastAnchor = anchor
        val b = box()
        val inner = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(row("🔄  Traduzir novamente") { dismiss(); actions.retranslate(sub) })
        inner.addView(row("✏️  Editar tradução") { showEdit(sub) })
        inner.addView(row("🧠  Estilo de tradução") { showStyles(sub) })
        inner.addView(row("📖  Ver texto original") { showInfo(sub) })
        inner.addView(row("🌐  Alterar idioma de destino") { showLang(sub) })
        inner.addView(row("📋  Copiar tradução") { actions.copy(sub); dismiss() })
        inner.addView(row("⏱️  Ajustar duração") { showDuration(sub) })
        inner.addView(row("🎨  Personalizar só esta legenda") { showStyle(sub) })
        inner.addView(row("❌  Ocultar legenda") { actions.hide(sub); dismiss() })
        b.addView(scroll(inner, 0.62f))
        present(b, yFor((sh * 0.5f).toInt()), false)
    }

    // --------------------------------------------------------------- editar

    private fun showEdit(sub: Subtitle) {
        val b = box()
        b.addView(title("EDITAR TRADUÇÃO"))
        val et = editBox("Tradução", sub.translated).apply { minLines = 3; maxLines = 6 }
        b.addView(et)
        var remember = false
        var kindIdx = 0
        val kinds = TermDb.KINDS.filter { it != "Frase" }
        val toggle = text("☐  Lembrar como termo / nome", 14f).apply { setPadding(dp(12), dp(12), dp(12), dp(4)) }
        val termBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val kindBtn = text("Tipo: ${kinds[0]}  ▸", 14f, ACCENT).apply { setPadding(dp(12), dp(6), dp(12), dp(6)) }
        kindBtn.setOnClickListener { kindIdx = (kindIdx + 1) % kinds.size; kindBtn.text = "Tipo: ${kinds[kindIdx]}  ▸" }
        val etSrc = editBox("Trecho original (ex.: nome do personagem)", if (sub.original.length <= 40) sub.original else "")
        val etTgt = editBox("Como deve ser traduzido", "")
        termBox.addView(kindBtn); termBox.addView(etSrc); termBox.addView(etTgt)
        toggle.setOnClickListener {
            remember = !remember
            toggle.text = if (remember) "☑  Lembrar como termo / nome" else "☐  Lembrar como termo / nome"
            termBox.visibility = if (remember) View.VISIBLE else View.GONE
        }
        b.addView(toggle); b.addView(termBox)
        b.addView(buttons(
            button("Cancelar", 0xFF3A3F6B.toInt()) { hideKeyboard(et); dismiss() },
            button("Salvar") {
                val t = et.text.toString()
                val s = etSrc.text.toString().trim()
                val g = etTgt.text.toString().trim()
                val term = if (remember && s.isNotEmpty() && g.isNotEmpty()) Triple(kinds[kindIdx], s, g) else null
                hideKeyboard(et); dismiss(); actions.saveEdit(sub, t, term)
            }
        ))
        present(b, dp(70), true)
        et.requestFocus()
        et.setSelection(et.text.length)
    }

    // ------------------------------------------------------------- original

    private fun showInfo(sub: Subtitle) {
        val b = box()
        b.addView(title("TEXTO ORIGINAL"))
        val inner = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), 0) }
        inner.addView(text("Idioma detectado: ${sub.sourceLang}", 13f, MUTED))
        inner.addView(text("Confiança do OCR: ${ocrLabel(sub.conf)} (mede a leitura do texto, não a qualidade da tradução)", 13f, MUTED))
        inner.addView(text("Traduzido por: ${engineLabel(sub.engine)} · estilo: ${sub.styleKey?.let { TStyles.label(it) } ?: "padrão"}", 13f, MUTED))
        inner.addView(text(sub.original, 17f).apply { setPadding(0, dp(6), 0, dp(10)); setTextIsSelectable(false) })
        inner.addView(text("Tradução atual" + if (sub.state == SubState.EDITED) " (editada por você)" else "", 13f, MUTED))
        inner.addView(text(sub.translated, 15f).apply { setPadding(0, dp(4), 0, dp(10)) })
        inner.addView(text("Histórico de correções", 13f, MUTED))
        if (sub.history.isEmpty()) inner.addView(text("Nenhuma ainda.", 14f))
        else sub.history.forEachIndexed { i, h -> inner.addView(text("${i + 1}. $h", 14f).apply { setPadding(0, dp(3), 0, dp(3)) }) }
        b.addView(scroll(inner, 0.45f))
        b.addView(buttons(button("Voltar", 0xFF3A3F6B.toInt()) { showMenu(sub, lastAnchor) }, button("Fechar") { dismiss() }))
        present(b, yFor((sh * 0.5f).toInt()), false)
    }

    // --------------------------------------------------------------- idioma

    private fun showLang(sub: Subtitle) {
        val b = box()
        b.addView(title("TRADUZIR ESTA LEGENDA PARA"))
        val inner = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        for ((name, code) in Langs.list) inner.addView(row(name) { dismiss(); actions.setTarget(sub, code) })
        b.addView(scroll(inner, 0.5f))
        present(b, yFor((sh * 0.5f).toInt()), false)
    }

    // -------------------------------------------------------------- duração

    private fun showDuration(sub: Subtitle) {
        val b = box()
        b.addView(title("DURAÇÃO DESTA LEGENDA"))
        for ((name, ms) in listOf("Padrão das configurações" to -1L, "3 segundos" to 3000L, "6 segundos" to 6000L,
            "10 segundos" to 10000L, "Até a tela mudar" to 0L))
            b.addView(row(name) { actions.setDuration(sub, ms); dismiss() })
        present(b, yFor(dp(300)), false)
    }

    // ---------------------------------------------------------------- estilo

    private fun swatches(label: String, colors: IntArray, onPick: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(2)) }
        r.addView(text(label, 12f, MUTED))
        val line = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        for (col in colors) {
            val v = TextView(c).apply {
                gravity = Gravity.CENTER; textSize = 12f; setTextColor(0xFF222222.toInt())
                text = when (col) { 1 -> "A"; 0 -> "∅"; else -> "" }
                background = GradientDrawable().apply {
                    cornerRadius = 8 * d; setStroke(dp(1), 0x88FFFFFF.toInt())
                    setColor(if (col == 1 || col == 0) 0xFFDDDDDD.toInt() else col)
                }
                setOnClickListener { onPick(col) }
            }
            line.addView(v, LinearLayout.LayoutParams(0, dp(34), 1f).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) })
        }
        r.addView(line)
        return r
    }

    private fun showStyle(sub: Subtitle) {
        val b = box()
        b.addView(title("PERSONALIZAR SÓ ESTA LEGENDA"))
        fun cur(): SubStyle = sub.styleOv ?: styleProvider().copy()
        val sizeTv = text("", 14f).apply { gravity = Gravity.CENTER }
        fun refresh() { val s = cur(); sizeTv.text = if (s.autoSize) "Tamanho: auto" else "Tamanho: ${s.textSizeSp.toInt()} sp" }
        refresh()
        val sizeRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        sizeRow.addView(button("A−", 0xFF3A3F6B.toInt()) {
            val s = cur(); val base = if (s.autoSize) 16f else s.textSizeSp
            actions.applyStyle(sub, s.copy(autoSize = false, textSizeSp = max(8f, base - 2f))); refresh()
        }, LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT))
        sizeRow.addView(sizeTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sizeRow.addView(button("A+", 0xFF3A3F6B.toInt()) {
            val s = cur(); val base = if (s.autoSize) 16f else s.textSizeSp
            actions.applyStyle(sub, s.copy(autoSize = false, textSizeSp = min(48f, base + 2f))); refresh()
        }, LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT))
        b.addView(sizeRow)

        val white = 0xFFFFFFFF.toInt(); val black = 0xFF000000.toInt()
        b.addView(swatches("Cor das letras (A = automática)",
            intArrayOf(1, white, black, 0xFFFFEB3B.toInt(), 0xFFFF5252.toInt(), 0xFF00E5FF.toInt(), 0xFF69F0AE.toInt())) { col ->
            val s = cur()
            actions.applyStyle(sub, if (col == 1) s.copy(textColorAuto = true) else s.copy(textColorAuto = false, textColor = col))
        })
        b.addView(swatches("Fundo (A = igual ao original, ∅ = sem fundo)",
            intArrayOf(1, 0, white, black, 0xFFFFF3C4.toInt(), 0xFF1A1E3C.toInt(), 0xFFFFCDD2.toInt())) { col ->
            val s = cur()
            actions.applyStyle(sub, when (col) {
                1 -> s.copy(bgEnabled = true, bgAuto = true)
                0 -> s.copy(bgEnabled = false)
                else -> s.copy(bgEnabled = true, bgAuto = false, bgColor = col)
            })
        })
        b.addView(buttons(
            button("Restaurar", 0xFF3A3F6B.toInt()) { actions.applyStyle(sub, null); showStyle(sub) },
            button("Pronto") { dismiss() }
        ))
        present(b, yFor(dp(330)), false)
    }

    // ------------------------------------------------------------ comparação

    fun edit(sub: Subtitle, anchor: RectF) { lastAnchor = anchor; showEdit(sub) }

    private fun showStyles(sub: Subtitle) {
        val b = box()
        b.addView(title("ESTILO DE TRADUÇÃO DESTA LEGENDA"))
        val inner = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        inner.addView(row("Padrão das configurações") { dismiss(); actions.setStyle(sub, null) })
        for ((key, name) in TStyles.list) inner.addView(row(name + if (sub.styleKey == key) "  ✔" else "") { dismiss(); actions.setStyle(sub, key) })
        b.addView(scroll(inner, 0.5f))
        b.addView(text("O estilo vale para a IA; no modo offline a tradução não muda.", 11f, MUTED).apply { setPadding(dp(12), dp(4), dp(12), dp(6)) })
        present(b, yFor((sh * 0.5f).toInt()), false)
    }

    fun showCompare(sub: Subtitle, anchor: RectF, cmp: Compare) {
        lastAnchor = anchor
        val b = box()
        b.addView(title("COMPARAR RESULTADOS"))
        val inner = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), 0) }
        inner.addView(text("Idioma detectado: ${cmp.lang}", 13f, MUTED))
        inner.addView(text("Texto reconhecido (OCR) · confiança: ${ocrLabel(cmp.conf)}", 12f, MUTED).apply { setPadding(0, dp(8), 0, 0) })
        inner.addView(text(cmp.recognized, 16f))
        inner.addView(text("A confiança mede a leitura do texto, não se a tradução está certa.", 11f, MUTED))
        cmp.cands.forEachIndexed { i, cd ->
            inner.addView(text((if (i == cmp.applied) "✔ " else "") + cd.label, 12f, MUTED).apply { setPadding(0, dp(8), 0, 0) })
            inner.addView(text(cd.text, 15f, if (i == cmp.applied) 0xFF69F0AE.toInt() else WHITE))
        }
        if (cmp.manual) inner.addView(text("Sua correção manual só será trocada se você escolher outra opção.", 11f, MUTED).apply { setPadding(0, dp(8), 0, 0) })
        b.addView(scroll(inner, 0.42f))
        val btns = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        cmp.cands.forEachIndexed { i, cd ->
            btns.addView(button("Usar: " + cd.label, if (i == cmp.applied) 0xFF3A3F6B.toInt() else ACCENT) { dismiss(); actions.choose(sub, i) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), dp(3), dp(4), dp(3)) })
        }
        b.addView(btns)
        present(b, yFor((sh * 0.6f).toInt()), false)
    }
}
