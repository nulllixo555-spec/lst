package com.livescreentranslator

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private val languages = listOf(
        "Português (Brasil)" to "pt", "English" to "en", "Español" to "es",
        "Français" to "fr", "Deutsch" to "de", "Italiano" to "it", "日本語" to "ja"
    )
    private lateinit var btnPause: MaterialButton
    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton
    private lateinit var status: TextView
    private lateinit var spinner: Spinner
    private val prefs by lazy { getSharedPreferences("lst", Context.MODE_PRIVATE) }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslatorService::class.java)
                .setAction(TranslatorService.ACTION_START)
                .putExtra(TranslatorService.EXTRA_CODE, r.resultCode)
                .putExtra(TranslatorService.EXTRA_DATA, data)
                .putExtra(TranslatorService.EXTRA_TARGET, languages[spinner.selectedItemPosition].second)
            ContextCompat.startForegroundService(this, i)
        }
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { askProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnStart = findViewById(R.id.btnStart); btnPause = findViewById(R.id.btnPause)
        btnStop = findViewById(R.id.btnStop); status = findViewById(R.id.status)
        spinner = findViewById(R.id.language)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, languages.map { it.first })
        spinner.setSelection(languages.indexOfFirst { it.second == prefs.getString("target", "pt") }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putString("target", languages[pos].second).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        btnStart.setOnClickListener { start() }
        btnPause.setOnClickListener {
            val paused = TranslatorService.state.value == TranslatorService.State.PAUSED
            send(if (paused) TranslatorService.ACTION_RESUME else TranslatorService.ACTION_PAUSE)
        }
        btnStop.setOnClickListener { send(TranslatorService.ACTION_STOP) }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                TranslatorService.state.collect { render(it) }
            }
        }
    }

    private fun render(s: TranslatorService.State) {
        status.text = when (s) {
            TranslatorService.State.IDLE -> "Parado"
            TranslatorService.State.RUNNING -> "Traduzindo…"
            TranslatorService.State.PAUSED -> "Pausado"
        }
        btnStart.isEnabled = s == TranslatorService.State.IDLE
        btnPause.isEnabled = s != TranslatorService.State.IDLE
        btnStop.isEnabled = s != TranslatorService.State.IDLE
        btnPause.text = if (s == TranslatorService.State.PAUSED) "Retomar tradução" else "Pausar tradução"
    }

    private fun send(action: String) = startService(Intent(this, TranslatorService::class.java).setAction(action))

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita a exibição sobre outros apps e volte.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS); return
        }
        askProjection()
    }

    private fun askProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
