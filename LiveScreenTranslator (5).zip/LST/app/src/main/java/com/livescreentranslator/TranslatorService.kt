package com.livescreentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.graphics.ColorUtils
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class TranslatorService : Service() {

    enum class State { IDLE, RUNNING, PAUSED }

    companion object {
        const val ACTION_START = "start"; const val ACTION_PAUSE = "pause"
        const val ACTION_RESUME = "resume"; const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"; const val EXTRA_DATA = "data"
        const val EXTRA_TARGET = "target"; const val EXTRA_SOURCE = "source"
        const val EXTRA_MODE = "mode"; const val EXTRA_LIGHT = "light"
        val state = MutableStateFlow(State.IDLE)
        @Volatile var reloadHook: (() -> Unit)? = null
        private const val CHANNEL = "lst"
        private const val CELL = 96
    }

    private class Tr(val out: String, val src: String, val bg: Int, val fg: Int)
    private class Pending(
        val sub: Subtitle, val old: String, val new: String, val original: String, val lang: String,
        val prev: SubState, val oldTarget: String?, val newTarget: String?
    ) { var applied = false }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var bubble: Bubble? = null
    private var menu: FloatingMenu? = null
    private var screenW = 0
    private var screenH = 0
    private val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    // captura e rastreamento
    private val imgLock = Any()
    private var held: Image? = null
    @Volatile private var heldAt = 0L
    private var prevProf: Tracker.Prof? = null
    @Volatile private var phase = 1                 // 0 rastreando, 1 aguardando a tela estabilizar
    private var changeAt = 0L
    private var needClean = false
    private var lastMotionAt = 0L
    private var lastOcrAt = 0L
    @Volatile private var ignoreUntil = 0L
    @Volatile private var dirty = false
    @Volatile private var busy = false
    @Volatile private var retrBusy = false
    @Volatile private var menuOpen = false
    @Volatile private var touchMode = false
    @Volatile private var sx = 0                    // rolagem acumulada (mundo -> tela)
    @Volatile private var sy = 0
    private val pages = ArrayList<Page>()
    @Volatile private var page: Page? = null
    private var pagesDirty = false
    private var lastSaveAt = 0L
    private var pending: Pending? = null

    // tradução
    private var target = TranslateLanguage.PORTUGUESE
    private var sourceMode = "en"
    private var onDemand = false
    private var light = false
    @Volatile private var requested = false
    private val cache = ConcurrentHashMap<String, String>()
    private val translators = HashMap<String, Translator>()
    private val modelLock = Mutex()
    private val db by lazy { TermDb.get(this) }
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val jp by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent)
            ACTION_PAUSE -> {
                state.value = State.PAUSED
                overlay?.suppressed = true
                menu?.dismiss()
                notify(true)
            }
            ACTION_RESUME -> {
                state.value = State.RUNNING
                overlay?.suppressed = false
                resetToStable(SystemClock.uptimeMillis(), false)
                notify(false)
            }
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- início

    private fun begin(intent: Intent) {
        createChannel()
        val n = buildNotification(false, null)
        if (Build.VERSION.SDK_INT >= 29)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        target = intent.getStringExtra(EXTRA_TARGET) ?: TranslateLanguage.PORTUGUESE
        sourceMode = intent.getStringExtra(EXTRA_SOURCE) ?: "en"
        onDemand = intent.getStringExtra(EXTRA_MODE) == "demand"
        light = intent.getBooleanExtra(EXTRA_LIGHT, true)
        Tracker.step = if (light) 8 else 5
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION") val data: Intent = intent.getParcelableExtra(EXTRA_DATA) ?: return shutdown()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { shutdown() } }
            }, main)
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels; screenH = dm.heightPixels

        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 4)
        display = projection!!.createVirtualDisplay(
            "lst", screenW, screenH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )

        val lp = WindowManager.LayoutParams(
            screenW, screenH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28)
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        overlayLp = lp
        overlay = OverlayView(this).also {
            it.style = SubStyle.load(this)
            it.onTap = { sub, box -> onTapSub(sub, box) }
            it.onLongPress = { sub, _ -> rearmTouch(); retranslate(sub, null) }
            wm.addView(it, lp)
        }
        menu = FloatingMenu(this, wm, screenW, screenH, { SubStyle.load(this) }, actions)
        bubble = Bubble(this, wm, screenW, screenH, { onBubble() }, { unhideAll() }).also { it.show() }

        pages.addAll(PageStore.load(this))
        state.value = State.RUNNING
        phase = 1; changeAt = SystemClock.uptimeMillis(); needClean = false
        reloadHook = { main.post { overlay?.style = SubStyle.load(this@TranslatorService) } }

        scope.launch {
            val first = when (sourceMode) { "ja" -> "ja"; "zh" -> "zh"; "ko" -> "ko"; "id" -> "id"; else -> "en" }
            translatorFor(first, target); if (first != "en") translatorFor("en", target)
        }
        job = scope.launch {
            while (isActive) {
                if (state.value == State.RUNNING) runCatching { tick() }
                delay(if (light) 170L else 90L)
            }
        }
    }

    // ------------------------------------------------------------ modo toque

    private val touchOff = Runnable { if (!menuOpen) setTouch(false) else rearmTouch() }

    private fun rearmTouch() { main.removeCallbacks(touchOff); if (touchMode) main.postDelayed(touchOff, 15000) }

    private fun setTouch(on: Boolean) {
        touchMode = on
        overlayLp?.let { lp ->
            lp.flags = if (on) baseFlags else baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            overlay?.let { v -> runCatching { wm.updateViewLayout(v, lp) } }
        }
        overlay?.touchMode = on
        bubble?.setActive(on)
        main.removeCallbacks(touchOff)
        if (on) main.postDelayed(touchOff, 15000) else menu?.dismiss()
        notifyText(if (on) "Modo toque ligado: toque numa legenda (desliga sozinho)" else null)
    }

    private fun onTapSub(sub: Subtitle?, box: RectF?) {
        rearmTouch()
        if (sub == null || box == null) { if (menuOpen) menu?.dismiss(); return }
        menuOpen = true
        menu?.showMenu(sub, box)
    }

    /** Botão flutuante: no modo automático liga/desliga o toque; sob demanda traduz esta tela e liga o toque. */
    private fun onBubble() {
        if (onDemand) {
            requested = true; dirty = true; lastMotionAt = 0L; lastOcrAt = 0L
            notifyText("Traduzindo esta tela…")
            setTouch(true)
        } else setTouch(!touchMode)
    }

    private fun unhideAll() {
        page?.subs?.forEach { it.userHidden = false }
        pagesDirty = true
        postUpdate()
        notifyText("Legendas ocultas reexibidas")
    }

    // ------------------------------------------------------ ações do menu

    private val actions = object : MenuActions {
        override fun retranslate(sub: Subtitle) = this@TranslatorService.retranslate(sub, null)

        override fun saveEdit(sub: Subtitle, text: String, term: Triple<String, String, String>?) {
            val t = text.trim()
            if (t.isEmpty()) return
            val before = sub.translated
            sub.history.add(before); sub.translated = t; sub.state = SubState.EDITED
            val tgt = sub.targetLang ?: target
            scope.launch {
                db.log(sub.original, before, t)
                db.upsert("Frase", sub.original, t, sub.sourceLang, tgt)
                term?.let { db.upsert(it.first, it.second, it.third, sub.sourceLang, tgt) }
                pagesDirty = true
            }
            postUpdate()
        }

        override fun setTarget(sub: Subtitle, lang: String) = this@TranslatorService.retranslate(sub, lang)

        override fun copy(sub: Subtitle) {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("tradução", sub.translated))
            notifyText("Tradução copiada")
        }

        override fun setDuration(sub: Subtitle, ms: Long) {
            sub.ttlOv = ms; pagesDirty = true
            overlay?.resetAnim(); postUpdate()
        }

        override fun applyStyle(sub: Subtitle, s: SubStyle?) { sub.styleOv = s; postUpdate() }

        override fun hide(sub: Subtitle) {
            sub.userHidden = true; pagesDirty = true; postUpdate()
            notifyText("Legenda oculta. Segure o botão 👆 para reexibir")
        }

        override fun choose(sub: Subtitle, useNew: Boolean) {
            val p = pending ?: return
            pending = null
            if (p.sub !== sub) return
            if (useNew && !p.applied) applyPending(p)
            if (!useNew && p.applied) {
                sub.translated = p.old; sub.state = p.prev; sub.targetLang = p.oldTarget
                sub.history.remove(p.old)
            }
            pagesDirty = true
            postUpdate()
        }

        override fun closed() { menuOpen = false }
    }

    private fun applyPending(p: Pending) {
        val s = p.sub
        s.history.add(p.old)
        s.original = p.original; s.translated = p.new; s.sourceLang = p.lang; s.state = SubState.TRANSLATED
        if (p.newTarget != null) s.targetLang = p.newTarget
        p.applied = true
    }

    // ------------------------------------------------------------------ ciclo

    private suspend fun tick() {
        val now = SystemClock.uptimeMillis()
        val img: Image? = synchronized(imgLock) {
            val i = reader?.acquireLatestImage()
            if (i != null) { held?.close(); held = i; heldAt = now }
            i
        }
        if (phase == 0) {
            if (img != null && now >= ignoreUntil && !menuOpen) onFrame(img, now)
            maybeSettle(now)
        } else {
            val h = held
            if (h != null && (!needClean || heldAt > changeAt + 60) &&
                ((now - heldAt > 220 && now - changeAt > 300) || now - changeAt > 2500)) finalizePage(h, now)
        }
        if (pagesDirty && now - lastSaveAt > 8000) {
            pagesDirty = false; lastSaveAt = now
            PageStore.save(this, pages.toList())
        }
    }

    private fun onFrame(img: Image, now: Long) {
        val masks = (overlay?.boxes ?: emptyList()) + listOfNotNull(bubble?.rect())
        val prof = Tracker.profile(img, masks)
        val prev = prevProf
        prevProf = prof
        if (prev == null) return
        val m = Tracker.estimate(prev, prof)
        when (m.kind) {
            1 -> { sx -= m.dx; sy -= m.dy; lastMotionAt = now; dirty = true; postUpdate() }
            2 -> resetToStable(now, overlay?.boxes?.isNotEmpty() == true)
        }
    }

    /** A tela mudou por completo (outra página): guarda a atual e espera a nova estabilizar. */
    private fun resetToStable(now: Long, hadVisible: Boolean) {
        phase = 1; changeAt = now; needClean = hadVisible; prevProf = null
        sx = 0; sy = 0; page = null; dirty = false
        postUpdate()
    }

    private fun finalizePage(img: Image, now: Long) {
        val fp = Tracker.fingerprint(img)
        val match = pages.firstOrNull { Tracker.fpDiff(it.fingerprint, fp) < 10f }
        val p = match ?: Page(Ids.next(), fp).also {
            pages.add(it)
            if (pages.size > 25) pages.removeAt(0)
        }
        page = p
        sx = 0; sy = 0
        prevProf = Tracker.profile(img, emptyList())
        phase = 0
        dirty = !onDemand && (match == null || p.done.isEmpty())
        lastMotionAt = now
        postUpdate()
    }

    private fun postUpdate() {
        val subs = page?.subs?.toList() ?: emptyList()
        val x = sx
        val y = sy
        main.post { overlay?.update(subs, x, y) }
    }

    private fun maybeSettle(now: Long) {
        if (!dirty || busy || retrBusy || menuOpen) return
        if (onDemand && !requested) return
        val settle = if (onDemand) 0L else if (light) 600L else 400L
        val gap = if (light) 1200L else 600L
        if (now - lastMotionAt < settle || now - lastOcrAt < gap) return
        val p = page ?: return
        busy = true; dirty = false; requested = false; lastOcrAt = now
        scope.launch {
            try { ocrPage(p) } catch (e: CancellationException) { throw e } catch (e: Throwable) { /* ignora */ }
            finally { busy = false; lastOcrAt = SystemClock.uptimeMillis() }
        }
    }

    // ------------------------------------------------- OCR só do que é novo

    private fun key(cx: Int, cy: Int) = (cx.toLong() shl 32) xor (cy.toLong() and 0xffffffffL)

    private suspend fun waitNewFrame(t0: Long) {
        var waited = 0
        while (heldAt <= t0 + 30 && waited < 600) { delay(25); waited += 25 }
    }

    private suspend fun ocrPage(p: Page) {
        val x0 = sx
        val y0 = sy
        val top = (screenH * 0.07f).toInt()
        val bot = (screenH * 0.95f).toInt()
        val cx0 = Math.floorDiv(x0, CELL)
        val cx1 = Math.floorDiv(x0 + screenW - 1, CELL)
        val cy0 = Math.floorDiv(y0 + top, CELL)
        val cy1 = Math.floorDiv(y0 + bot - 1, CELL)
        var ux0 = Int.MAX_VALUE; var uy0 = Int.MAX_VALUE; var ux1 = Int.MIN_VALUE; var uy1 = Int.MIN_VALUE
        var count = 0
        for (cy in cy0..cy1) for (cx in cx0..cx1) if (!p.done.contains(key(cx, cy))) {
            count++; ux0 = min(ux0, cx); uy0 = min(uy0, cy); ux1 = max(ux1, cx); uy1 = max(uy1, cy)
        }
        fun markAll() { for (cy in cy0..cy1) for (cx in cx0..cx1) p.done.add(key(cx, cy)) }
        if (count == 0) return
        if (count < 2) { markAll(); return }

        val margin = 48
        val crop = Rect(
            (ux0 * CELL - x0 - margin).coerceAtLeast(0), (uy0 * CELL - y0 - margin).coerceAtLeast(top),
            ((ux1 + 1) * CELL - x0 + margin).coerceAtMost(screenW), ((uy1 + 1) * CELL - y0 + margin).coerceAtMost(bot)
        )
        if (crop.width() < 40 || crop.height() < 40) { markAll(); return }

        // Só esconde as legendas se alguma cobrir a região que vai ler.
        val needHide = overlay?.boxes?.any { Rect.intersects(it, crop) } == true
        if (needHide) {
            val t0 = SystemClock.uptimeMillis()
            ignoreUntil = Long.MAX_VALUE
            withContext(Dispatchers.Main) { overlay?.suppressed = true }
            waitNewFrame(t0)
        }
        val cap = synchronized(imgLock) { held?.let { Triple(toBitmap(it), sx, sy) } }
        if (needHide) {
            withContext(Dispatchers.Main) { overlay?.suppressed = false }
            ignoreUntil = SystemClock.uptimeMillis() + 200
        }
        if (cap == null) return
        val (full, cx, cy) = cap
        if (cx != x0 || cy != y0) { full.recycle(); dirty = true; if (onDemand) requested = true; return }   // rolou enquanto capturava: tenta de novo

        val region = Bitmap.createBitmap(full, crop.left, crop.top, crop.width(), crop.height())
        full.recycle()
        val blocks = mergeBalloons(ocrBlocks(region, sourceMode), region.width().toLong() * region.height())

        val cutRects = java.util.Collections.synchronizedList(ArrayList<Rect>())
        coroutineScope {
            blocks.map { (rect, text) ->
                async {
                    val wr = Rect(rect.left + crop.left + cx, rect.top + crop.top + cy, rect.right + crop.left + cx, rect.bottom + crop.top + cy)
                    val sl = rect.left + crop.left
                    val sr = rect.right + crop.left
                    val st = rect.top + crop.top
                    val sb = rect.bottom + crop.top
                    if (sl <= 3 || sr >= screenW - 3 || st <= top + 6 || sb >= bot - 6) { cutRects.add(wr); return@async }   // texto cortado pela borda
                    if (!shouldProcess(p, wr)) return@async
                    val tr = translateBlock(region, rect, text, sourceMode) ?: return@async
                    val pad = 2
                    val sub = Subtitle(
                        Ids.next(), "${text.hashCode()}@${wr.left / CELL},${wr.top / CELL}", text, tr.out, tr.src,
                        wr.left - pad, wr.top - pad, wr.width() + 2 * pad, wr.height() + 2 * pad, tr.bg, tr.fg
                    )
                    if (place(p, sub)) { pagesDirty = true; postUpdate() }
                }
            }.awaitAll()
        }
        region.recycle()
        markAll()
        // Texto cortado na borda: libera essas células para ler de novo quando ele aparecer inteiro.
        for (r in cutRects) {
            for (yy in Math.floorDiv(r.top, CELL)..Math.floorDiv(r.bottom, CELL))
                for (xx in Math.floorDiv(r.left, CELL)..Math.floorDiv(r.right, CELL)) p.done.remove(key(xx, yy))
        }
    }

    // ------------------------------------------- juntar blocos do mesmo balão

    private class Grp(val r: Rect, val parts: ArrayList<Pair<Rect, String>>)

    private fun canJoin(a: Rect, b: Rect, maxArea: Long): Boolean {
        val aV = a.height() > a.width() * 1.5f
        val bV = b.height() > b.width() * 1.5f
        if (aV != bV) return false
        val u = Rect(a)
        u.union(b)
        if (u.width().toLong() * u.height() > maxArea) return false
        if (aV) {   // colunas de texto vertical vizinhas
            val vo = min(a.bottom, b.bottom) - max(a.top, b.top)
            val gap = max(a.left, b.left) - min(a.right, b.right)
            return vo >= 0.6f * min(a.height(), b.height()) && gap >= -4 && gap <= 0.8f * min(a.width(), b.width())
        }
        val ho = min(a.right, b.right) - max(a.left, b.left)
        val gap = max(a.top, b.top) - min(a.bottom, b.bottom)
        val cxd = abs(a.centerX() - b.centerX())
        val maxGap = max(10f, 0.5f * min(a.height(), b.height()))
        return ho >= 0.4f * min(a.width(), b.width()) && gap >= -4 && gap <= maxGap &&
            cxd <= 0.35f * max(a.width(), b.width())
    }

    /** Une blocos vizinhos e alinhados (mesma fala dividida pelo OCR) para traduzir a frase inteira. */
    private fun mergeBalloons(blocks: List<Pair<Rect, String>>, maxRegionArea: Long): List<Pair<Rect, String>> {
        if (blocks.size < 2) return blocks
        val maxArea = (maxRegionArea * 0.3).toLong()
        val groups = blocks.map { Grp(Rect(it.first), arrayListOf(it)) }.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in groups.indices) for (j in i + 1 until groups.size) {
                if (canJoin(groups[i].r, groups[j].r, maxArea)) {
                    groups[i].r.union(groups[j].r)
                    groups[i].parts.addAll(groups[j].parts)
                    groups.removeAt(j)
                    changed = true
                    break@loop
                }
            }
        }
        return groups.map { g ->
            if (g.parts.size == 1) g.parts[0]
            else {
                val vertical = g.parts.all { it.first.height() > it.first.width() * 1.5f }
                val ordered = if (vertical) g.parts.sortedWith(compareByDescending<Pair<Rect, String>> { it.first.centerX() }.thenBy { it.first.top })
                else g.parts.sortedWith(compareBy<Pair<Rect, String>>({ it.first.top }, { it.first.left }))
                val cjk = ordered.any { p -> p.second.any { isCjk(it) } }
                g.r to joinText(ordered.map { it.second }, cjk)
            }
        }
    }

    private fun overlap(a: Rect, b: Rect): Float {
        val i = Rect(a)
        if (!i.intersect(b)) return 0f
        val ia = i.width().toLong() * i.height()
        val m = min(a.width().toLong() * a.height(), b.width().toLong() * b.height())
        return ia.toFloat() / max(1L, m)
    }

    /** Evita duplicar: só processa se não há legenda ali, ou se o texto agora está mais completo. */
    private fun shouldProcess(p: Page, wr: Rect): Boolean {
        for (o in p.subs) {
            if (overlap(o.rect(), wr) > 0.4f) {
                val a = wr.width().toLong() * wr.height()
                val oa = o.w.toLong() * o.h
                return a > oa * 1.35 && o.state == SubState.TRANSLATED
            }
        }
        return true
    }

    private fun place(p: Page, sub: Subtitle): Boolean = synchronized(p) {
        for (o in p.subs) {
            if (overlap(o.rect(), sub.rect()) > 0.4f) {
                val a = sub.w.toLong() * sub.h
                val oa = o.w.toLong() * o.h
                if (a > oa * 1.35 && o.state == SubState.TRANSLATED) { p.subs.remove(o); p.subs.add(sub); return true }
                return false
            }
        }
        p.subs.add(sub)
        true
    }

    // ---------------------------------------------------------- retradução

    private fun fail(sub: Subtitle, prev: SubState, msg: String) { sub.state = prev; notifyText(msg) }

    private fun retranslate(sub: Subtitle, newTarget: String?) {
        if (retrBusy) return
        retrBusy = true
        notifyText("Traduzindo novamente…")
        scope.launch {
            val prev = sub.state
            try {
                sub.state = SubState.TRANSLATING
                val t0 = SystemClock.uptimeMillis()
                sub.hidden = true
                postUpdate()
                waitNewFrame(t0)
                val cap = synchronized(imgLock) { held?.let { Triple(toBitmap(it), sx, sy) } }
                sub.hidden = false
                postUpdate()
                if (cap == null) { fail(sub, prev, "Não consegui capturar a tela"); return@launch }
                val (bmp, cx, cy) = cap
                val m = 14
                val l = (sub.x - cx - m).coerceIn(0, bmp.width - 2)
                val t = (sub.y - cy - m).coerceIn(0, bmp.height - 2)
                val r = (sub.x + sub.w - cx + m).coerceIn(l + 1, bmp.width)
                val b = (sub.y + sub.h - cy + m).coerceIn(t + 1, bmp.height)
                if (r - l < 10 || b - t < 10) { bmp.recycle(); fail(sub, prev, "A legenda não está visível na tela"); return@launch }
                val crop = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
                bmp.recycle()
                val blocks = ocrBlocks(crop, "auto")
                crop.recycle()
                if (blocks.isEmpty()) { fail(sub, prev, "Não encontrei texto nessa região"); return@launch }

                val vertical = blocks.count { it.first.height() > it.first.width() * 1.5f } * 2 > blocks.size
                val ordered = if (vertical)
                    blocks.sortedWith(compareByDescending<Pair<Rect, String>> { it.first.centerX() }.thenBy { it.first.top })
                else blocks.sortedWith(compareBy<Pair<Rect, String>>({ it.first.top }, { it.first.left }))
                val texts = ordered.map { it.second }
                val cjk = texts.any { s -> s.any { isCjk(it) } }
                val text = joinText(texts, cjk)

                val src = sourceLang(text, "auto")
                val tgt = newTarget ?: sub.targetLang ?: target
                if (src == null) { fail(sub, prev, "Não consegui identificar o idioma"); return@launch }
                if (src == tgt) { fail(sub, prev, "O texto já está no idioma de destino"); return@launch }
                val out = translateText(text, src, tgt, true)
                if (out == null) { fail(sub, prev, "Modelo de tradução indisponível (conecte à internet)"); return@launch }

                val p = Pending(sub, sub.translated, out, text, src, prev, sub.targetLang, newTarget)
                if (prev != SubState.EDITED) applyPending(p) else sub.state = prev   // correção manual só muda com autorização
                pending = p
                pagesDirty = true
                postUpdate()
                if (out == p.old) { pending = null; notifyText("A tradução continua igual"); return@launch }
                notifyText("Nova tradução pronta")
                withContext(Dispatchers.Main) {
                    menuOpen = true
                    menu?.showCompare(sub, overlay?.boxOf(sub) ?: RectF((sub.x - sx).toFloat(), (sub.y - sy).toFloat(),
                        (sub.x + sub.w - sx).toFloat(), (sub.y + sub.h - sy).toFloat()),
                        Compare(text, src, p.old, out, prev == SubState.EDITED))
                }
            } finally {
                sub.hidden = false
                if (sub.state == SubState.TRANSLATING) sub.state = prev
                retrBusy = false
            }
        }
    }

    // ---------------------------------------------------------------- OCR

    private fun isCjk(c: Char) = c in '\u3040'..'\u30ff' || c in '\u4e00'..'\u9fff' || c in '\uac00'..'\ud7af'
    private fun letters(s: String) = s.count { it.isLetter() }

    private suspend fun ocrBlocks(bmp: Bitmap, mode: String): List<Pair<Rect, String>> {
        val targetW = if (light) 640 else 1080
        val scale = (targetW.toFloat() / bmp.width).coerceIn(0.4f, 1.6f)
        val small = if (kotlin.math.abs(scale - 1f) > 0.05f)
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val res = recognize(small, mode).map { (r, t) ->
            Rect((r.left / scale).toInt(), (r.top / scale).toInt(), (r.right / scale).toInt(), (r.bottom / scale).toInt()) to t
        }
        if (small !== bmp) small.recycle()
        return res
    }

    private suspend fun recognize(bmp: Bitmap, mode: String): List<Pair<Rect, String>> = coroutineScope {
        val img = InputImage.fromBitmap(bmp, 0)
        val auto = mode == "auto"
        val recs = when (mode) {
            "auto" -> listOf(ko to true, jp to true, zh to true, latin to false)
            "ja" -> listOf(jp to true)
            "zh" -> listOf(zh to true)
            "ko" -> listOf(ko to true)
            else -> listOf(latin to false)
        }
        val rs = recs.map { (r, _) -> async { runCatching { r.process(img).await() }.getOrNull() } }.awaitAll()
        val cand = ArrayList<Pair<Rect, String>>()
        rs.forEachIndexed { idx, t ->
            t?.textBlocks?.forEach { b ->
                val box = b.boundingBox ?: return@forEach
                val raw = b.text.replace(Regex("(\\p{L})[-\u2010\u2011\u2012\u2013]\\s*\\n\\s*(\\p{L})"), "\$1\$2")
                val cjkText = raw.any { isCjk(it) }
                val txt = TermDb.norm(raw.replace("\n", if (cjkText) "" else " "))
                if (letters(txt) < 2 || box.width() < 10 || box.height() < 10) return@forEach
                if (auto) {
                    val share = txt.count { isCjk(it) }.toFloat() / txt.length
                    if (if (recs[idx].second) share >= 0.3f else share < 0.3f) cand += box to txt
                } else cand += box to txt
            }
        }
        val kept = ArrayList<Pair<Rect, String>>()
        for (c in cand) {
            if (kept.none { overlap(it.first, c.first) > 0.4f }) kept += c
        }
        kept
    }

    // ----------------------------------------------------------- tradução

    private suspend fun sourceLang(text: String, mode: String): String? {
        if (text.any { it in '\uac00'..'\ud7af' }) return TranslateLanguage.KOREAN
        if (text.any { it in '\u3040'..'\u30ff' }) return TranslateLanguage.JAPANESE
        if (text.any { it in '\u4e00'..'\u9fff' }) return TranslateLanguage.CHINESE
        if (text.length >= 12 && mode != "auto") {
            val c = runCatching { langId.identifyLanguage(text).await() }.getOrNull()
            if (c != null && c != "und" && c == target) return c   // já está no idioma de destino
        }
        when (mode) {
            "id" -> return TranslateLanguage.INDONESIAN
            "en", "ja", "zh", "ko" -> return TranslateLanguage.ENGLISH
        }
        val code = runCatching { langId.identifyLanguage(text).await() }.getOrNull() ?: return null
        return if (code == "und") TranslateLanguage.ENGLISH else TranslateLanguage.fromLanguageTag(code)
    }

    /** Usa a memória de correções, depois o cache, depois o tradutor. force = ignora memória e cache. */
    private suspend fun translateText(text: String, src: String, tgt: String, force: Boolean): String? {
        val norm = TermDb.norm(text)
        if (!force) db.exact(norm, tgt)?.let { return it }
        val key = "$src>$tgt>$norm"
        if (!force) cache[key]?.let { return it }
        val cleaned = cleanText(norm, src)
        val input = if (force) cleaned else db.preSubstitute(cleaned, tgt)
        val tr = translatorFor(src, tgt) ?: return null
        val out = runCatching { tr.translate(input).await() }.getOrNull() ?: return null
        if (!force) cache[key] = out
        return out
    }

    /** Corrige defeitos comuns do OCR para a tradução sair melhor. */
    private fun cleanText(t0: String, src: String): String {
        var t = t0
        if (src == "ja" || src == "zh") {
            val cjkChars = "\u3040-\u30ff\u4e00-\u9fff\uff00-\uffef"
            t = Regex("(?<=[$cjkChars])\\s+(?=[$cjkChars])").replace(t, "")
        } else if (src != "ko") {
            t = Regex("\\s+([,.;:!?])").replace(t, "\$1")
            t = Regex("(?<=\\p{L})\\|(?=\\p{L})").replace(t, "I")
            val letters = t.count { it.isLetter() }
            val upper = t.count { it.isUpperCase() }
            if (letters >= 4 && upper >= letters * 0.7) t = sentenceCase(t.lowercase(), src)   // TEXTO EM CAIXA ALTA
        }
        return TermDb.norm(t)
    }

    private fun sentenceCase(s: String, src: String): String {
        val sb = StringBuilder(s.length)
        var cap = true
        for (ch in s) {
            if (cap && ch.isLetter()) { sb.append(ch.uppercaseChar()); cap = false }
            else {
                sb.append(ch)
                if (ch == '.' || ch == '!' || ch == '?' || ch == '\u2026') cap = true
                else if (ch.isLetter()) cap = false
            }
        }
        val out = sb.toString()
        return if (src == "en") Regex("\\bi\\b").replace(out, "I") else out
    }

    /** Junta pedaços de texto; palavra partida com hífen no fim da linha volta a ser uma palavra só. */
    private fun joinText(parts: List<String>, cjk: Boolean): String {
        val sb = StringBuilder()
        for (p in parts) {
            if (sb.isEmpty()) { sb.append(p); continue }
            when {
                cjk -> sb.append(p)
                sb.last() == '-' && sb.length >= 2 && sb[sb.length - 2].isLetter() && p.firstOrNull()?.isLetter() == true -> {
                    sb.setLength(sb.length - 1); sb.append(p)
                }
                else -> sb.append(' ').append(p)
            }
        }
        return TermDb.norm(sb.toString())
    }

    private suspend fun translateBlock(bmp: Bitmap, rect: Rect, text: String, mode: String): Tr? {
        val src = sourceLang(text, mode) ?: return null
        if (src == target) return null
        val out = translateText(text, src, target, false) ?: return null
        if (out.equals(text, true)) return null
        val bg = sampleBackground(bmp, rect)
        val fg = if (ColorUtils.calculateLuminance(bg) > 0.45) 0xFF111111.toInt() else 0xFFF5F5F5.toInt()
        return Tr(out, src, bg, fg)
    }

    private suspend fun translatorFor(src: String, tgt: String): Translator? = modelLock.withLock {
        val k = "$src>$tgt"
        translators[k]?.let { return it }
        val t = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        val ok = runCatching { t.downloadModelIfNeeded(DownloadConditions.Builder().build()).await() }.isSuccess
        if (ok) { translators[k] = t; t } else { t.close(); null }
    }

    private fun sampleBackground(b: Bitmap, r: Rect): Int {
        var rs = 0; var gs = 0; var bs = 0; var n = 0
        fun px(x: Int, y: Int) {
            val c = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))
            rs += c shr 16 and 255; gs += c shr 8 and 255; bs += c and 255; n++
        }
        val steps = 8
        for (i in 0..steps) {
            val x = r.left + r.width() * i / steps
            val y = r.top + r.height() * i / steps
            px(x, r.top - 3); px(x, r.bottom + 3); px(r.left - 3, y); px(r.right + 3, y)
        }
        return 0xFF shl 24 or (rs / n shl 16) or (gs / n shl 8) or (bs / n)
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val pad = p.rowStride - p.pixelStride * img.width
        val full = Bitmap.createBitmap(img.width + pad / p.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        if (pad == 0) return full
        val out = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        full.recycle()
        return out
    }

    // ------------------------------------------------------- notificação

    private fun createChannel() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Tradução", NotificationManager.IMPORTANCE_LOW))
    }

    private fun act(a: String, label: String) = NotificationCompat.Action(
        0, label, PendingIntent.getService(this, a.hashCode(),
            Intent(this, TranslatorService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE))

    private fun buildNotification(paused: Boolean, text: String?): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Live Screen Translator")
            .setContentText(text ?: if (paused) "Pausado" else "Traduzindo a tela…")
            .setOngoing(true)
            .addAction(if (paused) act(ACTION_RESUME, "Retomar") else act(ACTION_PAUSE, "Pausar"))
            .addAction(act(ACTION_STOP, "Encerrar"))
            .build()

    private fun notify(paused: Boolean) =
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification(paused, null))

    /** Avisos vão na notificação (um Toast apareceria na tela e seria lido pelo OCR). */
    private fun notifyText(text: String?) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(1, buildNotification(state.value == State.PAUSED, text))
    }

    // ---------------------------------------------------------- encerrar

    private fun shutdown() {
        job?.cancel()
        reloadHook = null
        runCatching { PageStore.save(this, pages.toList()) }
        main.removeCallbacks(touchOff)
        menu?.dismiss()
        bubble?.hide()
        overlay?.let { v -> runCatching { wm.removeView(v) } }
        overlay = null
        synchronized(imgLock) { held?.close(); held = null }
        display?.release(); reader?.close(); projection?.stop()
        translators.values.forEach { it.close() }; translators.clear()
        state.value = State.IDLE
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
