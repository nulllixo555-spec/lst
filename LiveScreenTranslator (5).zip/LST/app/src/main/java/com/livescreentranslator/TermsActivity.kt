package com.livescreentranslator

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/** Memória de correções: termos, nomes de personagens, habilidades, lugares, expressões e frases. */
class TermsActivity : AppCompatActivity() {

    private lateinit var db: TermDb
    private lateinit var listBox: LinearLayout
    private var filter = 0
    private var query = ""
    private val WHITE = 0xFFFFFFFF.toInt()
    private val MUTED = 0xFF9AA0C8.toInt()
    private val ACCENT = 0xFF6C63FF.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val target: String get() = getSharedPreferences("lst", MODE_PRIVATE).getString("target", "pt") ?: "pt"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val exporter = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        val ok = runCatching {
            contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) }
        }.isSuccess
        Toast.makeText(this, if (ok) "Backup salvo" else "Não foi possível salvar o backup", Toast.LENGTH_LONG).show()
    }

    private val importer = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val text = runCatching { contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } }.getOrNull()
        val n = text?.let { runCatching { db.countJson(it) }.getOrNull() }
        if (text == null || n == null) {
            Toast.makeText(this, "Esse arquivo não é um backup válido", Toast.LENGTH_LONG).show()
            return@registerForActivityResult
        }
        AlertDialog.Builder(this).setTitle("Importar backup?")
            .setMessage("$n termos serão importados. Termos com o mesmo original serão atualizados; os demais ficam como estão.")
            .setPositiveButton("Importar") { _, _ ->
                val done = runCatching { db.importJson(text) }.getOrDefault(0)
                Toast.makeText(this, "$done termos importados", Toast.LENGTH_SHORT).show()
                refresh()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TermDb.get(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), 0) }
        root.addView(TextView(this).apply {
            text = "Memória de correções"; textSize = 22f; setTextColor(WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Nomes e termos salvos aqui são usados em todas as próximas traduções."
            textSize = 13f; setTextColor(MUTED); setPadding(0, dp(4), 0, dp(10))
        })
        root.addView(MaterialButton(this).apply { text = "＋ Adicionar termo"; setOnClickListener { edit(null) } },
            LinearLayout.LayoutParams(MATCH, dp(52)))

        val backupRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        backupRow.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Exportar backup"; setOnClickListener { exporter.launch("memoria-de-correcoes.json") }
        }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(4) })
        backupRow.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Importar backup"; setOnClickListener { importer.launch(arrayOf("*/*")) }
        }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(4) })
        root.addView(backupRow, LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT))

        val kinds = listOf("Todos") + TermDb.KINDS
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, kinds)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { filter = pos; refresh() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sp, LinearLayout.LayoutParams(MATCH, dp(52)))

        val search = EditText(this).apply { hint = "Buscar…"; setTextColor(WHITE); setHintTextColor(MUTED) }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { query = e.toString().trim(); refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(search)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(40)) }
        root.addView(ScrollView(this).apply { addView(listBox) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val kind = if (filter == 0) null else TermDb.KINDS[filter - 1]
        val items = db.all().filter {
            (kind == null || it.kind == kind) &&
                (query.isEmpty() || it.source.contains(query, true) || it.target.contains(query, true))
        }
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Nada salvo ainda. Ao editar uma legenda, marque “Lembrar como termo”, ou toque em Adicionar."
                textSize = 14f; setTextColor(MUTED); setPadding(0, dp(20), 0, 0)
            })
            return
        }
        for (t in items) listBox.addView(card(t), LinearLayout.LayoutParams(MATCH, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })
    }

    private fun card(t: Term): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(8))
            background = GradientDrawable().apply { cornerRadius = 16 * resources.displayMetrics.density; setColor(0xFF1A1E3C.toInt()) }
        }
        c.addView(TextView(this).apply { text = t.kind.uppercase() + if (t.tgtLang.isNotEmpty()) "  ·  → ${t.tgtLang}" else ""; textSize = 11f; setTextColor(ACCENT) })
        c.addView(TextView(this).apply { text = "${t.source}  →  ${t.target}"; textSize = 16f; setTextColor(WHITE); setPadding(0, dp(4), 0, dp(4)) })
        val row = LinearLayout(this).apply { gravity = Gravity.END }
        row.addView(TextView(this).apply { text = "Editar"; textSize = 14f; setTextColor(ACCENT); setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { edit(t) } })
        row.addView(TextView(this).apply { text = "Excluir"; textSize = 14f; setTextColor(0xFFFF6B6B.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { confirmDelete(t) } })
        c.addView(row)
        return c
    }

    private fun confirmDelete(t: Term) {
        AlertDialog.Builder(this).setTitle("Excluir termo?").setMessage("${t.source} → ${t.target}")
            .setPositiveButton("Excluir") { _, _ -> db.delete(t.id); refresh() }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun edit(t: Term?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val kindSp = Spinner(this)
        kindSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, TermDb.KINDS)
        kindSp.setSelection(t?.let { TermDb.KINDS.indexOf(it.kind) }?.coerceAtLeast(0) ?: 0)
        val src = EditText(this).apply { hint = "Original (ex.: nome do personagem)"; setText(t?.source ?: "") }
        val tgt = EditText(this).apply { hint = "Como deve ser traduzido"; setText(t?.target ?: "") }
        box.addView(kindSp); box.addView(src); box.addView(tgt)
        AlertDialog.Builder(this).setTitle(if (t == null) "Novo termo" else "Editar termo").setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val s = src.text.toString().trim()
                val g = tgt.text.toString().trim()
                if (s.isEmpty() || g.isEmpty()) { Toast.makeText(this, "Preencha os dois campos", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val kind = TermDb.KINDS[kindSp.selectedItemPosition]
                if (t == null) db.upsert(kind, s, g, "", target) else db.update(t.id, kind, s, g)
                refresh()
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
