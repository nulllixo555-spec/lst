package com.livescreentranslator

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Term(
    val id: Long, val kind: String, val source: String, val target: String,
    val srcLang: String, val tgtLang: String, val whole: Boolean
)

/** Memória de correções (SQLite local): termos, nomes, lugares, habilidades, frases e histórico. */
class TermDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "lst_memory.db", null, 1) {

    companion object {
        val KINDS = listOf("Termo", "Personagem", "Habilidade", "Lugar", "Expressão", "Frase")
        @Volatile private var inst: TermDb? = null
        fun get(c: Context): TermDb = inst ?: synchronized(this) { inst ?: TermDb(c).also { inst = it } }
        fun norm(s: String) = s.trim().replace(Regex("\\s+"), " ")
    }

    @Volatile private var cache: List<Term>? = null

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE terms(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, source TEXT, target TEXT, srcLang TEXT, tgtLang TEXT, whole INTEGER, created INTEGER)")
        db.execSQL("CREATE UNIQUE INDEX idx_terms ON terms(source, tgtLang)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, original TEXT, old_t TEXT, new_t TEXT, at INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized fun all(): List<Term> {
        cache?.let { return it }
        val out = ArrayList<Term>()
        readableDatabase.rawQuery("SELECT id,kind,source,target,srcLang,tgtLang,whole FROM terms ORDER BY kind, source", null).use { c ->
            while (c.moveToNext()) out += Term(c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                c.getString(4) ?: "", c.getString(5) ?: "", c.getInt(6) == 1)
        }
        cache = out
        return out
    }

    @Synchronized fun upsert(kind: String, source: String, target: String, srcLang: String, tgtLang: String) {
        val v = ContentValues()
        v.put("kind", kind); v.put("source", norm(source)); v.put("target", norm(target))
        v.put("srcLang", srcLang); v.put("tgtLang", tgtLang)
        v.put("whole", if (kind == "Frase") 1 else 0); v.put("created", System.currentTimeMillis())
        writableDatabase.insertWithOnConflict("terms", null, v, SQLiteDatabase.CONFLICT_REPLACE)
        cache = null
    }

    @Synchronized fun update(id: Long, kind: String, source: String, target: String) {
        val v = ContentValues()
        v.put("kind", kind); v.put("source", norm(source)); v.put("target", norm(target))
        v.put("whole", if (kind == "Frase") 1 else 0)
        writableDatabase.update("terms", v, "id=?", arrayOf(id.toString()))
        cache = null
    }

    @Synchronized fun delete(id: Long) {
        writableDatabase.delete("terms", "id=?", arrayOf(id.toString()))
        cache = null
    }

    fun log(original: String, before: String, after: String) {
        val v = ContentValues()
        v.put("original", original); v.put("old_t", before); v.put("new_t", after); v.put("at", System.currentTimeMillis())
        synchronized(this) { writableDatabase.insert("history", null, v) }
    }

    /** Tradução salva para o texto inteiro, se houver. */
    fun exact(text: String, tgt: String): String? =
        all().firstOrNull { it.tgtLang == tgt && it.source == text }?.target

    /** Troca termos salvos (nomes etc.) pela forma preferida antes de traduzir. */
    fun preSubstitute(text: String, tgt: String): String {
        var s = text
        for (t in all().filter { !it.whole && it.tgtLang == tgt && it.source.length >= 2 }.sortedByDescending { it.source.length }) {
            if (s.contains(t.source)) s = s.replace(t.source, " ${t.target} ")
        }
        return if (s == text) text else norm(s)
    }
}

/** Salva páginas e legendas em disco para recuperar depois (inclusive após reiniciar). */
object PageStore {
    private fun file(c: Context) = File(c.filesDir, "pages.json")

    fun save(c: Context, pages: List<Page>) {
        runCatching {
            val arr = JSONArray()
            for (p in pages.takeLast(20)) {
                val o = JSONObject()
                o.put("id", p.id)
                o.put("fp", JSONArray(p.fingerprint.toList()))
                val subs = JSONArray()
                for (u in p.subs) {
                    val j = JSONObject()
                    j.put("id", u.id); j.put("region", u.regionId); j.put("o", u.original); j.put("t", u.translated)
                    j.put("l", u.sourceLang); j.put("x", u.x); j.put("y", u.y); j.put("w", u.w); j.put("h", u.h)
                    j.put("bg", u.bg); j.put("fg", u.fg); j.put("st", u.state.name)
                    j.put("hist", JSONArray(u.history)); j.put("tgt", u.targetLang ?: "")
                    j.put("ttl", u.ttlOv); j.put("uh", u.userHidden)
                    subs.put(j)
                }
                o.put("subs", subs)
                arr.put(o)
            }
            file(c).writeText(arr.toString())
        }
    }

    fun load(c: Context): List<Page> {
        val out = ArrayList<Page>()
        runCatching {
            val f = file(c)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val fpA = o.getJSONArray("fp")
                val page = Page(o.getLong("id"), IntArray(fpA.length()) { fpA.getInt(it) })
                Ids.ensure(page.id)
                val subs = o.getJSONArray("subs")
                for (k in 0 until subs.length()) {
                    val j = subs.getJSONObject(k)
                    val u = Subtitle(j.getLong("id"), j.getString("region"), j.getString("o"), j.getString("t"), j.getString("l"),
                        j.getInt("x"), j.getInt("y"), j.getInt("w"), j.getInt("h"), j.getInt("bg"), j.getInt("fg"))
                    Ids.ensure(u.id)
                    u.state = runCatching { SubState.valueOf(j.getString("st")) }.getOrDefault(SubState.TRANSLATED)
                    val h = j.getJSONArray("hist")
                    for (m in 0 until h.length()) u.history.add(h.getString(m))
                    u.targetLang = j.getString("tgt").ifEmpty { null }
                    u.ttlOv = j.getLong("ttl"); u.userHidden = j.getBoolean("uh")
                    page.subs.add(u)
                }
                out.add(page)
            }
        }
        return out
    }
}
