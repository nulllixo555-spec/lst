package com.livescreentranslator

import android.graphics.Rect
import android.media.Image
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Rastreia a rolagem comparando perfis de linhas/colunas entre capturas (sem criar bitmaps). */
object Tracker {
    private const val STEP = 5
    private const val STATIC_T = 2.5f
    private const val OK_T = 10f
    private const val NONE = Float.MAX_VALUE

    class Prof(
        val w: Int, val h: Int, val y0: Int, val y1: Int,
        val rowM: FloatArray, val rowE: FloatArray, val colM: FloatArray, val colE: FloatArray
    )

    /** kind: 0 parado, 1 moveu (dx, dy = quanto o conteúdo andou na tela), 2 mudou (outra página). */
    class Motion(val kind: Int, val dx: Int = 0, val dy: Int = 0)

    fun profile(img: Image, masks: List<Rect>): Prof {
        val w = img.width
        val h = img.height
        val p = img.planes[0]
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        val gw = (w shr 3) + 1
        val gh = (h shr 3) + 1
        val mask = BooleanArray(gw * gh)
        for (r in masks) {
            val gy0 = (r.top shr 3).coerceAtLeast(0); val gy1 = (r.bottom shr 3).coerceAtMost(gh - 1)
            val gx0 = (r.left shr 3).coerceAtLeast(0); val gx1 = (r.right shr 3).coerceAtMost(gw - 1)
            for (gy in gy0..gy1) for (gx in gx0..gx1) mask[gy * gw + gx] = true
        }
        val y0 = (h * 0.07f).toInt()
        val y1 = (h * 0.95f).toInt()
        val rowM = FloatArray(h) { -1f }
        val rowE = FloatArray(h)
        val colM = FloatArray(w) { -1f }
        val colE = FloatArray(w)

        val nx = (w - 2) / STEP
        for (y in y0 until y1) {
            var sum = 0; var en = 0; var n = 0
            val base = y * rs
            var x = 0
            while (x < w - 1) {
                if (!mask[(y shr 3) * gw + (x shr 3)]) {
                    val a = buf.get(base + x * ps + 1).toInt() and 255
                    val b = buf.get(base + (x + 1) * ps + 1).toInt() and 255
                    sum += a; en += abs(b - a); n++
                }
                x += STEP
            }
            if (n * 4 >= nx && n > 0) { rowM[y] = sum.toFloat() / n; rowE[y] = en.toFloat() / n }
        }
        val ny = (y1 - y0 - 2) / STEP
        for (x in 0 until w) {
            var sum = 0; var en = 0; var n = 0
            var y = y0
            while (y < y1 - 1) {
                if (!mask[(y shr 3) * gw + (x shr 3)]) {
                    val a = buf.get(y * rs + x * ps + 1).toInt() and 255
                    val b = buf.get((y + 1) * rs + x * ps + 1).toInt() and 255
                    sum += a; en += abs(b - a); n++
                }
                y += STEP
            }
            if (n * 4 >= ny && n > 0) { colM[x] = sum.toFloat() / n; colE[x] = en.toFloat() / n }
        }
        return Prof(w, h, y0, y1, rowM, rowE, colM, colE)
    }

    // Erro médio entre o perfil atual e o anterior deslocado por d.
    private fun err(cm: FloatArray, ce: FloatArray, pm: FloatArray, pe: FloatArray, lo: Int, hi: Int, d: Int): Float {
        var sum = 0f
        var n = 0
        var y = max(lo, lo + d)
        val to = min(hi, hi + d)
        while (y < to) {
            val py = y - d
            val a = cm[y]
            val b = pm[py]
            if (a >= 0f && b >= 0f) { sum += abs(a - b) + abs(ce[y] - pe[py]); n++ }
            y++
        }
        return if (n < (hi - lo) / 4 || n == 0) NONE else sum / n
    }

    private fun search(cm: FloatArray, ce: FloatArray, pm: FloatArray, pe: FloatArray, lo: Int, hi: Int, range: Int): Pair<Int, Float> {
        var bd = 0
        var be = NONE
        for (k in 0..range * 2) {
            val d = if (k % 2 == 1) (k + 1) / 2 else -(k / 2)
            val e = err(cm, ce, pm, pe, lo, hi, d)
            if (e < be) { be = e; bd = d }
        }
        return bd to be
    }

    fun estimate(p: Prof, c: Prof): Motion {
        if (p.w != c.w || p.h != c.h) return Motion(2)
        val e0v = err(c.rowM, c.rowE, p.rowM, p.rowE, c.y0, c.y1, 0)
        val e0h = err(c.colM, c.colE, p.colM, p.colE, 0, c.w, 0)
        if (e0v < STATIC_T && e0h < STATIC_T) return Motion(0)
        val (dy, ev) = search(c.rowM, c.rowE, p.rowM, p.rowE, c.y0, c.y1, (c.h * 0.33f).toInt())
        val (dx, eh) = search(c.colM, c.colE, p.colM, p.colE, 0, c.w, (c.w * 0.33f).toInt())
        val rv = if (e0v >= NONE) 1f else ev / (e0v + 0.01f)
        val rh = if (e0h >= NONE) 1f else eh / (e0h + 0.01f)
        val okV = ev < OK_T && rv < 0.5f && dy != 0
        val okH = eh < OK_T && rh < 0.5f && dx != 0
        return when {
            okV && okH && rv < 0.3f && rh < 0.3f -> Motion(1, dx, dy)
            okV && (!okH || rv <= rh) -> Motion(1, 0, dy)
            okH -> Motion(1, dx, 0)
            e0v < 6f && e0h < 6f -> Motion(0)
            else -> Motion(2)
        }
    }

    /** Miniatura 24x32 em tons de cinza: identifica uma página já vista. */
    fun fingerprint(img: Image): IntArray {
        val w = img.width
        val h = img.height
        val p = img.planes[0]
        val buf = p.buffer
        val rs = p.rowStride
        val ps = p.pixelStride
        val gx = 24
        val gy = 32
        val y0 = (h * 0.08f).toInt()
        val y1 = (h * 0.94f).toInt()
        val out = IntArray(gx * gy)
        for (j in 0 until gy) for (i in 0 until gx) {
            val cx = ((i + 0.5f) * w / gx).toInt()
            val cy = y0 + ((j + 0.5f) * (y1 - y0) / gy).toInt()
            var s = 0
            for (oy in -1..1) for (ox in -1..1) {
                val x = (cx + ox * 3).coerceIn(0, w - 1)
                val y = (cy + oy * 3).coerceIn(0, h - 1)
                s += buf.get(y * rs + x * ps + 1).toInt() and 255
            }
            out[j * gx + i] = s / 9
        }
        return out
    }

    fun fpDiff(a: IntArray, b: IntArray): Float {
        var s = 0L
        for (i in a.indices) s += abs(a[i] - b[i])
        return s.toFloat() / a.size
    }
}
